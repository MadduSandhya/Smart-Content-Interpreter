# Design Brief: Smart Content Interpreter

## Tone & Purpose
Premium, refined, editorial. A trusted guide for content clarity. Intelligence paired with accessibility.

## Color Palette (OKLCH)
| Role | Light | Dark | Usage |
|------|-------|------|-------|
| Primary | `0.35 0.14 264` (Deep Indigo) | `0.68 0.16 264` | Primary CTAs, highlights, trusted focal points |
| Secondary | `0.62 0.14 185` (Cyan-Blue) | `0.72 0.14 185` | Progress states, clarity indicators |
| Accent | `0.58 0.18 192` (Teal) | `0.68 0.18 192` | Keywords, highlights, UI emphasis |
| Foreground | `0.12 0 0` (Near-black) | `0.96 0 0` (Near-white) | Text, readability |
| Background | `0.98 0 0` (Off-white) | `0.11 0 0` (Deep charcoal) | Neutral surfaces |
| Muted | `0.92 0 0` (Light) | `0.2 0 0` (Dark) | Secondary text, disabled states |
| Destructive | `0.62 0.22 12` (Warm red) | `0.72 0.18 12` | Warnings, errors |

## Typography
- **Display**: General Sans (bold, 600–700 weight) — app identity, hero headlines
- **Body**: Inter (400–500 weight) — content, readability, UI labels
- **Mono**: JetBrains Mono — code snippets, technical terms
- **Type Scale**: 12/14/16/18/24/32/40px; line-height 1.4–1.6 for body text

## Structural Zones
| Zone | Treatment |
|------|-----------|
| Header/Nav | `bg-card` with `border-b` in `border`, persistent dark mode toggle |
| Hero | `bg-background`, centered copy, soft spacing (48px vertical) |
| Input Area | `bg-card` with `shadow-subtle`, 8px border-radius, breathing room |
| Output Split-Screen | Two `bg-card` columns on desktop (gap 16px), stacked mobile, `shadow-subtle` |
| Keywords Panel | `bg-muted/30` with accent highlights via `.glow-accent` utility |
| Footer | `bg-muted/20` with `border-t` in `border` |

## Shape Language
- Border radius: 8px (0.5rem) for cards, modals, inputs
- Spacing: 16px/24px/32px/48px grid for rhythm
- No full-rounded corners; preserve structure clarity

## Component Patterns
- **Cards**: `rounded-lg`, `bg-card`, `shadow-subtle`, hover state lifts to `shadow-elevated`
- **Buttons**: Primary (indigo background, white text, 6px radius), Secondary (outline, 6px radius)
- **Inputs**: Neutral border, focus ring in accent color, smooth transition
- **Keywords**: Inline highlight with `.glow-accent`, teal text accent on hover

## Motion & Transitions
- **Content transitions**: `.transition-content` (fade + slide, 0.4s) for split-screen toggles
- **Smooth interactions**: `.transition-smooth` (0.3s cubic-bezier) for hover, focus states
- **Entrance animations**: `animate-slide-in-bottom` for panels, `animate-fade-in` for content
- **Keyword highlights**: `animate-pulse-glow` for subtle attention

## Dark Mode
Primary mode with full parity. Light mode supported. Toggle in header (top-right). Preference persisted to localStorage.

## Anti-Patterns Avoided
- No full-page gradients; depth via layers and shadows
- No generic blue; custom indigo/teal palette
- No scattered animations; choreographed entrance/exit sequences
- No 12-color palette; 3 core colors (indigo, teal, red) with semantic naming
- No sans-serif system defaults; bundled premium fonts

## Signature Detail
**Keyword glow effect**: Accent-colored text with subtle box-shadow glow on keywords. Reinforces "clarity" UX.

## Responsive Breakpoints
- **Mobile**: Single-column, full-width content, stacked input/output
- **Tablet** (640px+): Refined spacing, beginning split-screen layouts
- **Desktop** (1024px+): Full split-screen comparison, side-by-side keywords panel
