import type { AudioFormat, backendInterface, ReadingLevel, SummaryLength, TtsVoice } from "../backend";

export const mockBackend: backendInterface = {
  simplifyText: async (_text: string, _level: ReadingLevel) => ({
    __kind__: "ok",
    ok: {
      simplifiedText:
        "The immune system is the body's defense network. It uses white blood cells to fight germs and keep you healthy. When a germ enters your body, your immune system detects it and sends cells to destroy it.",
      readingLevel: _level,
    },
  }),

  summarizeText: async (_text: string, _length: SummaryLength) => ({
    __kind__: "ok",
    ok: {
      summaryLength: _length,
      bulletPoints: [
        "The immune system protects the body from harmful pathogens",
        "White blood cells are the primary agents in immune defense",
        "Antibodies are proteins that neutralize specific threats",
        "Vaccines train the immune system to recognize pathogens",
      ],
      paragraph:
        "The immune system is a complex network of cells and proteins that defends the body against infection. It identifies and destroys harmful pathogens such as bacteria, viruses, and parasites, while maintaining a memory of past threats for faster future responses.",
    },
  }),

  extractKeywords: async (_text: string) => ({
    __kind__: "ok",
    ok: {
      keywords: [
        { word: "immune system", score: 0.95 },
        { word: "white blood cells", score: 0.88 },
        { word: "antibodies", score: 0.82 },
        { word: "pathogens", score: 0.79 },
        { word: "lymphocytes", score: 0.74 },
        { word: "inflammation", score: 0.68 },
        { word: "vaccination", score: 0.65 },
        { word: "antigens", score: 0.61 },
      ],
    },
  }),

  explainTerm: async (term: string) => ({
    __kind__: "ok",
    ok: {
      term,
      definition: `${term} refers to a key concept in medical science related to biological defense mechanisms and cellular response processes.`,
      examples: [
        `${term} plays a critical role in preventing infection.`,
        `Researchers study ${term} to develop new treatments.`,
      ],
    },
  }),

  summarizeVideo: async (_url: string) => ({
    __kind__: "ok",
    ok: {
      videoId: "dQw4w9WgXcQ",
      metadata: {
        videoId: "dQw4w9WgXcQ",
        title: "Sample Video Title",
        channelName: "Sample Channel",
        thumbnailUrl: "https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
        durationSeconds: BigInt(0),
      },
      summaryShort: "A brief overview of the video content covering the main topic.",
      summaryDetailed:
        "This video provides a comprehensive look at the subject matter, exploring key concepts and their practical applications. The presenter walks through several examples and explains the underlying principles in accessible language.",
      keyPoints: [
        "Introduction to the core concept",
        "Practical examples and demonstrations",
        "Key takeaways and applications",
      ],
      topics: ["Education", "Science", "Technology"],
      segments: [
        { timeSeconds: BigInt(0), timeFormatted: "0:00", keyPoint: "Introduction" },
        { timeSeconds: BigInt(60), timeFormatted: "1:00", keyPoint: "Main concept explained" },
        { timeSeconds: BigInt(180), timeFormatted: "3:00", keyPoint: "Practical examples" },
      ],
    },
  }),

  generateSpeech: async (_text: string, _voice: TtsVoice, _format?: AudioFormat | null) => ({
    __kind__: "ok",
    ok: {
      // Minimal valid silent WAV (44-byte RIFF/PCM header, 1-sample, 8-bit mono 8kHz)
      // This ensures AudioPlayer receives a non-empty data URL and renders correctly in demo mode.
      audioBase64:
        "UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=",
      audioFormat: _format ?? "mp3",
      sampleRate: "44100",
      bitrate: "128kbps",
      durationEstimate: 1.0,
    },
  }),

  generateMultilingualSpeech: async (
    _text: string,
    _voice: TtsVoice,
    targetLanguage: string,
    _format?: AudioFormat | null,
  ) => ({
    __kind__: "ok",
    ok: {
      audioBase64:
        "UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=",
      audioFormat: _format ?? "mp3",
      sampleRate: "44100",
      bitrate: "128kbps",
      translatedText: `[Translated to ${targetLanguage}] ${_text.slice(0, 200)}`,
      detectedLanguage: "English",
      durationEstimate: "5s",
      translatedLanguage: targetLanguage,
    },
  }),

  generateVoicePreview: async (_voice: TtsVoice, _language: string, _format: AudioFormat) => ({
    __kind__: "ok",
    ok: {
      audioBase64:
        "UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=",
      audioFormat: _format,
      sampleRate: "44100",
      bitrate: "128kbps",
      durationEstimate: 2.0,
    },
  }),

  transform: async (input) => ({
    status: BigInt(200),
    body: input.response.body,
    headers: [],
  }),

  transformVideo: async (input) => ({
    status: BigInt(200),
    body: input.response.body,
    headers: [],
  }),

  transformTts: async (input) => ({
    status: BigInt(200),
    body: input.response.body,
    headers: [],
  }),

  transformMultilingualTts: async (input) => ({
    status: BigInt(200),
    body: input.response.body,
    headers: [],
  }),

  transformVoicePreview: async (input) => ({
    status: BigInt(200),
    body: input.response.body,
    headers: [],
  }),
};
