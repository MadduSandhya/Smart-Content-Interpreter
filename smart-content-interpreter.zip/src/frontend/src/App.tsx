import { AudioPlayer } from "@/components/audio/AudioPlayer";
import { Layout } from "@/components/layout/Layout";
import { AudioFromFileSection } from "@/components/sections/AudioFromFileSection";
import { HeroSection } from "@/components/sections/HeroSection";
import { InputSection } from "@/components/sections/InputSection";
import { ResultsSection } from "@/components/sections/ResultsSection";
import { VideoSummarizerSection } from "@/components/sections/VideoSummarizerSection";
import { Toaster } from "@/components/ui/sonner";
import { useTheme } from "@/hooks/useTheme";
import { useContentStore } from "@/store/useContentStore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { FileAudio, FileText, Video } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";

// Eagerly apply theme before first render to avoid flash
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      retry: 1,
    },
  },
});

type ActiveTab = "text" | "video" | "file-audio";

const TABS: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
  {
    id: "text",
    label: "Text Interpreter",
    icon: <FileText className="w-4 h-4" />,
  },
  {
    id: "video",
    label: "Video Summarizer",
    icon: <Video className="w-4 h-4" />,
  },
  {
    id: "file-audio",
    label: "Audio from File",
    icon: <FileAudio className="w-4 h-4" />,
  },
];

function TabBar({
  activeTab,
  onTabChange,
}: {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}) {
  return (
    <div
      role="tablist"
      aria-label="Tool selection"
      className="flex flex-wrap bg-card border border-border rounded-xl p-1 shadow-sm w-full sm:w-auto gap-1"
    >
      {TABS.map((tab) => (
        <button
          type="button"
          key={tab.id}
          role="tab"
          aria-selected={activeTab === tab.id}
          onClick={() => onTabChange(tab.id)}
          data-ocid={`app.tab.${tab.id}`}
          className={[
            "flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 rounded-lg",
            "text-sm font-medium transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            activeTab === tab.id
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground hover:bg-muted/50",
          ].join(" ")}
        >
          {tab.icon}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
}

// Direction helper for slide animations
function getSlideDirection(tab: ActiveTab): number {
  const order: ActiveTab[] = ["text", "video", "file-audio"];
  return order.indexOf(tab);
}

function AppShell() {
  // Initializes and applies stored theme on mount
  useTheme();
  const result = useContentStore((s) => s.result);
  const [activeTab, setActiveTab] = useState<ActiveTab>("text");
  const [prevTab, setPrevTab] = useState<ActiveTab>("text");

  const handleTabChange = (tab: ActiveTab) => {
    setPrevTab(activeTab);
    setActiveTab(tab);
  };

  const direction =
    getSlideDirection(activeTab) > getSlideDirection(prevTab) ? 1 : -1;

  return (
    <Layout>
      <HeroSection ctaTargetId="interpreter" />

      <section
        id="interpreter"
        className="container mx-auto px-4 sm:px-6 py-8 space-y-6"
      >
        {/* ── Tab bar ── */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
          className="flex justify-center sm:justify-start"
        >
          <TabBar activeTab={activeTab} onTabChange={handleTabChange} />
        </motion.div>

        {/* ── Tab content ── */}
        <AnimatePresence mode="wait" custom={direction}>
          {activeTab === "text" && (
            <motion.div
              key="text-tab"
              custom={direction}
              initial={{ opacity: 0, x: -12 * direction }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 * direction }}
              transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
              className="space-y-8"
              data-ocid="app.text.panel"
            >
              <InputSection />
              {result && <ResultsSection />}
            </motion.div>
          )}

          {activeTab === "video" && (
            <motion.div
              key="video-tab"
              custom={direction}
              initial={{ opacity: 0, x: -12 * direction }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 * direction }}
              transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
              data-ocid="app.video.panel"
            >
              <VideoSummarizerSection />
            </motion.div>
          )}

          {activeTab === "file-audio" && (
            <motion.div
              key="file-audio-tab"
              custom={direction}
              initial={{ opacity: 0, x: -12 * direction }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 * direction }}
              transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
              data-ocid="app.file-audio.panel"
            >
              <AudioFromFileSection />
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </Layout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppShell />
      <AudioPlayer />
      <Toaster position="bottom-right" richColors />
    </QueryClientProvider>
  );
}
