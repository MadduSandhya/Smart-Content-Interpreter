import type { ExtractionResult } from "@/types";

// PDF.js worker CDN — avoids bundling the heavy worker
const PDF_WORKER_SRC =
  "https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.min.mjs";

const SUPPORTED_EXTENSIONS = [".txt", ".pdf", ".docx"] as const;
const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5 MB

// ─── Text Cleaning ─────────────────────────────────────────────────────────────

export function cleanText(raw: string): string {
  return raw
    .replace(/\r\n/g, "\n") // normalise line endings
    .replace(/\r/g, "\n")
    .replace(/\t/g, " ") // tabs → spaces
    .replace(/[^\S\n]+/g, " ") // collapse inline whitespace
    .replace(/\n{3,}/g, "\n\n") // max 2 consecutive newlines
    .trim();
}

// ─── Chunking ──────────────────────────────────────────────────────────────────

/**
 * Splits text into chunks at sentence boundaries so that each chunk is ≤ maxChars.
 * Falls back to hard split when no sentence boundary is found within the window.
 */
export function chunkText(text: string, maxChars = 4000): string[] {
  if (text.length <= maxChars) return [text];

  const chunks: string[] = [];
  let remaining = text;

  while (remaining.length > maxChars) {
    // Try to break at sentence boundary (. ! ?) followed by whitespace
    const window = remaining.slice(0, maxChars);
    const lastSentence = Math.max(
      window.lastIndexOf(". "),
      window.lastIndexOf("! "),
      window.lastIndexOf("? "),
      window.lastIndexOf(".\n"),
    );

    const splitAt = lastSentence > maxChars * 0.5 ? lastSentence + 1 : maxChars;
    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trim();
  }

  if (remaining.length > 0) chunks.push(remaining);
  return chunks;
}

// ─── Extractors ────────────────────────────────────────────────────────────────

export async function extractTextFromTxt(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve((e.target?.result as string) ?? "");
    reader.onerror = () => reject(new Error("Failed to read text file."));
    reader.readAsText(file);
  });
}

export async function extractTextFromPdf(file: File): Promise<string> {
  // Dynamic import to keep initial bundle lean
  const pdfjsLib = await import("pdfjs-dist");
  // Set worker source to CDN to avoid bundling the heavy worker
  pdfjsLib.GlobalWorkerOptions.workerSrc = PDF_WORKER_SRC;

  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;

  const pageTexts: string[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join(" ");
    pageTexts.push(pageText);
  }

  return pageTexts.join("\n\n");
}

export async function extractTextFromDocx(file: File): Promise<string> {
  // Dynamic import to keep initial bundle lean
  const mammoth = await import("mammoth");
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
}

// ─── Main Entry ────────────────────────────────────────────────────────────────

export async function extractTextFromFile(
  file: File,
): Promise<ExtractionResult> {
  // Validate size
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(
      `File is too large (${(file.size / 1024 / 1024).toFixed(1)} MB). Maximum allowed size is 5 MB.`,
    );
  }

  const name = file.name.toLowerCase();
  const ext = SUPPORTED_EXTENSIONS.find((e) => name.endsWith(e));

  if (!ext) {
    throw new Error(
      "Unsupported file format. Please upload a TXT, PDF, or DOCX file.",
    );
  }

  let raw: string;

  if (ext === ".txt") {
    raw = await extractTextFromTxt(file);
  } else if (ext === ".pdf") {
    raw = await extractTextFromPdf(file);
  } else {
    raw = await extractTextFromDocx(file);
  }

  const text = cleanText(raw);

  if (!text.trim()) {
    throw new Error(
      "The file appears to be empty or contains no readable text.",
    );
  }

  const wordCount = text.split(/\s+/).filter((w) => w.length > 0).length;
  const charCount = text.length;

  return { text, wordCount, charCount, fileName: file.name };
}
