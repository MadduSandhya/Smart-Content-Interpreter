// ─── Reading & Summary Controls ───────────────────────────────────────────────

export type ReadingLevel = "beginner" | "intermediate" | "advanced";

export type SummaryLength = "short" | "medium" | "detailed";

export type ActiveView = "original" | "simplified" | "split";

// ─── AI Result Types ───────────────────────────────────────────────────────────

export interface Keyword {
  word: string;
  /** brief definition shown in tooltip */
  definition: string;
  importance: "high" | "medium" | "low";
}

export interface DifficultTerm {
  term: string;
  explanation: string;
  /** char offset in simplified text where term starts */
  position?: number;
}

export interface Summary {
  paragraph: string;
  bullets: string[];
  length: SummaryLength;
}

export interface SimplificationResult {
  original: string;
  simplified: string;
  summary: Summary;
  keywords: Keyword[];
  difficultTerms: DifficultTerm[];
  readingLevel: ReadingLevel;
  processingTimeMs: number;
}

// ─── API Request / Response ───────────────────────────────────────────────────

export interface ProcessTextRequest {
  text: string;
  readingLevel: ReadingLevel;
  summaryLength: SummaryLength;
}

export interface ApiError {
  message: string;
  code?: string;
}

// ─── UI State ─────────────────────────────────────────────────────────────────

export interface ContentState {
  inputText: string;
  result: SimplificationResult | null;
  isProcessing: boolean;
  error: string | null;
  selectedReadingLevel: ReadingLevel;
  selectedSummaryLength: SummaryLength;
  activeView: ActiveView;
}

// ─── Video Summarizer Types ───────────────────────────────────────────────────

export interface VideoMetadata {
  videoId: string;
  title: string;
  channelName: string;
  durationSeconds: number;
  thumbnailUrl: string;
}

export interface TimestampSegment {
  timeSeconds: number;
  timeFormatted: string;
  keyPoint: string;
}

export interface VideoSummaryResult {
  videoId: string;
  metadata: VideoMetadata;
  summaryShort: string;
  summaryDetailed: string;
  keyPoints: string[];
  topics: string[];
  segments: TimestampSegment[];
}

export interface VideoState {
  videoUrl: string;
  videoResult: VideoSummaryResult | null;
  isProcessingVideo: boolean;
  videoError: string | null;
  setVideoUrl: (url: string) => void;
  setVideoResult: (r: VideoSummaryResult | null) => void;
  setIsProcessingVideo: (v: boolean) => void;
  setVideoError: (e: string | null) => void;
  processVideo: () => Promise<void>;
}

// ─── Audio Format Types ───────────────────────────────────────────────────────

export type AudioFormat = "mp3" | "wav" | "ogg" | "m4a";

export interface AudioFormatInfo {
  format: AudioFormat;
  label: string;
  mimeType: string;
  ext: string;
  bitrate: string;
  sampleRate: string;
  description: string;
}

export const AUDIO_FORMATS: AudioFormatInfo[] = [
  {
    format: "mp3",
    label: "MP3",
    mimeType: "audio/mpeg",
    ext: "mp3",
    bitrate: "128 kbps",
    sampleRate: "44.1 kHz",
    description: "Best compatibility",
  },
  {
    format: "wav",
    label: "WAV",
    mimeType: "audio/wav",
    ext: "wav",
    bitrate: "1411 kbps",
    sampleRate: "44.1 kHz",
    description: "Lossless quality",
  },
  {
    format: "ogg",
    label: "OGG",
    mimeType: "audio/ogg",
    ext: "ogg",
    bitrate: "128 kbps",
    sampleRate: "44.1 kHz",
    description: "Web optimized",
  },
  {
    format: "m4a",
    label: "M4A",
    mimeType: "audio/mp4",
    ext: "m4a",
    bitrate: "128 kbps",
    sampleRate: "44.1 kHz",
    description: "Mobile optimized",
  },
];

/**
 * Returns the AudioFormatInfo for a given format code.
 * Falls back to MP3 if not found.
 */
export function getFormatInfo(format: AudioFormat): AudioFormatInfo {
  return AUDIO_FORMATS.find((f) => f.format === format) ?? AUDIO_FORMATS[0];
}

/**
 * Detects the best audio format for the current device.
 * Returns 'm4a' on iOS/Android, 'mp3' otherwise.
 */
export function detectAdaptiveFormat(): AudioFormat {
  if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) return "m4a";
  return "mp3";
}

/**
 * Checks if the browser supports a given audio format via canPlayType().
 * Falls back to 'mp3' if unsupported.
 */
export function checkBrowserFormatSupport(format: AudioFormat): AudioFormat {
  const audio = document.createElement("audio");
  const mimeMap: Record<AudioFormat, string> = {
    mp3: "audio/mpeg",
    wav: "audio/wav",
    ogg: 'audio/ogg; codecs="vorbis"',
    m4a: 'audio/mp4; codecs="mp4a.40.2"',
  };
  const support = audio.canPlayType(mimeMap[format]);
  if (support === "probably" || support === "maybe") return format;
  return "mp3";
}

// ─── Text-to-Speech Types ─────────────────────────────────────────────────────

export type TtsVoice = "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer";

export interface TtsResult {
  audioBase64: string;
  durationEstimate: number;
  audioFormat?: AudioFormat;
  bitrate?: string;
  sampleRate?: string;
}

export interface AudioState {
  audioUrl: string | null;
  isGeneratingAudio: boolean;
  audioError: string | null;
  selectedVoice: TtsVoice;
  currentAudioSection: string | null;
  selectedFormat: AudioFormat;
  audioFormat?: AudioFormat;
  bitrate?: string;
  sampleRate?: string;
}

// ─── Multilingual TTS Types ───────────────────────────────────────────────────

export const SUPPORTED_LANGUAGES = [
  "English",
  "Hindi",
  "Telugu",
  "Spanish",
  "French",
  "German",
  "Japanese",
  "Chinese",
  "Arabic",
  "Portuguese",
] as const;

export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number];

export interface MultilingualTtsResult {
  audioBase64: string;
  translatedText: string;
  detectedLanguage: string;
  durationEstimate: string;
  translatedLanguage: string;
  audioFormat?: AudioFormat;
  bitrate?: string;
  sampleRate?: string;
}

// ─── File Upload / Audio-from-File Types ─────────────────────────────────────

export interface ExtractionResult {
  text: string;
  wordCount: number;
  charCount: number;
  fileName: string;
}

export interface FileAudioState {
  fileInputText: string;
  fileName: string | null;
  isExtractingFile: boolean;
  fileExtractionError: string | null;
  // Multilingual
  targetLanguage: SupportedLanguage;
  multilingualResult: MultilingualTtsResult | null;
  setFileInputText: (text: string) => void;
  setFileName: (name: string | null) => void;
  setIsExtractingFile: (val: boolean) => void;
  setFileExtractionError: (err: string | null) => void;
  setTargetLanguage: (lang: SupportedLanguage) => void;
  clearFileInput: () => void;
}
