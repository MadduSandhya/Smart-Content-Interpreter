import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Result_2 = {
    __kind__: "ok";
    ok: SimplificationResult;
} | {
    __kind__: "err";
    err: string;
};
export interface TransformationOutput {
    status: bigint;
    body: Uint8Array;
    headers: Array<http_header>;
}
export type Result_6 = {
    __kind__: "ok";
    ok: ExplanationResult;
} | {
    __kind__: "err";
    err: string;
};
export interface KeywordResult {
    keywords: Array<Keyword>;
}
export interface TtsResult {
    audioBase64: string;
    sampleRate: string;
    audioFormat: string;
    durationEstimate: number;
    bitrate: string;
}
export type Result_5 = {
    __kind__: "ok";
    ok: KeywordResult;
} | {
    __kind__: "err";
    err: string;
};
export type Result_1 = {
    __kind__: "ok";
    ok: SummarizationResult;
} | {
    __kind__: "err";
    err: string;
};
export interface http_header {
    value: string;
    name: string;
}
export interface TimestampSegment {
    timeFormatted: string;
    keyPoint: string;
    timeSeconds: bigint;
}
export interface SummarizationResult {
    summaryLength: SummaryLength;
    bulletPoints: Array<string>;
    paragraph: string;
}
export interface SimplificationResult {
    simplifiedText: string;
    readingLevel: ReadingLevel;
}
export interface http_request_result {
    status: bigint;
    body: Uint8Array;
    headers: Array<http_header>;
}
export type Result_4 = {
    __kind__: "ok";
    ok: MultilingualTtsResult;
} | {
    __kind__: "err";
    err: string;
};
export type Result_3 = {
    __kind__: "ok";
    ok: TtsResult;
} | {
    __kind__: "err";
    err: string;
};
export type Result = {
    __kind__: "ok";
    ok: VideoSummaryResult;
} | {
    __kind__: "err";
    err: string;
};
export interface TransformationInput {
    context: Uint8Array;
    response: http_request_result;
}
export interface MultilingualTtsResult {
    audioBase64: string;
    sampleRate: string;
    translatedText: string;
    detectedLanguage: string;
    audioFormat: string;
    durationEstimate: string;
    translatedLanguage: string;
    bitrate: string;
}
export interface Keyword {
    word: string;
    score: number;
}
export interface ExplanationResult {
    term: string;
    examples: Array<string>;
    definition: string;
}
export interface VideoMetadata {
    title: string;
    channelName: string;
    thumbnailUrl: string;
    durationSeconds: bigint;
    videoId: string;
}
export interface VideoSummaryResult {
    metadata: VideoMetadata;
    segments: Array<TimestampSegment>;
    keyPoints: Array<string>;
    topics: Array<string>;
    summaryShort: string;
    summaryDetailed: string;
    videoId: string;
}
export enum AudioFormat {
    m4a = "m4a",
    mp3 = "mp3",
    ogg = "ogg",
    wav = "wav"
}
export enum ReadingLevel {
    Beginner = "Beginner",
    Advanced = "Advanced",
    Intermediate = "Intermediate"
}
export enum SummaryLength {
    Short = "Short",
    Detailed = "Detailed",
    Medium = "Medium"
}
export enum TtsVoice {
    Echo = "Echo",
    Nova = "Nova",
    Onyx = "Onyx",
    Fable = "Fable",
    Alloy = "Alloy",
    Shimmer = "Shimmer"
}
export interface backendInterface {
    explainTerm(term: string): Promise<Result_6>;
    extractKeywords(text: string): Promise<Result_5>;
    generateMultilingualSpeech(text: string, voice: TtsVoice, targetLanguage: string, format: AudioFormat | null): Promise<Result_4>;
    generateSpeech(text: string, voice: TtsVoice, format: AudioFormat | null): Promise<Result_3>;
    generateVoicePreview(voice: TtsVoice, language: string, format: AudioFormat): Promise<Result_3>;
    simplifyText(text: string, level: ReadingLevel): Promise<Result_2>;
    summarizeText(text: string, length: SummaryLength): Promise<Result_1>;
    summarizeVideo(url: string): Promise<Result>;
    transform(input: TransformationInput): Promise<TransformationOutput>;
    transformMultilingualTts(input: TransformationInput): Promise<TransformationOutput>;
    transformTts(input: TransformationInput): Promise<TransformationOutput>;
    transformVideo(input: TransformationInput): Promise<TransformationOutput>;
    transformVoicePreview(input: TransformationInput): Promise<TransformationOutput>;
}
