/**
 * API service layer for Smart Content Interpreter.
 *
 * Currently uses simulated AI processing on the frontend.
 * When the backend canister exposes simplifyText / summarizeText / extractKeywords,
 * replace the simulation functions with actor calls via useActor().
 */

import type {
  AudioFormat,
  DifficultTerm,
  Keyword,
  MultilingualTtsResult,
  ProcessTextRequest,
  SimplificationResult,
  Summary,
  TtsResult,
  TtsVoice,
  VideoSummaryResult,
} from "@/types";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Simplifies vocabulary based on reading level.
 * Real implementation: actor.simplifyText(text, level)
 */
function simulateSimplification(
  text: string,
  level: ProcessTextRequest["readingLevel"],
): string {
  const levelMap = {
    beginner:
      "Here is the text explained in simple, everyday words that anyone can understand. The main ideas have been broken down into clear, short sentences. Technical terms have been replaced with common language.",
    intermediate:
      "The following is a clear explanation of the content with some technical context preserved. Key concepts are explained without assuming deep domain expertise.",
    advanced:
      "This is a refined restatement preserving technical precision while improving clarity and flow. Domain terminology is retained with concise contextual notes.",
  };

  const intro = levelMap[level];
  const sentences = text
    .split(/[.!?]+/)
    .filter((s) => s.trim().length > 20)
    .slice(0, 6)
    .map((s) => s.trim());

  return `${intro}\n\n${sentences.join(". ")}.`;
}

/**
 * Generates a summary at the requested length.
 * Real implementation: actor.summarizeText(text, length)
 */
function simulateSummary(
  text: string,
  length: ProcessTextRequest["summaryLength"],
): Summary {
  const wordCount = text.split(/\s+/).length;
  const bulletCount = length === "short" ? 3 : length === "medium" ? 5 : 8;
  const words = text.split(/\s+/).filter((w) => w.length > 4);

  const bullets: string[] = [];
  for (let i = 0; i < Math.min(bulletCount, 8); i++) {
    const idx = Math.floor((i / bulletCount) * words.length);
    const chunk = words.slice(idx, idx + 8).join(" ");
    if (chunk) bullets.push(`${chunk}.`);
  }

  const paragraph =
    length === "short"
      ? `The text covers ${wordCount} words and discusses key themes with implications for the reader.`
      : `This ${wordCount}-word text explores the core subject matter through several key ideas. The author presents a structured argument with supporting evidence. Understanding these concepts helps clarify the broader context and practical applications of the topic.`;

  return { paragraph, bullets, length };
}

/**
 * Stop-words excluded from keyword extraction — mirrors HighlightedText.tsx logic.
 * Any word <=7 chars or in this set is considered "common" and skipped.
 */
const KEYWORD_STOP_WORDS = new Set([
  "the",
  "that",
  "this",
  "with",
  "have",
  "will",
  "from",
  "they",
  "been",
  "were",
  "your",
  "more",
  "also",
  "into",
  "than",
  "then",
  "when",
  "what",
  "some",
  "would",
  "there",
  "their",
  "which",
  "about",
  "other",
  "after",
  "before",
  "because",
  "through",
  "during",
  "under",
  "over",
  "between",
  "could",
  "should",
  "these",
  "those",
  "where",
  "while",
  "every",
  "being",
  "since",
  "either",
  "within",
  "without",
  "against",
  "although",
  "whether",
  // common longer words that aren't domain keywords
  "information",
  "understanding",
  "environment",
  "development",
  "organization",
  "government",
  "international",
  "relationship",
  "community",
  "management",
  "technology",
  "communication",
  "educational",
  "significant",
  "particularly",
  "furthermore",
  "nonetheless",
  "nevertheless",
  "accordingly",
  "specifically",
  "approximately",
  "immediately",
  "continuously",
  "unfortunately",
  "essentially",
]);

/**
 * Extracts important keywords from text.
 * Scans for words over 7 characters not in a common English stop-word list,
 * scores them by length and uniqueness, and returns the top 8–12 results.
 * This logic mirrors the word-detection strategy in HighlightedText.tsx.
 *
 * Real implementation: actor.extractKeywords(text)
 */
function simulateKeywords(text: string): Keyword[] {
  const wordPattern = /[a-zA-Z]{8,}/g;
  const matches = text.match(wordPattern) ?? [];

  // Count occurrences
  const freq = new Map<string, number>();
  for (const raw of matches) {
    const w = raw.toLowerCase();
    if (!KEYWORD_STOP_WORDS.has(w)) {
      freq.set(w, (freq.get(w) ?? 0) + 1);
    }
  }

  if (freq.size === 0) return [];

  // Score by length + frequency (longer + more frequent = higher score)
  const maxLen = Math.max(...Array.from(freq.keys()).map((w) => w.length));
  const maxFreq = Math.max(...Array.from(freq.values()));

  const scored = Array.from(freq.entries()).map(([word, count]) => {
    const lengthScore = (word.length - 7) / Math.max(maxLen - 7, 1);
    const freqScore = count / maxFreq;
    const score = 0.5 + 0.3 * lengthScore + 0.2 * freqScore;
    return { word, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 12);

  return top.map(
    ({ word, score }) =>
      ({
        word,
        definition: `A key term found in the text (complexity score: ${score.toFixed(2)})`,
        importance: score >= 0.75 ? "high" : score >= 0.6 ? "medium" : "low",
      }) satisfies Keyword,
  );
}

/**
 * Lazily explains a single term on demand.
 * Real implementation: actor.explainTerm(term)
 */
export async function explainTerm(term: string): Promise<string> {
  await delay(400 + Math.random() * 300);
  const definitions: Record<string, string> = {
    epistemic: "Relating to knowledge or the conditions required to acquire it",
    heuristic:
      "A practical problem-solving approach that may not be perfect but is sufficient for the immediate goal",
    ontological:
      "Relating to the branch of metaphysics dealing with the nature of being and existence",
    taxonomy:
      "A scheme of classification, especially a hierarchical system of categorising organisms or concepts",
    mitigation:
      "The action of reducing the severity, seriousness, or painfulness of something",
    substantive:
      "Having a firm basis in reality; meaningful and significant rather than superficial",
    paradigm:
      "A typical example, pattern, or model of something; a conceptual framework within a discipline",
    hypothesis:
      "A proposed explanation made on the basis of limited evidence as a starting point for investigation",
    methodology:
      "A system of methods and principles used in a particular area of study or activity",
    algorithm:
      "A step-by-step procedure or set of rules for solving a specific problem or achieving a goal",
    empirical:
      "Based on observation or experiment rather than pure theory or logic",
    synthesis:
      "The combination of elements to form a connected whole; a new, more complex entity",
    cognitive:
      "Relating to the mental processes of acquiring knowledge through thought and experience",
    inference:
      "A conclusion reached through evidence, reasoning, and logical deduction",
  };
  const clean = term.toLowerCase().replace(/[^a-z]/g, "");
  return (
    definitions[clean] ??
    "A technical or complex term used in the subject domain. For a detailed definition, consult a subject-specific glossary."
  );
}

/**
 * Detects difficult terms and provides explanations.
 * Real implementation: actor.explainTerm(term)
 */
function simulateDifficultTerms(text: string): DifficultTerm[] {
  const difficult: DifficultTerm[] = [
    {
      term: "epistemic",
      explanation: "Relating to knowledge or the conditions for acquiring it",
    },
    {
      term: "heuristic",
      explanation:
        "A practical problem-solving approach that may not be perfect but is sufficient",
    },
    {
      term: "ontological",
      explanation:
        "Relating to the branch of philosophy dealing with the nature of existence",
    },
    {
      term: "taxonomy",
      explanation: "A scheme of classification, especially of living organisms",
    },
    {
      term: "mitigation",
      explanation: "The action of reducing the severity of something harmful",
    },
    {
      term: "substantive",
      explanation: "Having a firm basis in reality; significant and meaningful",
    },
  ];

  return difficult.filter((t) => text.toLowerCase().includes(t.term));
}

// ─── Main Text API Function ───────────────────────────────────────────────────

export async function processText(
  request: ProcessTextRequest,
): Promise<SimplificationResult> {
  const startTime = Date.now();

  if (!request.text.trim()) {
    throw new Error("Input text cannot be empty.");
  }

  if (request.text.trim().length < 20) {
    throw new Error(
      "Please enter at least a sentence or two for meaningful analysis.",
    );
  }

  // Simulate network latency for realistic UX
  await delay(1200 + Math.random() * 800);

  const simplified = simulateSimplification(request.text, request.readingLevel);
  const summary = simulateSummary(request.text, request.summaryLength);
  const keywords = simulateKeywords(request.text);
  const difficultTerms = simulateDifficultTerms(request.text);

  return {
    original: request.text,
    simplified,
    summary,
    keywords,
    difficultTerms,
    readingLevel: request.readingLevel,
    processingTimeMs: Date.now() - startTime,
  };
}

// ─── Video Summarizer API ─────────────────────────────────────────────────────

/**
 * Extracts YouTube video ID from various URL formats.
 * Supports: youtube.com/watch?v=ID, youtu.be/ID, youtube.com/embed/ID
 */
export function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?(?:.*&)?v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match?.[1]) return match[1];
  }
  return null;
}

/**
 * Formats seconds to MM:SS or HH:MM:SS display.
 */
function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}

/**
 * Simulates a video summary result with realistic sample data.
 * Real implementation: actor.summarizeVideo(url)
 */
function simulateVideoSummary(videoId: string): VideoSummaryResult {
  return {
    videoId,
    metadata: {
      videoId,
      title:
        "The Future of Artificial Intelligence: Transforming How We Work and Learn",
      channelName: "TechInsights Academy",
      durationSeconds: 1847,
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
    },
    summaryShort:
      "This video explores how artificial intelligence is reshaping industries from healthcare to education, covering machine learning fundamentals, real-world applications, and ethical considerations for the next decade.",
    summaryDetailed:
      "The presenter begins with an overview of the current AI landscape, explaining how large language models and neural networks have evolved from theoretical constructs to practical tools used by millions daily. The video covers three major domains: workplace automation (with emphasis on augmentation rather than replacement), personalized learning systems that adapt to individual student needs, and diagnostic AI in medicine that achieves near-specialist accuracy. The second half addresses challenges including algorithmic bias, data privacy, and the need for transparent AI governance frameworks. The presenter concludes with an optimistic yet cautious outlook, arguing that the most transformative outcomes require collaboration between technologists, policymakers, and the communities most affected by these systems.",
    keyPoints: [
      "Large language models have crossed a capability threshold that makes them practically useful for everyday tasks",
      "AI augments human workers rather than replacing them in most near-term scenarios",
      "Personalized learning systems improve student outcomes by 30–40% in controlled studies",
      "Medical AI achieves specialist-level diagnostic accuracy for imaging tasks",
      "Algorithmic bias remains a critical unsolved challenge requiring diverse training data",
      "Data privacy frameworks like GDPR shape how AI systems can be deployed ethically",
      "Cross-sector collaboration is essential for responsible AI governance",
    ],
    topics: [
      "Machine Learning",
      "Neural Networks",
      "Workplace Automation",
      "EdTech",
      "Medical AI",
      "Algorithmic Bias",
      "Data Privacy",
      "AI Ethics",
      "Governance",
    ],
    segments: [
      {
        timeSeconds: 0,
        timeFormatted: "0:00",
        keyPoint: "Introduction: The AI revolution in context",
      },
      {
        timeSeconds: 142,
        timeFormatted: "2:22",
        keyPoint: "How large language models actually work",
      },
      {
        timeSeconds: 318,
        timeFormatted: "5:18",
        keyPoint: "AI in the workplace: augmentation vs. replacement",
      },
      {
        timeSeconds: 524,
        timeFormatted: "8:44",
        keyPoint: "Case study: AI-powered customer service tools",
      },
      {
        timeSeconds: 703,
        timeFormatted: "11:43",
        keyPoint: "Personalized learning and adaptive education platforms",
      },
      {
        timeSeconds: 901,
        timeFormatted: "15:01",
        keyPoint: "Medical diagnosis AI: imaging and early detection",
      },
      {
        timeSeconds: 1102,
        timeFormatted: "18:22",
        keyPoint: "Understanding algorithmic bias and its real-world impacts",
      },
      {
        timeSeconds: 1298,
        timeFormatted: "21:38",
        keyPoint: "Data privacy regulations and AI deployment",
      },
      {
        timeSeconds: 1490,
        timeFormatted: "24:50",
        keyPoint: "Building governance frameworks for AI",
      },
      {
        timeSeconds: 1680,
        timeFormatted: "28:00",
        keyPoint: "Outlook: What the next decade holds",
      },
    ],
  };
}

/**
 * Summarizes a YouTube video by URL.
 * Real implementation: calls actor.summarizeVideo(url) via backend canister.
 */
export async function summarizeVideo(url: string): Promise<VideoSummaryResult> {
  const videoId = extractVideoId(url);
  if (!videoId) {
    throw new Error(
      "Invalid YouTube URL. Please paste a link like youtube.com/watch?v=… or youtu.be/…",
    );
  }

  // Simulate backend processing latency
  await delay(2000 + Math.random() * 1200);

  return simulateVideoSummary(videoId);
}

// ─── Text-to-Speech API ───────────────────────────────────────────────────────

/**
 * Returns bitrate metadata for a given format.
 */
function getFormatMeta(format: AudioFormat): {
  bitrate: string;
  sampleRate: string;
} {
  const map: Record<AudioFormat, { bitrate: string; sampleRate: string }> = {
    mp3: { bitrate: "128 kbps", sampleRate: "44.1 kHz" },
    wav: { bitrate: "1411 kbps", sampleRate: "44.1 kHz" },
    ogg: { bitrate: "128 kbps", sampleRate: "44.1 kHz" },
    m4a: { bitrate: "128 kbps", sampleRate: "44.1 kHz" },
  };
  return map[format];
}

/**
 * Generates speech audio from text using the backend TTS service.
 * Returns a TtsResult with audioBase64 (base64-encoded audio) and durationEstimate.
 * The caller should construct data URL: `data:audio/${format};base64,` + result.audioBase64
 *
 * Real implementation: actor.generateSpeech(text, voice, format)
 */
export async function generateSpeech(
  text: string,
  _voice: TtsVoice,
  format: AudioFormat = "mp3",
): Promise<TtsResult> {
  if (!text.trim()) {
    throw new Error("Text cannot be empty.");
  }

  // Simulate backend TTS latency
  await delay(1500 + Math.random() * 1000);

  // In production, this calls actor.generateSpeech(text, voice, format)
  // and returns { audioBase64, durationEstimate, audioFormat, bitrate, sampleRate }
  const estimatedWords = text.split(/\s+/).length;
  const durationEstimate = estimatedWords / 2.5; // ~150 wpm
  const { bitrate, sampleRate } = getFormatMeta(format);

  return {
    audioBase64: "",
    durationEstimate,
    audioFormat: format,
    bitrate,
    sampleRate,
  };
}

// ─── Multilingual Text-to-Speech API ─────────────────────────────────────────

/**
 * Simulates language detection based on simple heuristics.
 * Real implementation: backend AI language detection.
 */
function simulateDetectLanguage(text: string): string {
  // Very simple heuristic: check for non-ASCII character patterns
  if (/[\u0900-\u097F]/.test(text)) return "Hindi";
  if (/[\u0C00-\u0C7F]/.test(text)) return "Telugu";
  if (/[\u4E00-\u9FFF]/.test(text)) return "Chinese";
  if (/[\u3040-\u30FF]/.test(text)) return "Japanese";
  if (/[\u0600-\u06FF]/.test(text)) return "Arabic";
  // Default to English for Latin script
  return "English";
}

/**
 * Simulates translation prefix for demonstration.
 * Real implementation: actor.generateMultilingualSpeech(text, voice, targetLanguage)
 */
function simulateTranslation(text: string, targetLanguage: string): string {
  const prefixMap: Record<string, string> = {
    Hindi: "[हिंदी अनुवाद] यह सामग्री हिंदी में प्रस्तुत की गई है। ",
    Telugu: "[తెలుగు అనువాదం] ఈ కంటెంట్ తెలుగులో అందించబడింది। ",
    Spanish:
      "[Traducción al Español] Este contenido ha sido traducido al español. ",
    French: "[Traduction en Français] Ce contenu a été traduit en français. ",
    German:
      "[Deutsche Übersetzung] Dieser Inhalt wurde ins Deutsche übersetzt. ",
    Japanese: "[日本語翻訳] このコンテンツは日本語に翻訳されました。",
    Chinese: "[中文翻译] 此内容已翻译成中文。",
    Arabic: "[الترجمة العربية] تمت ترجمة هذا المحتوى إلى اللغة العربية. ",
    Portuguese:
      "[Tradução para Português] Este conteúdo foi traduzido para o português. ",
    English: "",
  };
  const prefix = prefixMap[targetLanguage] ?? "";
  // Truncate preview for simulation — real backend returns full translation
  const preview = text.slice(0, 300) + (text.length > 300 ? "…" : "");
  return prefix + preview;
}

/**
 * Generates multilingual speech from text with automatic language detection
 * and translation to the target language.
 *
 * Real implementation: actor.generateMultilingualSpeech(text, voice, targetLanguage, format)
 */
export async function generateMultilingualSpeech(
  text: string,
  _voice: TtsVoice,
  targetLanguage: string,
  format: AudioFormat = "mp3",
): Promise<MultilingualTtsResult> {
  if (!text.trim()) {
    throw new Error("Text cannot be empty.");
  }
  if (!targetLanguage.trim()) {
    throw new Error("Target language must be specified.");
  }

  // Simulate backend processing latency (translation adds overhead)
  await delay(2000 + Math.random() * 1500);

  const detectedLanguage = simulateDetectLanguage(text);
  const translatedText = simulateTranslation(text, targetLanguage);
  const estimatedWords = translatedText.split(/\s+/).length;
  const durationSecs = Math.round(estimatedWords / 2.5);
  const mins = Math.floor(durationSecs / 60);
  const secs = durationSecs % 60;
  const durationEstimate = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  const { bitrate, sampleRate } = getFormatMeta(format);

  return {
    audioBase64: "",
    translatedText,
    detectedLanguage,
    translatedLanguage: targetLanguage,
    durationEstimate,
    audioFormat: format,
    bitrate,
    sampleRate,
  };
}

// ─── Voice Preview API ────────────────────────────────────────────────────────

/**
 * Generates a short voice preview sample (a few words of sample text).
 * Real implementation: actor.generateVoicePreview(voice, language, format)
 */
export async function generateVoicePreview(
  _voice: TtsVoice,
  _language: string,
  _format: AudioFormat,
): Promise<TtsResult> {
  // Simulate short TTS latency for preview
  await delay(800 + Math.random() * 500);

  // Real backend returns a short base64 audio sample
  return {
    audioBase64: "",
    durationEstimate: 3,
    audioFormat: _format,
    bitrate: getFormatMeta(_format).bitrate,
    sampleRate: getFormatMeta(_format).sampleRate,
  };
}

// Re-export formatDuration for use in components
export { formatDuration };
