/**
 * AudioPlayer — sticky bottom audio player for TTS output.
 * Reads from the global content store. Shows when audioUrl is available.
 * Features: play/pause/stop, seek bar, volume, speed, format selector,
 * format+language badge with bitrate info, voice preview, download, dismiss.
 */

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useContentStore } from "@/store/useContentStore";
import { AUDIO_FORMATS, type AudioFormat, type TtsVoice } from "@/types";
import {
  Download,
  Pause,
  Play,
  PlayCircle,
  Square,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useRef, useState } from "react";

// ─── Voice Options ────────────────────────────────────────────────────────────

const VOICE_OPTIONS: { value: TtsVoice; label: string; desc: string }[] = [
  { value: "alloy", label: "Alloy", desc: "Neutral" },
  { value: "echo", label: "Echo", desc: "Male" },
  { value: "fable", label: "Fable", desc: "Male" },
  { value: "onyx", label: "Onyx", desc: "Deep Male" },
  { value: "nova", label: "Nova", desc: "Female" },
  { value: "shimmer", label: "Shimmer", desc: "Female" },
];

// ─── Speed Options ────────────────────────────────────────────────────────────

const SPEED_OPTIONS = [0.75, 1, 1.25, 1.5] as const;

// ─── Format color map ─────────────────────────────────────────────────────────

const FORMAT_COLORS: Record<AudioFormat, string> = {
  mp3: "bg-primary/15 text-primary border-primary/30",
  wav: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  ogg: "bg-violet-500/15 text-violet-600 dark:text-violet-400 border-violet-500/30",
  m4a: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
};

// ─── Time Formatter ───────────────────────────────────────────────────────────

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function AudioPlayer() {
  const {
    audioUrl,
    currentAudioSection,
    selectedVoice,
    selectedFormat,
    audioFormat,
    bitrate,
    sampleRate,
    multilingualResult,
    setSelectedVoice,
    setAudioUrl,
    setCurrentAudioSection,
    setAudioFormat,
    generateVoicePreview,
  } = useContentStore();

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [speed, setSpeed] = useState<(typeof SPEED_OPTIONS)[number]>(1);
  const [showVoicePanel, setShowVoicePanel] = useState(false);
  const [showFormatPanel, setShowFormatPanel] = useState(false);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  // Keep mutable refs for values used in the audioUrl effect without triggering re-runs
  const volumeRef = useRef(volume);
  const isMutedRef = useRef(isMuted);
  const speedRef = useRef(speed);

  useEffect(() => {
    volumeRef.current = volume;
  }, [volume]);
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);
  useEffect(() => {
    speedRef.current = speed;
  }, [speed]);

  // ── Load new audio source ──
  useEffect(() => {
    if (!audioRef.current || !audioUrl) return;
    const audio = audioRef.current;
    audio.src = audioUrl;
    audio.load();
    audio.playbackRate = speedRef.current;
    audio.volume = isMutedRef.current ? 0 : volumeRef.current;
    setCurrentTime(0);
    setDuration(0);
    setIsPlaying(false);
  }, [audioUrl]);

  // ── Event listeners ──
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onDurationChange = () => setDuration(audio.duration);
    const onEnded = () => setIsPlaying(false);
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("durationchange", onDurationChange);
    audio.addEventListener("loadedmetadata", onDurationChange);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);

    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("durationchange", onDurationChange);
      audio.removeEventListener("loadedmetadata", onDurationChange);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
    };
  }, []);

  // ── Speed sync ──
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  }, [speed]);

  // ── Volume sync ──
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const handlePlayPause = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
    } else {
      await audio.play();
    }
  }, [isPlaying]);

  const handleStop = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    audio.currentTime = 0;
    setIsPlaying(false);
  }, []);

  const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const audio = audioRef.current;
    if (!audio) return;
    const t = Number(e.target.value);
    audio.currentTime = t;
    setCurrentTime(t);
  }, []);

  const handleVolume = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const v = Number(e.target.value);
    setVolume(v);
    setIsMuted(v === 0);
  }, []);

  // Format-aware download: uses audioFormat from store for correct extension + MIME
  const handleDownload = useCallback(() => {
    if (!audioUrl) return;
    const fmt = audioFormat ?? selectedFormat;
    const fmtInfo = AUDIO_FORMATS.find((f) => f.format === fmt);
    const ext = fmtInfo?.ext ?? "mp3";
    const mimeType = fmtInfo?.mimeType ?? "audio/mpeg";
    const langLabel = multilingualResult?.translatedLanguage
      ? `-${multilingualResult.translatedLanguage.toLowerCase()}`
      : "";

    // If data URI, convert to blob for cleaner download
    if (audioUrl.startsWith("data:")) {
      const [, base64] = audioUrl.split(",");
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: mimeType });
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `content-audio${langLabel}.${ext}`;
      link.click();
      URL.revokeObjectURL(blobUrl);
    } else {
      const link = document.createElement("a");
      link.href = audioUrl;
      link.download = `content-audio${langLabel}.${ext}`;
      link.click();
    }
  }, [audioUrl, audioFormat, selectedFormat, multilingualResult]);

  const handleDismiss = useCallback(() => {
    handleStop();
    setAudioUrl(null);
    setCurrentAudioSection(null);
  }, [handleStop, setAudioUrl, setCurrentAudioSection]);

  const handleVoicePreview = useCallback(async () => {
    setIsPreviewLoading(true);
    const language = multilingualResult?.translatedLanguage ?? "English";
    await generateVoicePreview(selectedVoice, language);
    setIsPreviewLoading(false);
  }, [selectedVoice, multilingualResult, generateVoicePreview]);

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  // Displayed format: use actual audioFormat from generated result, fallback to selectedFormat
  const displayFormat = audioFormat ?? selectedFormat;
  const fmtInfo = AUDIO_FORMATS.find((f) => f.format === displayFormat);
  const displayLanguage = multilingualResult?.translatedLanguage ?? null;

  return (
    <>
      {/* Hidden audio element with track for accessibility */}
      <audio ref={audioRef} preload="auto">
        <track kind="captions" />
      </audio>

      <AnimatePresence>
        {audioUrl !== null && (
          <motion.div
            key="audio-player"
            initial={{ opacity: 0, y: 80 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 80 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-md shadow-2xl"
            data-ocid="audio.player"
          >
            {/* Progress bar — full width at top */}
            <div className="relative h-1 bg-muted">
              <div
                className="absolute left-0 top-0 h-full bg-primary transition-all duration-100"
                style={{ width: `${progressPercent}%` }}
              />
              <input
                type="range"
                min={0}
                max={duration || 0}
                step={0.1}
                value={currentTime}
                onChange={handleSeek}
                aria-label="Seek audio position"
                data-ocid="audio.seek_bar"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            <div className="container mx-auto px-4 py-3">
              <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
                {/* Section label + format/language badge */}
                <div className="flex-1 min-w-0 order-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-xs text-muted-foreground truncate">
                      <span className="text-primary font-medium">
                        🔊 Listening:
                      </span>{" "}
                      <span className="text-foreground">
                        {currentAudioSection ?? "Audio"}
                      </span>
                    </p>
                    {/* Format + Language badge */}
                    <span
                      data-ocid="audio.format_badge"
                      className={cn(
                        "inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-semibold",
                        FORMAT_COLORS[displayFormat],
                      )}
                    >
                      {fmtInfo?.label ?? displayFormat.toUpperCase()}
                      {displayLanguage && (
                        <>
                          <span className="opacity-40">•</span>
                          {displayLanguage}
                        </>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-xs text-muted-foreground font-mono">
                      {formatTime(currentTime)}{" "}
                      <span className="text-muted-foreground/50">/</span>{" "}
                      {formatTime(duration)}
                    </p>
                    {/* Bitrate / sample rate indicator */}
                    {(bitrate ?? sampleRate) && (
                      <p
                        data-ocid="audio.quality_info"
                        className="text-xs text-muted-foreground/70 font-mono hidden sm:block"
                      >
                        {[bitrate, sampleRate].filter(Boolean).join(" • ")}
                      </p>
                    )}
                  </div>
                </div>

                {/* Transport controls */}
                <div className="flex items-center gap-1 order-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleStop}
                    aria-label="Stop"
                    data-ocid="audio.stop_button"
                    className="h-8 w-8 rounded-full hover:bg-muted"
                  >
                    <Square className="w-3.5 h-3.5 fill-foreground" />
                  </Button>

                  <Button
                    variant="default"
                    size="icon"
                    onClick={handlePlayPause}
                    aria-label={isPlaying ? "Pause" : "Play"}
                    data-ocid="audio.play_button"
                    className="h-9 w-9 rounded-full shadow-sm"
                  >
                    {isPlaying ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4 translate-x-0.5" />
                    )}
                  </Button>
                </div>

                {/* Speed selector — fieldset for semantic grouping */}
                <fieldset className="flex items-center gap-0.5 border-0 p-0 m-0 order-3">
                  <legend className="sr-only">Playback speed</legend>
                  {SPEED_OPTIONS.map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => setSpeed(s)}
                      data-ocid={`audio.speed.${String(s).replace(".", "_")}x`}
                      aria-pressed={speed === s}
                      className={cn(
                        "px-2 py-1 rounded text-xs font-mono font-medium transition-colors",
                        speed === s
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted/60",
                      )}
                    >
                      {s}x
                    </button>
                  ))}
                </fieldset>

                {/* Volume */}
                <div className="hidden sm:flex items-center gap-2 order-4">
                  <button
                    type="button"
                    onClick={() => setIsMuted(!isMuted)}
                    aria-label={isMuted ? "Unmute" : "Mute"}
                    data-ocid="audio.mute_toggle"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={isMuted ? 0 : volume}
                    onChange={handleVolume}
                    aria-label="Volume"
                    data-ocid="audio.volume_slider"
                    className="w-20 accent-primary cursor-pointer"
                  />
                </div>

                {/* Format selector */}
                <div className="relative order-5">
                  <button
                    type="button"
                    onClick={() => {
                      setShowFormatPanel(!showFormatPanel);
                      setShowVoicePanel(false);
                    }}
                    data-ocid="audio.format_select"
                    aria-label="Select audio format"
                    aria-expanded={showFormatPanel}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-colors",
                      showFormatPanel
                        ? "border-primary/50 bg-primary/10 text-primary"
                        : cn("border-border", FORMAT_COLORS[selectedFormat]),
                    )}
                  >
                    {AUDIO_FORMATS.find((f) => f.format === selectedFormat)
                      ?.label ?? selectedFormat.toUpperCase()}
                  </button>

                  <AnimatePresence>
                    {showFormatPanel && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full right-0 mb-2 bg-card border border-border rounded-xl shadow-lg p-2 min-w-52 z-10"
                        data-ocid="audio.format.popover"
                      >
                        <p className="text-xs text-muted-foreground px-2 py-1 mb-1 font-medium">
                          Output Format
                        </p>
                        {AUDIO_FORMATS.map((f) => (
                          <button
                            type="button"
                            key={f.format}
                            onClick={() => {
                              setAudioFormat(f.format);
                              setShowFormatPanel(false);
                            }}
                            data-ocid={`audio.format.${f.format}`}
                            className={cn(
                              "w-full text-left flex items-center justify-between px-2 py-2 rounded-lg text-xs transition-colors",
                              selectedFormat === f.format
                                ? "bg-primary/10 text-primary font-medium"
                                : "text-foreground hover:bg-muted/60",
                            )}
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={cn(
                                  "px-1.5 py-0.5 rounded text-xs font-bold border",
                                  FORMAT_COLORS[f.format],
                                )}
                              >
                                {f.label}
                              </span>
                              <span className="text-muted-foreground">
                                {f.description}
                              </span>
                            </div>
                            <span className="text-muted-foreground font-mono text-xs">
                              {f.bitrate}
                            </span>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Voice selector toggle */}
                <div className="relative order-6">
                  <button
                    type="button"
                    onClick={() => {
                      setShowVoicePanel(!showVoicePanel);
                      setShowFormatPanel(false);
                    }}
                    data-ocid="audio.voice_select"
                    aria-label="Select voice"
                    aria-expanded={showVoicePanel}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors",
                      showVoicePanel
                        ? "border-primary/50 bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:text-foreground hover:border-border/80",
                    )}
                  >
                    <span aria-hidden>🎙</span>
                    <span className="capitalize">{selectedVoice}</span>
                  </button>

                  <AnimatePresence>
                    {showVoicePanel && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full right-0 mb-2 bg-card border border-border rounded-xl shadow-lg p-2 min-w-48 z-10"
                        data-ocid="audio.voice.popover"
                      >
                        <div className="flex items-center justify-between px-2 py-1 mb-1">
                          <p className="text-xs text-muted-foreground">Voice</p>
                          {/* Voice Preview button */}
                          <button
                            type="button"
                            onClick={handleVoicePreview}
                            disabled={isPreviewLoading}
                            data-ocid="audio.voice_preview_button"
                            aria-label="Preview selected voice"
                            className={cn(
                              "flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium transition-colors",
                              isPreviewLoading
                                ? "text-muted-foreground opacity-60 cursor-wait"
                                : "text-primary hover:bg-primary/10",
                            )}
                          >
                            <PlayCircle className="w-3.5 h-3.5" />
                            {isPreviewLoading ? "Loading…" : "Preview"}
                          </button>
                        </div>
                        {VOICE_OPTIONS.map((v) => (
                          <button
                            type="button"
                            key={v.value}
                            onClick={() => {
                              setSelectedVoice(v.value);
                              setShowVoicePanel(false);
                            }}
                            data-ocid={`audio.voice.${v.value}`}
                            className={cn(
                              "w-full text-left flex items-center justify-between px-2 py-1.5 rounded-lg text-xs transition-colors",
                              selectedVoice === v.value
                                ? "bg-primary/10 text-primary font-medium"
                                : "text-foreground hover:bg-muted/60",
                            )}
                          >
                            <span>{v.label}</span>
                            <span className="text-muted-foreground">
                              {v.desc}
                            </span>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Download */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleDownload}
                  aria-label="Download audio"
                  data-ocid="audio.download_button"
                  className="h-8 w-8 rounded-full order-7"
                >
                  <Download className="w-3.5 h-3.5" />
                </Button>

                {/* Dismiss */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleDismiss}
                  aria-label="Close audio player"
                  data-ocid="audio.close_button"
                  className="h-8 w-8 rounded-full order-8 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
