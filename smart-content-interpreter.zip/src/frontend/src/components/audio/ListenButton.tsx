/**
 * ListenButton — triggers TTS generation for a given text section.
 * Shows loading state when generating audio for this section.
 * Shows error inline if generation fails for this section.
 */

import { cn } from "@/lib/utils";
import { useContentStore } from "@/store/useContentStore";
import { AlertCircle, Loader2, Volume2 } from "lucide-react";
import { useCallback } from "react";

interface ListenButtonProps {
  text: string;
  label: string;
  className?: string;
}

export function ListenButton({ text, label, className }: ListenButtonProps) {
  const {
    generateAudio,
    isGeneratingAudio,
    currentAudioSection,
    audioError,
    audioUrl,
  } = useContentStore();

  const isThisSection = currentAudioSection === label;
  const isLoadingThis = isGeneratingAudio && isThisSection;
  const hasErrorThis = !!audioError && isThisSection;
  const isPlayingThis = !!audioUrl && isThisSection && !isGeneratingAudio;

  const handleClick = useCallback(async () => {
    if (!text.trim() || isLoadingThis) return;
    await generateAudio(text, label);
  }, [text, label, isLoadingThis, generateAudio]);

  return (
    <div className={cn("inline-flex flex-col items-start gap-1", className)}>
      <button
        type="button"
        onClick={handleClick}
        disabled={isLoadingThis || !text.trim()}
        data-ocid={`audio.listen.${label.toLowerCase().replace(/\s+/g, "_")}`}
        aria-label={`Listen to ${label}`}
        className={cn(
          "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium",
          "border transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          "disabled:opacity-60 disabled:cursor-not-allowed",
          isPlayingThis
            ? "border-accent/50 bg-accent/10 text-accent"
            : isLoadingThis
              ? "border-primary/30 bg-primary/5 text-primary"
              : "border-border text-muted-foreground hover:text-foreground hover:border-primary/40 hover:bg-primary/5",
        )}
      >
        {isLoadingThis ? (
          <>
            <Loader2 className="w-3 h-3 animate-spin shrink-0" />
            <span>Generating…</span>
          </>
        ) : (
          <>
            <Volume2
              className={cn("w-3 h-3 shrink-0", isPlayingThis && "text-accent")}
            />
            <span>{isPlayingThis ? "Playing" : "🔊 Listen"}</span>
          </>
        )}
      </button>

      {hasErrorThis && (
        <p
          className="flex items-center gap-1 text-xs text-destructive"
          role="alert"
        >
          <AlertCircle className="w-3 h-3 shrink-0" />
          <span className="truncate max-w-48">Audio generation failed</span>
        </p>
      )}
    </div>
  );
}
