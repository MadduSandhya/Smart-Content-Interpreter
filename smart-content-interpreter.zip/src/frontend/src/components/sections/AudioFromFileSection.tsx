import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useContentStore } from "@/store/useContentStore";
import {
  AUDIO_FORMATS,
  type AudioFormat,
  SUPPORTED_LANGUAGES,
  type SupportedLanguage,
} from "@/types";
import { extractTextFromFile } from "@/utils/fileExtractor";
import {
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  FileAudio,
  FileText,
  Globe,
  Info,
  Loader2,
  Music2,
  Trash2,
  Upload,
  Volume2,
  X,
} from "lucide-react";
import { useCallback, useRef, useState } from "react";

type InputMode = "upload" | "type";

const FILE_FORMAT_LABELS: { ext: string; color: string }[] = [
  { ext: "TXT", color: "bg-muted text-muted-foreground" },
  { ext: "PDF", color: "bg-destructive/10 text-destructive" },
  { ext: "DOCX", color: "bg-primary/10 text-primary" },
];

const AUDIO_FORMAT_COLORS: Record<AudioFormat, string> = {
  mp3: "bg-primary/15 text-primary border-primary/30",
  wav: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  ogg: "bg-violet-500/15 text-violet-600 dark:text-violet-400 border-violet-500/30",
  m4a: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
};

const MAX_PREVIEW_CHARS = 600;
const TRANSLATED_PREVIEW_CHARS = 400;

function FileBadge({ ext, color }: { ext: string; color: string }) {
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${color}`}
    >
      {ext}
    </span>
  );
}

function DropZone({
  onFile,
  isDragging,
  onDragOver,
  onDragLeave,
  onDrop,
}: {
  onFile: (file: File) => void;
  isDragging: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <button
      type="button"
      data-ocid="file-audio.dropzone"
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
      aria-label="Click or drag a file to upload"
      className={[
        "flex flex-col items-center justify-center gap-4 rounded-2xl border-2 border-dashed",
        "py-14 px-6 cursor-pointer transition-smooth select-none",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        isDragging
          ? "border-primary bg-primary/5 scale-[1.01]"
          : "border-border hover:border-primary/50 hover:bg-muted/30",
      ].join(" ")}
    >
      <div className="flex flex-col items-center gap-3 text-center">
        <div
          className={`p-4 rounded-full transition-smooth ${isDragging ? "bg-primary/15" : "bg-muted/60"}`}
        >
          <Upload
            className={`w-8 h-8 transition-smooth ${isDragging ? "text-primary" : "text-muted-foreground"}`}
          />
        </div>
        <div>
          <p className="font-semibold text-foreground text-base">
            {isDragging ? "Drop your file here" : "Drag & drop your file"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            or{" "}
            <span className="text-primary font-medium underline underline-offset-2">
              browse to upload
            </span>
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-center">
          {FILE_FORMAT_LABELS.map(({ ext, color }) => (
            <FileBadge key={ext} ext={ext} color={color} />
          ))}
          <span className="text-xs text-muted-foreground">· Max 5 MB</span>
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        accept=".txt,.pdf,.docx"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFile(file);
          e.target.value = "";
        }}
      />
    </button>
  );
}

function FileInfo({
  name,
  size,
  onClear,
}: {
  name: string;
  size?: number;
  onClear: () => void;
}) {
  const ext = name.split(".").pop()?.toUpperCase() ?? "";
  const sizeLabel = size
    ? size < 1024 * 1024
      ? `${(size / 1024).toFixed(1)} KB`
      : `${(size / 1024 / 1024).toFixed(1)} MB`
    : null;

  return (
    <div
      data-ocid="file-audio.file_info"
      className="flex items-center gap-3 p-4 rounded-xl bg-muted/40 border border-border"
    >
      <FileText className="w-8 h-8 text-primary flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-foreground truncate">{name}</p>
        <p className="text-xs text-muted-foreground">
          {ext} {sizeLabel ? `· ${sizeLabel}` : ""}
        </p>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        data-ocid="file-audio.clear_button"
        onClick={onClear}
        className="text-muted-foreground hover:text-destructive flex-shrink-0"
        aria-label="Remove file"
      >
        <X className="w-4 h-4" />
      </Button>
    </div>
  );
}

function TextPreview({
  text,
  wordCount,
  charCount,
}: {
  text: string;
  wordCount: number;
  charCount: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const isLong = text.length > MAX_PREVIEW_CHARS;
  const displayed =
    isLong && !expanded ? text.slice(0, MAX_PREVIEW_CHARS) : text;

  return (
    <div
      data-ocid="file-audio.preview_panel"
      className="rounded-xl border border-border bg-card overflow-hidden"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
        <div className="flex items-center gap-2">
          <FileAudio className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">
            Extracted Text
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {wordCount.toLocaleString()} words
          </Badge>
          <Badge variant="outline" className="text-xs">
            {charCount.toLocaleString()} chars
          </Badge>
        </div>
      </div>
      <div className="p-4">
        <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words font-mono">
          {displayed}
          {isLong && !expanded && (
            <span className="text-muted-foreground">…</span>
          )}
        </p>
        {isLong && (
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            data-ocid="file-audio.preview_toggle"
            className="mt-3 flex items-center gap-1 text-xs font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-3 h-3" /> Show less
              </>
            ) : (
              <>
                <ChevronDown className="w-3 h-3" /> Show full text
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function TranslatedTextPreview({ text }: { text: string }) {
  const [expanded, setExpanded] = useState(false);
  const isLong = text.length > TRANSLATED_PREVIEW_CHARS;
  const displayed =
    isLong && !expanded ? text.slice(0, TRANSLATED_PREVIEW_CHARS) : text;

  return (
    <div
      data-ocid="file-audio.translated_preview"
      className="rounded-xl border border-primary/20 bg-primary/5 overflow-hidden"
    >
      <div className="flex items-center gap-2 px-4 py-3 border-b border-primary/15">
        <Globe className="w-4 h-4 text-primary" />
        <span className="text-sm font-semibold text-foreground">
          Translated Text
        </span>
        <span className="text-xs text-muted-foreground ml-auto">Preview</span>
      </div>
      <div className="p-4">
        <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words">
          {displayed}
          {isLong && !expanded && (
            <span className="text-muted-foreground">…</span>
          )}
        </p>
        {isLong && (
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            data-ocid="file-audio.translated_toggle"
            className="mt-3 flex items-center gap-1 text-xs font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-3 h-3" /> Show less
              </>
            ) : (
              <>
                <ChevronDown className="w-3 h-3" /> Show more
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function LanguageSelector({
  value,
  onChange,
}: {
  value: SupportedLanguage;
  onChange: (lang: SupportedLanguage) => void;
}) {
  return (
    <div className="space-y-2">
      <label
        htmlFor="output-language"
        className="flex items-center gap-1.5 text-sm font-semibold text-foreground"
      >
        <Globe className="w-4 h-4 text-primary" />
        Output Language
      </label>
      <div className="relative">
        <select
          id="output-language"
          data-ocid="file-audio.language_select"
          value={value}
          onChange={(e) => onChange(e.target.value as SupportedLanguage)}
          className={[
            "w-full appearance-none rounded-xl border border-input bg-card",
            "px-4 py-2.5 pr-10 text-sm text-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring transition-smooth",
            "cursor-pointer",
          ].join(" ")}
        >
          {SUPPORTED_LANGUAGES.map((lang) => (
            <option key={lang} value={lang}>
              {lang}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
      </div>
    </div>
  );
}

function AudioFormatSelector({
  value,
  onChange,
}: {
  value: AudioFormat;
  onChange: (fmt: AudioFormat) => void;
}) {
  return (
    <div className="space-y-2">
      <label
        htmlFor="output-audio-format"
        className="flex items-center gap-1.5 text-sm font-semibold text-foreground"
      >
        <Music2 className="w-4 h-4 text-primary" />
        Audio Format
      </label>
      <div className="relative">
        <select
          id="output-audio-format"
          data-ocid="file-audio.format_select"
          value={value}
          onChange={(e) => onChange(e.target.value as AudioFormat)}
          className={[
            "w-full appearance-none rounded-xl border border-input bg-card",
            "px-4 py-2.5 pr-10 text-sm text-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring transition-smooth",
            "cursor-pointer",
          ].join(" ")}
        >
          {AUDIO_FORMATS.map((f) => (
            <option key={f.format} value={f.format}>
              {f.label} — {f.description} ({f.bitrate})
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
      </div>
      {/* Selected format detail chips */}
      {(() => {
        const info = AUDIO_FORMATS.find((f) => f.format === value);
        if (!info) return null;
        return (
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={`inline-flex items-center px-2 py-0.5 rounded border text-xs font-semibold ${AUDIO_FORMAT_COLORS[value]}`}
            >
              {info.label}
            </span>
            <span className="text-xs text-muted-foreground font-mono">
              {info.bitrate}
            </span>
            <span className="text-muted-foreground/40 text-xs">·</span>
            <span className="text-xs text-muted-foreground font-mono">
              {info.sampleRate}
            </span>
            <span className="text-muted-foreground/40 text-xs">·</span>
            <span className="text-xs text-muted-foreground">
              {info.description}
            </span>
          </div>
        );
      })()}
    </div>
  );
}

export function AudioFromFileSection() {
  const {
    fileInputText,
    fileName,
    isExtractingFile,
    fileExtractionError,
    isGeneratingAudio,
    selectedVoice,
    selectedFormat,
    currentAudioSection,
    audioError,
    targetLanguage,
    multilingualResult,
    setFileInputText,
    setFileName,
    setIsExtractingFile,
    setFileExtractionError,
    setTargetLanguage,
    setAudioFormat,
    clearFileInput,
    generateMultilingualAudio,
  } = useContentStore();

  const [mode, setMode] = useState<InputMode>("upload");
  const [isDragging, setIsDragging] = useState(false);
  const [fileSizeCache, setFileSizeCache] = useState<number | undefined>();
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);

  // Restore counts from persisted text on first render
  const countsInitialized = useRef(false);
  if (!countsInitialized.current && fileInputText) {
    const words = fileInputText.split(/\s+/).filter((w) => w.length > 0).length;
    setWordCount(words);
    setCharCount(fileInputText.length);
    countsInitialized.current = true;
  }

  const handleFile = useCallback(
    async (file: File) => {
      setIsExtractingFile(true);
      setFileExtractionError(null);
      setFileName(file.name);
      setFileSizeCache(file.size);
      try {
        const { extractTextFromFile } = await import("@/utils/fileExtractor");
        const result = await extractTextFromFile(file);
        setFileInputText(result.text);
        setWordCount(result.wordCount);
        setCharCount(result.charCount);
      } catch (err) {
        const msg =
          err instanceof Error ? err.message : "Failed to extract text.";
        setFileExtractionError(msg);
        setFileName(null);
        setFileSizeCache(undefined);
      } finally {
        setIsExtractingFile(false);
      }
    },
    [
      setIsExtractingFile,
      setFileExtractionError,
      setFileName,
      setFileInputText,
    ],
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setFileInputText(val);
    setWordCount(val.split(/\s+/).filter((w) => w.length > 0).length);
    setCharCount(val.length);
  };

  const handleClear = () => {
    clearFileInput();
    setFileSizeCache(undefined);
    setWordCount(0);
    setCharCount(0);
  };

  const handleGenerateAudio = () => {
    if (!fileInputText.trim()) return;
    const label = fileName ? `File: ${fileName}` : "Typed text";
    generateMultilingualAudio(
      fileInputText.trim(),
      selectedVoice,
      targetLanguage,
      label,
    );
  };

  const isPlayingThis =
    currentAudioSection?.startsWith("File:") ||
    currentAudioSection === "Typed text";

  // Show no-translation notice when detected === target
  const showNoTranslationNote =
    multilingualResult &&
    multilingualResult.detectedLanguage.toLowerCase() ===
      multilingualResult.translatedLanguage.toLowerCase();

  // Show translated preview when translation was performed and text differs from original
  const showTranslatedPreview =
    multilingualResult &&
    !showNoTranslationNote &&
    multilingualResult.translatedText.trim() !== "" &&
    multilingualResult.translatedText.trim() !== fileInputText.trim();

  const fmtInfo = AUDIO_FORMATS.find((f) => f.format === selectedFormat);

  return (
    <div data-ocid="file-audio.section" className="space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Volume2 className="w-6 h-6 text-primary" />
          Audio from File
        </h2>
        <p className="text-muted-foreground text-sm">
          Upload a document or paste text — translate and listen in any language
          and format.
        </p>
      </div>

      {/* Mode toggle */}
      <div
        role="tablist"
        aria-label="Input mode"
        className="flex bg-muted/40 border border-border rounded-xl p-1 w-fit"
      >
        {(["upload", "type"] as const).map((m) => (
          <button
            type="button"
            key={m}
            role="tab"
            aria-selected={mode === m}
            data-ocid={`file-audio.mode_tab.${m}`}
            onClick={() => setMode(m)}
            className={[
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              mode === m
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50",
            ].join(" ")}
          >
            {m === "upload" ? (
              <>
                <Upload className="w-4 h-4" />
                Upload File
              </>
            ) : (
              <>
                <FileText className="w-4 h-4" />
                Type / Paste
              </>
            )}
          </button>
        ))}
      </div>

      {/* Upload mode */}
      {mode === "upload" && (
        <div className="space-y-4">
          {!fileName && !isExtractingFile && (
            <DropZone
              onFile={handleFile}
              isDragging={isDragging}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            />
          )}

          {isExtractingFile && (
            <div
              data-ocid="file-audio.extracting_state"
              className="flex flex-col items-center justify-center gap-4 py-16 rounded-2xl border border-border bg-muted/20"
            >
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
              <p className="text-sm text-muted-foreground font-medium">
                Extracting text from file…
              </p>
            </div>
          )}

          {fileName && !isExtractingFile && (
            <FileInfo
              name={fileName}
              size={fileSizeCache}
              onClear={handleClear}
            />
          )}
        </div>
      )}

      {/* Type/paste mode */}
      {mode === "type" && (
        <div className="space-y-2">
          <div className="relative">
            <textarea
              data-ocid="file-audio.text_input"
              value={fileInputText}
              onChange={handleTextChange}
              placeholder="Paste or type your content here…"
              rows={10}
              className={[
                "w-full rounded-xl border border-input bg-card px-4 py-3 text-sm text-foreground",
                "placeholder:text-muted-foreground resize-y min-h-[200px]",
                "focus:outline-none focus:ring-2 focus:ring-ring transition-smooth",
              ].join(" ")}
            />
            {fileInputText && (
              <button
                type="button"
                onClick={handleClear}
                data-ocid="file-audio.clear_text_button"
                className="absolute top-3 right-3 text-muted-foreground hover:text-destructive transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                aria-label="Clear text"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
            <span>
              {wordCount.toLocaleString()} words · {charCount.toLocaleString()}{" "}
              chars
            </span>
            {charCount > 4000 && (
              <span className="text-primary">
                Long text will be processed in chunks
              </span>
            )}
          </div>
        </div>
      )}

      {/* Extraction error */}
      {fileExtractionError && (
        <Card
          data-ocid="file-audio.error_state"
          className="border-destructive/40 bg-destructive/5"
        >
          <CardContent className="flex items-start gap-3 p-4">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-destructive">
                Extraction failed
              </p>
              <p className="text-sm text-muted-foreground mt-0.5">
                {fileExtractionError}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Text preview — shown when text is available (upload mode or after typing) */}
      {fileInputText && mode === "upload" && !isExtractingFile && (
        <TextPreview
          text={fileInputText}
          wordCount={wordCount}
          charCount={charCount}
        />
      )}

      {/* ── Language + Format Selectors (side by side on larger screens) ── */}
      {(fileInputText || fileName) && !isExtractingFile && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <LanguageSelector
            value={targetLanguage}
            onChange={setTargetLanguage}
          />
          <AudioFormatSelector
            value={selectedFormat}
            onChange={setAudioFormat}
          />
        </div>
      )}

      {/* Detected language badge — shown after processing */}
      {multilingualResult && isPlayingThis && (
        <div
          data-ocid="file-audio.detection_result"
          className="flex flex-wrap items-center gap-3"
        >
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted/60 border border-border text-xs font-medium text-foreground">
            <Globe className="w-3.5 h-3.5 text-primary" />
            Detected:{" "}
            <span className="font-semibold text-primary">
              {multilingualResult.detectedLanguage}
            </span>
          </div>
          {multilingualResult.durationEstimate && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted/60 border border-border text-xs font-medium text-muted-foreground">
              Est. duration:{" "}
              <span className="font-semibold text-foreground">
                {multilingualResult.durationEstimate}
              </span>
            </div>
          )}
          {multilingualResult.audioFormat && (
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold ${AUDIO_FORMAT_COLORS[multilingualResult.audioFormat]}`}
            >
              <Music2 className="w-3 h-3" />
              {AUDIO_FORMATS.find(
                (f) => f.format === multilingualResult.audioFormat,
              )?.label ?? multilingualResult.audioFormat.toUpperCase()}
              {multilingualResult.bitrate && (
                <span className="font-mono opacity-75">
                  · {multilingualResult.bitrate}
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {/* No-translation note */}
      {showNoTranslationNote && isPlayingThis && (
        <div
          data-ocid="file-audio.no_translation_note"
          className="flex items-start gap-2.5 p-3 rounded-xl bg-muted/40 border border-border text-sm text-muted-foreground"
        >
          <Info className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
          <span>
            No translation needed — audio will be in the original language (
            <span className="font-medium text-foreground">
              {multilingualResult?.detectedLanguage}
            </span>
            ).
          </span>
        </div>
      )}

      {/* Translated text preview */}
      {showTranslatedPreview && isPlayingThis && (
        <TranslatedTextPreview text={multilingualResult!.translatedText} />
      )}

      {/* Audio error */}
      {audioError && isPlayingThis && (
        <Card
          data-ocid="file-audio.audio_error_state"
          className="border-destructive/40 bg-destructive/5"
        >
          <CardContent className="flex items-start gap-3 p-4">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-destructive">
                Audio generation failed
              </p>
              <p className="text-sm text-muted-foreground mt-0.5">
                {audioError}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Generate Audio CTA */}
      <Card className="bg-card border border-border shadow-sm">
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1 min-w-0">
              <p className="font-semibold text-foreground">Generate Audio</p>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                <span>
                  Voice:{" "}
                  <span className="text-foreground capitalize font-medium">
                    {selectedVoice}
                  </span>
                </span>
                <span className="text-border hidden sm:inline">·</span>
                <span className="flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-primary" />
                  <span className="text-foreground font-medium">
                    {targetLanguage}
                  </span>
                </span>
                <span className="text-border hidden sm:inline">·</span>
                {/* Format chip in CTA */}
                <span
                  className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border text-xs font-semibold ${AUDIO_FORMAT_COLORS[selectedFormat]}`}
                >
                  <Music2 className="w-3 h-3" />
                  {fmtInfo?.label ?? selectedFormat.toUpperCase()}
                </span>
                {charCount > 4000 && (
                  <>
                    <span className="text-border hidden sm:inline">·</span>
                    <span className="text-primary">
                      Chunked ({Math.ceil(charCount / 4000)} parts)
                    </span>
                  </>
                )}
              </div>
            </div>
            <Button
              type="button"
              size="lg"
              data-ocid="file-audio.generate_button"
              onClick={handleGenerateAudio}
              disabled={
                !fileInputText.trim() || isGeneratingAudio || isExtractingFile
              }
              className="w-full sm:w-auto gap-2 flex-shrink-0"
            >
              {isGeneratingAudio && isPlayingThis ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {targetLanguage !== "English"
                    ? "Translating & generating…"
                    : "Generating…"}
                </>
              ) : multilingualResult && isPlayingThis ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />🔊 Listen Again
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  Generate {fmtInfo?.label ?? selectedFormat.toUpperCase()}{" "}
                  Audio
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
