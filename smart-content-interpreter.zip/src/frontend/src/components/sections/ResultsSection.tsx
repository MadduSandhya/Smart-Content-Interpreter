import { ListenButton } from "@/components/audio/ListenButton";
import { HighlightedText } from "@/components/ui/HighlightedText";
import { KeywordBadge } from "@/components/ui/KeywordBadge";
import { SummaryPanel } from "@/components/ui/SummaryPanel";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
/**
 * ResultsSection — main output area shown only when a SimplificationResult exists.
 * Provides split-view toggle (Original | Simplified | Split),
 * keyword panel, summary tabs, download + copy actions.
 */
import { cn } from "@/lib/utils";
import { explainTerm } from "@/services/api";
import { useContentStore } from "@/store/useContentStore";
import type { ActiveView, SummaryLength } from "@/types";
import type { Summary } from "@/types";
import {
  Columns2,
  Copy,
  Download,
  FileText,
  Sparkles,
  Tag,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useRef } from "react";
import { toast } from "sonner";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildAllSummaries(summary: Summary): Record<SummaryLength, Summary> {
  // For each length, vary bullet count slightly to simulate real content
  const makeSummary = (length: SummaryLength): Summary => {
    const count =
      length === "short"
        ? 3
        : length === "medium"
          ? 5
          : summary.bullets.length || 8;
    return {
      ...summary,
      length,
      bullets: summary.bullets.slice(0, count),
    };
  };
  return {
    short: makeSummary("short"),
    medium: makeSummary("medium"),
    detailed: makeSummary("detailed"),
  };
}

function buildDownloadText(
  original: string,
  simplified: string,
  summary: Summary,
  readingLevel: string,
): string {
  const date = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const bullets = summary.bullets.map((b) => `  • ${b}`).join("\n");
  const levelLabel =
    readingLevel.charAt(0).toUpperCase() + readingLevel.slice(1);
  return [
    "Smart Content Interpreter — Export",
    `Date: ${date}`,
    `Reading Level: ${levelLabel}`,
    "",
    "─── SIMPLIFIED CONTENT ───────────────────────────",
    simplified,
    "",
    "─── SUMMARY ──────────────────────────────────────",
    bullets,
    "",
    summary.paragraph,
    "",
    "─── ORIGINAL CONTENT ─────────────────────────────",
    original,
  ].join("\n");
}

// ─── Panel Component ──────────────────────────────────────────────────────────

interface ContentPanelProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  headerClass?: string;
  action?: React.ReactNode;
}

function ContentPanel({
  title,
  icon,
  children,
  className,
  headerClass,
  action,
}: ContentPanelProps) {
  return (
    <div
      className={cn(
        "flex flex-col rounded-xl border border-border bg-card overflow-hidden h-full",
        className,
      )}
    >
      <div
        className={cn(
          "flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40",
          headerClass,
        )}
      >
        {icon}
        <span className="font-display font-semibold text-sm text-foreground flex-1">
          {title}
        </span>
        {action && <div className="ml-auto">{action}</div>}
      </div>
      <div className="flex-1 overflow-y-auto p-4">{children}</div>
    </div>
  );
}

// ─── View Toggle ──────────────────────────────────────────────────────────────

const VIEW_OPTIONS: {
  value: ActiveView;
  label: string;
  icon: React.ReactNode;
}[] = [
  {
    value: "original",
    label: "Original",
    icon: <FileText className="size-3.5" />,
  },
  { value: "split", label: "Split", icon: <Columns2 className="size-3.5" /> },
  {
    value: "simplified",
    label: "Simplified",
    icon: <Sparkles className="size-3.5" />,
  },
];

interface ViewToggleProps {
  activeView: ActiveView;
  onViewChange: (v: ActiveView) => void;
}

function ViewToggle({ activeView, onViewChange }: ViewToggleProps) {
  return (
    <Tabs
      value={activeView}
      onValueChange={(v) => onViewChange(v as ActiveView)}
      data-ocid="results.view_toggle"
    >
      <TabsList>
        {VIEW_OPTIONS.map(({ value, label, icon }) => (
          <TabsTrigger
            key={value}
            value={value}
            className="flex items-center gap-1.5 px-3"
            data-ocid={`results.view.${value}.tab`}
          >
            {icon}
            <span className="hidden sm:inline">{label}</span>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function ResultsSection() {
  const { result, activeView, setActiveView, selectedReadingLevel } =
    useContentStore();
  const copiedRef = useRef(false);

  const handleExplain = useCallback(async (term: string): Promise<string> => {
    return explainTerm(term);
  }, []);

  if (!result) return null;

  const {
    original,
    simplified,
    summary,
    keywords,
    difficultTerms,
    readingLevel,
  } = result;
  const allSummaries = buildAllSummaries(summary);

  // ── Copy to clipboard ──
  async function handleCopy() {
    if (copiedRef.current) return;
    copiedRef.current = true;
    await navigator.clipboard.writeText(simplified);
    toast.success("Copied to clipboard!", {
      description: "Simplified content has been copied.",
      duration: 3000,
    });
    setTimeout(() => {
      copiedRef.current = false;
    }, 3000);
  }

  // ── Download .txt ──
  function handleDownload() {
    const content = buildDownloadText(
      original,
      simplified,
      summary,
      readingLevel ?? selectedReadingLevel,
    );
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `smart-content-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Download started", {
      description: "Your .txt file is downloading.",
    });
  }

  const showOriginal = activeView === "original" || activeView === "split";
  const showSimplified = activeView === "simplified" || activeView === "split";

  return (
    <AnimatePresence>
      <motion.section
        initial={{ opacity: 0, y: 32 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 16 }}
        transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
        className="w-full space-y-6"
        data-ocid="results.section"
        aria-label="Results"
      >
        {/* ── Header bar ── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="size-5 text-accent" aria-hidden />
            <h2 className="font-display text-xl font-semibold text-foreground">
              Analysis Results
            </h2>
            {result.processingTimeMs && (
              <span className="text-xs text-muted-foreground hidden sm:inline">
                · {(result.processingTimeMs / 1000).toFixed(1)}s
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <ViewToggle activeView={activeView} onViewChange={setActiveView} />

            <Button
              variant="outline"
              size="sm"
              onClick={handleCopy}
              className="gap-1.5"
              data-ocid="results.copy_button"
              aria-label="Copy simplified content to clipboard"
            >
              <Copy className="size-3.5" />
              <span className="hidden sm:inline">Copy</span>
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              className="gap-1.5"
              data-ocid="results.download_button"
              aria-label="Download results as .txt"
            >
              <Download className="size-3.5" />
              <span className="hidden sm:inline">Download</span>
            </Button>
          </div>
        </div>

        {/* ── Content panels ── */}
        <motion.div
          layout
          className={cn(
            "grid gap-4 transition-content",
            activeView === "split"
              ? "grid-cols-1 md:grid-cols-2"
              : "grid-cols-1",
          )}
          style={{ minHeight: "320px" }}
        >
          <AnimatePresence mode="popLayout">
            {showOriginal && (
              <motion.div
                key="original-panel"
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.3 }}
                className="h-full"
                data-ocid="results.original_panel"
              >
                <ContentPanel
                  title="Original Content"
                  icon={
                    <FileText
                      className="size-4 text-muted-foreground"
                      aria-hidden
                    />
                  }
                  className="min-h-[280px]"
                >
                  <HighlightedText
                    text={original}
                    difficultTerms={difficultTerms}
                    onExplain={handleExplain}
                  />
                </ContentPanel>
              </motion.div>
            )}

            {showSimplified && (
              <motion.div
                key="simplified-panel"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 16 }}
                transition={{ duration: 0.3 }}
                className="h-full"
                data-ocid="results.simplified_panel"
              >
                <ContentPanel
                  title="Simplified Content"
                  icon={<Sparkles className="size-4 text-accent" aria-hidden />}
                  headerClass="bg-accent/10 border-accent/20"
                  action={
                    <ListenButton text={simplified} label="Simplified Text" />
                  }
                >
                  <p
                    className="text-sm leading-relaxed text-foreground font-body whitespace-pre-line"
                    data-ocid="results.simplified_text"
                  >
                    {simplified}
                  </p>
                </ContentPanel>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ── Keywords panel ── */}
        {keywords.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="rounded-xl border border-border bg-card p-4 space-y-3"
            data-ocid="results.keywords_panel"
          >
            <div className="flex items-center gap-2">
              <Tag className="size-4 text-accent" aria-hidden />
              <h3 className="font-display font-semibold text-sm text-foreground uppercase tracking-wide">
                Keywords
              </h3>
              <span className="text-xs text-muted-foreground ml-1">
                ({keywords.length})
              </span>
            </div>
            <ul
              className="flex flex-wrap gap-2 list-none"
              data-ocid="results.keywords_list"
              aria-label="Extracted keywords"
            >
              {keywords.map((kw, i) => (
                <li key={kw.word}>
                  <KeywordBadge
                    keyword={kw}
                    data-ocid={`results.keyword.${i + 1}`}
                  />
                </li>
              ))}
            </ul>
          </motion.div>
        )}

        {/* ── Summary panel ── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }}
          className="space-y-2"
        >
          <SummaryPanel
            summaries={allSummaries}
            defaultLength={summary.length}
          />
          <div
            className="flex items-center gap-2 px-1"
            aria-label="Listen to summaries"
          >
            <span className="text-xs text-muted-foreground">Listen to:</span>
            <ListenButton
              text={allSummaries.short.bullets.join(". ")}
              label="Short Summary"
            />
            <ListenButton
              text={allSummaries.detailed.paragraph}
              label="Detailed Summary"
            />
          </div>
        </motion.div>

        {/* ── Quick copy confirmation (accessibility) ── */}
        <output
          aria-live="polite"
          aria-atomic="true"
          className="sr-only"
          data-ocid="results.copy_status"
        >
          {/* Updated by sonner toast — screen reader fallback */}
        </output>
      </motion.section>
    </AnimatePresence>
  );
}
