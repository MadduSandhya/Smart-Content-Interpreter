/**
 * VideoSummarizerSection — YouTube video summarization tab.
 * Handles URL input, validation, video player embed, metadata display,
 * AI-generated summaries, key points, topics, and clickable timestamps.
 */

import { ListenButton } from "@/components/audio/ListenButton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { extractVideoId, formatDuration } from "@/services/api";
import { useContentStore } from "@/store/useContentStore";
import type { TimestampSegment, VideoSummaryResult } from "@/types";
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  Clock,
  ExternalLink,
  Hash,
  Loader2,
  Play,
  Sparkles,
  Tag,
  X,
  Youtube,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useRef, useState } from "react";

// ─── URL Validation ───────────────────────────────────────────────────────────

function isValidYouTubeUrl(url: string): boolean {
  return extractVideoId(url) !== null;
}

// ─── Video Skeleton ───────────────────────────────────────────────────────────

function VideoResultSkeleton() {
  return (
    <div data-ocid="video.loading_state" className="space-y-6">
      {/* Metadata card skeleton */}
      <div className="bg-card border border-border rounded-2xl p-5 flex gap-4">
        <Skeleton className="w-32 h-20 rounded-lg shrink-0" />
        <div className="flex-1 space-y-2.5">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/2" />
          <Skeleton className="h-5 w-20 rounded-full" />
        </div>
      </div>
      {/* Player skeleton */}
      <Skeleton className="w-full aspect-video rounded-xl" />
      {/* Summary skeleton */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
        <Skeleton className="h-4 w-28" />
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-5/6" />
        <Skeleton className="h-3 w-4/5" />
      </div>
      {/* Timestamps skeleton */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
        <Skeleton className="h-4 w-36" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-14 rounded-xl" />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Video Metadata Card ──────────────────────────────────────────────────────

interface VideoMetadataCardProps {
  result: VideoSummaryResult;
}

function VideoMetadataCard({ result }: VideoMetadataCardProps) {
  const { metadata } = result;
  const duration = formatDuration(metadata.durationSeconds);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card border border-border rounded-2xl overflow-hidden"
      data-ocid="video.metadata.card"
    >
      <div className="flex flex-col sm:flex-row gap-0">
        {/* Thumbnail */}
        <div className="relative w-full sm:w-48 h-32 sm:h-auto shrink-0 bg-muted overflow-hidden">
          <img
            src={metadata.thumbnailUrl}
            alt={metadata.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                `https://img.youtube.com/vi/${metadata.videoId}/hqdefault.jpg`;
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          <div className="absolute bottom-2 right-2">
            <Badge
              variant="secondary"
              className="bg-foreground/70 text-background border-0 text-xs font-mono gap-1"
            >
              <Clock className="w-3 h-3" />
              {duration}
            </Badge>
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col justify-between p-4 sm:p-5 flex-1 min-w-0">
          <div className="space-y-1.5">
            <h3 className="font-display font-semibold text-foreground text-sm sm:text-base leading-snug line-clamp-2">
              {metadata.title}
            </h3>
            <p className="text-sm text-muted-foreground flex items-center gap-1.5 min-w-0">
              <Youtube className="w-3.5 h-3.5 shrink-0 text-destructive" />
              <span className="truncate">{metadata.channelName}</span>
            </p>
          </div>

          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <Badge
              variant="outline"
              className="text-xs gap-1 border-primary/30 text-primary"
            >
              <CheckCircle2 className="w-3 h-3" />
              AI Summarized
            </Badge>
            <a
              href={`https://www.youtube.com/watch?v=${metadata.videoId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 ml-auto"
              data-ocid="video.metadata.link"
            >
              <ExternalLink className="w-3 h-3" />
              View on YouTube
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── YouTube Player ───────────────────────────────────────────────────────────

interface YouTubePlayerProps {
  videoId: string;
  iframeRef: React.RefObject<HTMLIFrameElement | null>;
}

function YouTubePlayer({ videoId, iframeRef }: YouTubePlayerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay: 0.1, ease: [0.4, 0, 0.2, 1] }}
      className="relative w-full rounded-xl overflow-hidden border border-border shadow-sm bg-black"
      style={{ aspectRatio: "16/9" }}
      data-ocid="video.player"
    >
      <iframe
        ref={iframeRef}
        src={`https://www.youtube-nocookie.com/embed/${videoId}?enablejsapi=1&rel=0&modestbranding=1`}
        title="YouTube video player"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
        className="absolute inset-0 w-full h-full"
      />
    </motion.div>
  );
}

// ─── Summary Panel ────────────────────────────────────────────────────────────

interface SummaryPanelProps {
  result: VideoSummaryResult;
}

function SummaryPanel({ result }: SummaryPanelProps) {
  const [summaryTab, setSummaryTab] = useState<"short" | "detailed">("short");

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card border border-border rounded-2xl overflow-hidden"
      data-ocid="video.summary.card"
    >
      {/* Header with tab toggle */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
            <BookOpen className="w-3.5 h-3.5 text-primary" />
          </div>
          <h3 className="font-display font-semibold text-sm text-foreground">
            Summary
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <div
            role="radiogroup"
            aria-label="Summary type"
            className="flex bg-muted/50 border border-border rounded-lg overflow-hidden h-8"
          >
            {(["short", "detailed"] as const).map((tab, idx) => (
              <button
                type="button"
                key={tab}
                aria-pressed={summaryTab === tab}
                onClick={() => setSummaryTab(tab)}
                data-ocid={`video.summary.${tab}_tab`}
                className={[
                  "px-3 text-xs font-medium transition-smooth focus-visible:outline-none",
                  idx > 0 ? "border-l border-border" : "",
                  summaryTab === tab
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                ].join(" ")}
              >
                {tab === "short" ? "Short" : "Detailed"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary content */}
      <div className="px-5 py-4">
        <AnimatePresence mode="wait">
          {summaryTab === "short" ? (
            <motion.div
              key="short"
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 8 }}
              transition={{ duration: 0.2 }}
            >
              {(() => {
                const bullets = result.summaryShort.includes("• ")
                  ? result.summaryShort.split("• ").filter(Boolean)
                  : result.summaryShort
                      .split(". ")
                      .map((s) => s.trim())
                      .filter(Boolean);
                return (
                  <ul className="space-y-2">
                    {bullets.map((bullet) => (
                      <li
                        key={bullet.slice(0, 40)}
                        className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed"
                      >
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        {bullet.endsWith(".") ? bullet : `${bullet}.`}
                      </li>
                    ))}
                  </ul>
                );
              })()}
              <div className="mt-3 pt-3 border-t border-border/50">
                <ListenButton
                  text={result.summaryShort}
                  label="Video Summary"
                />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="detailed"
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 8 }}
              transition={{ duration: 0.2 }}
            >
              <p className="text-sm text-foreground leading-relaxed">
                {result.summaryDetailed}
              </p>
              <div className="mt-3 pt-3 border-t border-border/50">
                <ListenButton
                  text={result.summaryDetailed}
                  label="Detailed Video Summary"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ─── Key Points Panel ─────────────────────────────────────────────────────────

interface KeyPointsPanelProps {
  keyPoints: string[];
}

function KeyPointsPanel({ keyPoints }: KeyPointsPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: 0.2, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card border border-border rounded-2xl overflow-hidden"
      data-ocid="video.keypoints.card"
    >
      <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
        <div className="w-7 h-7 rounded-lg bg-accent/10 flex items-center justify-center">
          <Sparkles className="w-3.5 h-3.5 text-accent" />
        </div>
        <h3 className="font-display font-semibold text-sm text-foreground">
          Key Points
        </h3>
        <Badge variant="secondary" className="ml-auto text-xs">
          {keyPoints.length}
        </Badge>
        <ListenButton
          text={keyPoints.join(". ")}
          label="Key Points"
          className="ml-1"
        />
      </div>

      <ul className="px-5 py-4 space-y-2.5">
        {keyPoints.map((point, idx) => (
          <motion.li
            key={point.slice(0, 40)}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.25, delay: idx * 0.05 }}
            data-ocid={`video.keypoints.item.${idx + 1}`}
            className="rounded-lg border border-border bg-card p-3 text-sm text-foreground leading-relaxed list-none"
          >
            {point}
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
}

// ─── Topics Panel ─────────────────────────────────────────────────────────────

interface TopicsPanelProps {
  topics: string[];
}

function TopicsPanel({ topics }: TopicsPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: 0.25, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card border border-border rounded-2xl p-5"
      data-ocid="video.topics.card"
    >
      <div className="flex items-center gap-2 mb-3.5">
        <div className="w-7 h-7 rounded-lg bg-secondary/20 flex items-center justify-center">
          <Hash className="w-3.5 h-3.5 text-secondary" />
        </div>
        <h3 className="font-display font-semibold text-sm text-foreground">
          Topics Covered
        </h3>
      </div>

      <div className="flex flex-wrap gap-2">
        {topics.map((topic) => (
          <Badge
            key={topic}
            variant="secondary"
            data-ocid="video.topics.tag"
            className="text-xs gap-1.5 border border-border bg-muted/50 hover:bg-muted transition-colors cursor-default"
          >
            <Tag className="w-2.5 h-2.5" />
            {topic}
          </Badge>
        ))}
      </div>
    </motion.div>
  );
}

// ─── Timestamp Segments Panel ─────────────────────────────────────────────────

interface TimestampsPanelProps {
  segments: TimestampSegment[];
  iframeRef: React.RefObject<HTMLIFrameElement | null>;
}

function TimestampsPanel({ segments, iframeRef }: TimestampsPanelProps) {
  const [activeSegment, setActiveSegment] = useState<number | null>(null);

  const seekTo = useCallback(
    (seconds: number, idx: number) => {
      setActiveSegment(idx);
      if (iframeRef.current?.contentWindow) {
        const msg = JSON.stringify({
          event: "command",
          func: "seekTo",
          args: [seconds, true],
        });
        iframeRef.current.contentWindow.postMessage(
          msg,
          "https://www.youtube-nocookie.com",
        );
        // Scroll iframe into view
        iframeRef.current.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }
    },
    [iframeRef],
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: 0.3, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card border border-border rounded-2xl overflow-hidden"
      data-ocid="video.timestamps.card"
    >
      <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
        <div className="w-7 h-7 rounded-lg bg-chart-1/15 flex items-center justify-center">
          <Clock className="w-3.5 h-3.5 text-chart-1" />
        </div>
        <h3 className="font-display font-semibold text-sm text-foreground">
          Timestamp Segments
        </h3>
        <span className="ml-auto text-xs text-muted-foreground">
          Click to jump to section
        </span>
      </div>

      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
        {segments.map((seg, idx) => (
          <motion.button
            type="button"
            key={`${seg.timeSeconds}-${seg.keyPoint.slice(0, 20)}`}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: idx * 0.04 }}
            onClick={() => seekTo(seg.timeSeconds, idx)}
            data-ocid={`video.timestamps.item.${idx + 1}`}
            className={[
              "group text-left flex items-center gap-3 px-3.5 py-3 rounded-xl border transition-smooth",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              activeSegment === idx
                ? "border-accent bg-accent/10 text-foreground"
                : "border-border bg-background hover:border-accent/50 hover:bg-accent/5 text-foreground",
            ].join(" ")}
          >
            {/* Time badge */}
            <span
              className={[
                "font-mono text-xs font-semibold shrink-0 px-2 py-1 rounded-md border transition-smooth",
                activeSegment === idx
                  ? "bg-accent text-accent-foreground border-accent"
                  : "bg-muted/50 text-muted-foreground border-border group-hover:bg-accent/10 group-hover:text-accent group-hover:border-accent/40",
              ].join(" ")}
            >
              {seg.timeFormatted}
            </span>

            {/* Point text */}
            <span className="text-xs leading-snug line-clamp-2 flex-1 min-w-0">
              {seg.keyPoint}
            </span>

            {/* Play icon hint */}
            <Play
              className={[
                "w-3.5 h-3.5 shrink-0 transition-smooth",
                activeSegment === idx
                  ? "text-accent"
                  : "text-muted-foreground/40 group-hover:text-accent/60",
              ].join(" ")}
              fill="currentColor"
            />
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function VideoSummarizerSection() {
  const {
    videoUrl,
    videoResult,
    isProcessingVideo,
    videoError,
    setVideoUrl,
    setVideoError,
    processVideo,
  } = useContentStore();

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const [inputError, setInputError] = useState<string | null>(null);

  const handleUrlChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setVideoUrl(val);
      if (inputError) setInputError(null);
      if (videoError) setVideoError(null);
    },
    [inputError, videoError, setVideoUrl, setVideoError],
  );

  const handleAnalyze = useCallback(async () => {
    if (!videoUrl.trim()) {
      setInputError("Please paste a YouTube URL to get started.");
      return;
    }
    if (!isValidYouTubeUrl(videoUrl)) {
      setInputError(
        "That doesn't look like a valid YouTube link. Try a format like youtube.com/watch?v=… or youtu.be/…",
      );
      return;
    }
    setInputError(null);
    await processVideo();
  }, [videoUrl, processVideo]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Enter" && !isProcessingVideo) {
        handleAnalyze();
      }
    },
    [handleAnalyze, isProcessingVideo],
  );

  const handleClearUrl = useCallback(() => {
    setVideoUrl("");
    setInputError(null);
    setVideoError(null);
  }, [setVideoUrl, setVideoError]);

  const displayError = inputError ?? videoError;

  return (
    <section data-ocid="video.section" className="w-full space-y-6">
      {/* ── URL Input Card ── */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
        className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden"
      >
        {/* Card header */}
        <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-destructive/10 flex items-center justify-center">
            <Youtube className="w-4 h-4 text-destructive" />
          </div>
          <h2 className="font-display font-semibold text-foreground text-sm">
            Video Summarizer
          </h2>
          <Badge variant="secondary" className="ml-2 text-xs">
            AI-Powered
          </Badge>
        </div>

        {/* URL input row */}
        <div className="px-5 py-4">
          <label
            htmlFor="video-url-input"
            className="block text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2"
          >
            YouTube URL
          </label>
          <div className="flex gap-2.5">
            <div className="relative flex-1 min-w-0">
              <input
                id="video-url-input"
                type="url"
                value={videoUrl}
                onChange={handleUrlChange}
                onKeyDown={handleKeyDown}
                placeholder="https://www.youtube.com/watch?v=…"
                disabled={isProcessingVideo}
                data-ocid="video.url.input"
                className={[
                  "w-full h-10 px-3.5 pr-9 rounded-lg border bg-background text-sm text-foreground",
                  "placeholder:text-muted-foreground/60 focus-visible:outline-none",
                  "focus-visible:ring-2 focus-visible:ring-ring transition-smooth",
                  displayError ? "border-destructive" : "border-input",
                  isProcessingVideo ? "opacity-60 cursor-not-allowed" : "",
                ].join(" ")}
              />
              {videoUrl && (
                <button
                  type="button"
                  onClick={handleClearUrl}
                  aria-label="Clear URL"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground/60 hover:text-foreground transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <Button
              onClick={handleAnalyze}
              disabled={isProcessingVideo || !videoUrl.trim()}
              data-ocid="video.analyze_button"
              className="gap-2 shrink-0 transition-smooth"
            >
              {isProcessingVideo ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="hidden sm:inline">Analyzing…</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span className="hidden sm:inline">Analyze Video</span>
                  <span className="sm:hidden">Analyze</span>
                </>
              )}
            </Button>
          </div>

          {/* Hint text */}
          {!displayError && !isProcessingVideo && (
            <p className="mt-2 text-xs text-muted-foreground">
              Supports youtube.com/watch?v=… and youtu.be/… links
            </p>
          )}
        </div>

        {/* Error state */}
        <AnimatePresence>
          {displayError && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div
                data-ocid="video.error_state"
                className="flex items-start gap-3 px-5 py-3 border-t border-destructive/20 bg-destructive/5"
              >
                <AlertCircle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
                <p className="text-sm text-destructive leading-snug flex-1">
                  {displayError}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setInputError(null);
                    setVideoError(null);
                  }}
                  className="ml-auto shrink-0 text-destructive/60 hover:text-destructive transition-colors"
                  aria-label="Dismiss error"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading progress indicator */}
        <AnimatePresence>
          {isProcessingVideo && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="px-5 py-3 border-t border-border bg-muted/20 flex items-center gap-3"
              data-ocid="video.loading_state"
            >
              <Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" />
              <div className="flex-1 space-y-0.5">
                <p className="text-xs font-medium text-foreground">
                  Extracting transcript and generating summary…
                </p>
                <p className="text-xs text-muted-foreground">
                  This usually takes 10–30 seconds
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ── Results ── */}
      <AnimatePresence mode="wait">
        {isProcessingVideo ? (
          <motion.div
            key="skeleton"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <VideoResultSkeleton />
          </motion.div>
        ) : videoResult ? (
          <motion.div
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-5"
            data-ocid="video.results.section"
          >
            {/* Metadata */}
            <VideoMetadataCard result={videoResult} />

            {/* Player */}
            <YouTubePlayer
              videoId={videoResult.videoId}
              iframeRef={iframeRef}
            />

            {/* Summary */}
            <SummaryPanel result={videoResult} />

            {/* Two-column on desktop: key points + topics */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              <div className="lg:col-span-2">
                <KeyPointsPanel keyPoints={videoResult.keyPoints} />
              </div>
              <div>
                <TopicsPanel topics={videoResult.topics} />
              </div>
            </div>

            {/* Timestamps */}
            <TimestampsPanel
              segments={videoResult.segments}
              iframeRef={iframeRef}
            />
          </motion.div>
        ) : !videoError ? (
          /* Empty state on first load */
          <motion.div
            key="empty"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            data-ocid="video.empty_state"
            className="flex flex-col items-center justify-center py-16 px-4 text-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mb-4 glow-accent">
              <Youtube className="w-8 h-8 text-destructive" strokeWidth={1.5} />
            </div>
            <h3 className="font-display font-semibold text-foreground text-lg mb-2">
              Paste a YouTube link to begin
            </h3>
            <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
              Get an AI-generated summary, key insights, topic breakdown, and
              clickable timestamps — all from any YouTube video with captions.
            </p>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </section>
  );
}
