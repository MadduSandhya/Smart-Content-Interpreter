/**
 * InputSection — primary content input panel.
 * Handles text entry, TXT file drag-and-drop, reading level + summary
 * length controls, and triggers the AI processing pipeline.
 */

import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { processText } from "@/services/api";
import { useContentStore } from "@/store/useContentStore";
import type { ReadingLevel, SummaryLength } from "@/types";
import {
  AlertCircle,
  FileText,
  Loader2,
  RotateCcw,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useRef, useState } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const MAX_CHARS = 10_000;

const READING_LEVELS: { value: ReadingLevel; label: string; desc: string }[] = [
  {
    value: "beginner",
    label: "Beginner",
    desc: "Simple, everyday language",
  },
  {
    value: "intermediate",
    label: "Intermediate",
    desc: "Some technical context preserved",
  },
  {
    value: "advanced",
    label: "Advanced",
    desc: "Full domain terminology retained",
  },
];

const SUMMARY_LENGTHS: { value: SummaryLength; label: string }[] = [
  { value: "short", label: "Short" },
  { value: "medium", label: "Medium" },
  { value: "detailed", label: "Detailed" },
];

const PLACEHOLDER = `Paste complex text here — academic papers, legal contracts, medical reports, technical documentation, or any content you want to simplify...

You can also drag and drop a .txt file anywhere in this area.`;

// ─── Component ────────────────────────────────────────────────────────────────

export function InputSection() {
  const {
    inputText,
    isProcessing,
    error,
    selectedReadingLevel,
    selectedSummaryLength,
    setInputText,
    setReadingLevel,
    setSummaryLength,
    setProcessing,
    setResult,
    setError,
    reset,
  } = useContentStore();

  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const charCount = inputText.length;
  const isOverLimit = charCount > MAX_CHARS;
  const canProcess =
    inputText.trim().length >= 20 && !isProcessing && !isOverLimit;

  // ─── File handling ──────────────────────────────────────────────────────────

  const readFile = useCallback(
    (file: File) => {
      if (!file.name.endsWith(".txt") && file.type !== "text/plain") {
        setError("Only .txt files are supported for upload.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result;
        if (typeof content === "string") {
          setInputText(content.slice(0, MAX_CHARS));
          setError(null);
          textareaRef.current?.focus();
        }
      };
      reader.onerror = () => setError("Failed to read file. Please try again.");
      reader.readAsText(file);
    },
    [setInputText, setError],
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) readFile(file);
    },
    [readFile],
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) readFile(file);
      // Reset so same file can be re-uploaded
      e.target.value = "";
    },
    [readFile],
  );

  // ─── Process ────────────────────────────────────────────────────────────────

  const handleProcess = useCallback(async () => {
    if (!canProcess) return;
    setProcessing(true);
    setError(null);
    try {
      const result = await processText({
        text: inputText,
        readingLevel: selectedReadingLevel,
        summaryLength: selectedSummaryLength,
      });
      setResult(result);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "An unexpected error occurred.";
      setError(msg);
      setResult(null);
    } finally {
      setProcessing(false);
    }
  }, [
    canProcess,
    inputText,
    selectedReadingLevel,
    selectedSummaryLength,
    setError,
    setProcessing,
    setResult,
  ]);

  const handleClear = useCallback(() => {
    reset();
  }, [reset]);

  // ─── Render ─────────────────────────────────────────────────────────────────

  return (
    <section data-ocid="input.section" className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
        className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden"
      >
        {/* ── Card header ── */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="w-4 h-4 text-primary" />
            </div>
            <h2 className="font-display font-semibold text-foreground text-sm">
              Input Content
            </h2>
          </div>

          {inputText.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              data-ocid="input.clear_button"
              className="text-muted-foreground hover:text-foreground transition-colors gap-1.5 h-8 px-2.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="text-xs">Clear</span>
            </Button>
          )}
        </div>

        {/* ── Textarea + drag zone ── */}
        <div
          className={[
            "relative transition-smooth",
            isDragging ? "ring-2 ring-inset ring-primary bg-primary/5" : "",
          ].join(" ")}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Textarea
            ref={textareaRef}
            data-ocid="input.textarea"
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value);
              if (error) setError(null);
            }}
            placeholder={PLACEHOLDER}
            disabled={isProcessing}
            className={[
              "min-h-[220px] resize-none border-0 rounded-none focus-visible:ring-0",
              "bg-transparent text-foreground placeholder:text-muted-foreground/60",
              "text-sm leading-relaxed px-5 py-4",
              "transition-smooth",
              isProcessing ? "opacity-60 cursor-not-allowed" : "",
            ].join(" ")}
            maxLength={MAX_CHARS + 500}
          />

          {/* Drag overlay */}
          <AnimatePresence>
            {isDragging && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center gap-3 pointer-events-none"
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/15 border-2 border-dashed border-primary/50 flex items-center justify-center">
                  <Upload className="w-6 h-6 text-primary" />
                </div>
                <p className="text-sm font-medium text-primary">
                  Drop your .txt file here
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ── Footer bar: char count + upload ── */}
        <div className="flex items-center justify-between px-5 py-2.5 border-t border-border bg-muted/30">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            data-ocid="input.upload_button"
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
            disabled={isProcessing}
          >
            <Upload className="w-3.5 h-3.5" />
            Upload .txt file
          </button>

          <span
            className={[
              "text-xs font-mono transition-colors",
              isOverLimit
                ? "text-destructive font-semibold"
                : charCount > MAX_CHARS * 0.85
                  ? "text-chart-5"
                  : "text-muted-foreground",
            ].join(" ")}
          >
            {charCount.toLocaleString()} / {MAX_CHARS.toLocaleString()}
          </span>

          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,text/plain"
            className="hidden"
            onChange={handleFileInput}
            tabIndex={-1}
          />
        </div>

        {/* ── Controls: reading level + summary length ── */}
        <div className="px-5 py-4 border-t border-border bg-muted/20 flex flex-col gap-4 sm:flex-row sm:items-end sm:gap-6">
          {/* Reading level */}
          <div className="flex-1 min-w-0 flex flex-col gap-1.5">
            <label
              htmlFor="reading-level-trigger"
              className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
            >
              Reading Level
            </label>
            <Select
              value={selectedReadingLevel}
              onValueChange={(v) => setReadingLevel(v as ReadingLevel)}
              disabled={isProcessing}
            >
              <SelectTrigger
                id="reading-level-trigger"
                data-ocid="input.reading_level.select"
                className="h-9 bg-background border-input text-sm"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {READING_LEVELS.map((lvl) => (
                  <SelectItem
                    key={lvl.value}
                    value={lvl.value}
                    data-ocid={`input.reading_level.${lvl.value}`}
                  >
                    <span className="font-medium">{lvl.label}</span>
                    <span className="text-muted-foreground ml-2 text-xs hidden sm:inline">
                      — {lvl.desc}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Summary length segmented control */}
          <div className="flex flex-col gap-1.5">
            <span
              id="summary-length-label"
              className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
            >
              Summary Length
            </span>
            <div
              role="radiogroup"
              aria-labelledby="summary-length-label"
              className="flex bg-background border border-input rounded-lg overflow-hidden h-9"
            >
              {SUMMARY_LENGTHS.map((len, idx) => (
                <button
                  type="button"
                  key={len.value}
                  aria-pressed={selectedSummaryLength === len.value}
                  onClick={() => setSummaryLength(len.value)}
                  disabled={isProcessing}
                  data-ocid={`input.summary_length.${len.value}`}
                  className={[
                    "flex-1 px-4 text-sm font-medium transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring",
                    idx > 0 ? "border-l border-input" : "",
                    selectedSummaryLength === len.value
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50",
                    isProcessing
                      ? "opacity-50 cursor-not-allowed"
                      : "cursor-pointer",
                  ].join(" ")}
                >
                  {len.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ── Error state ── */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div
                data-ocid="input.error_state"
                className="flex items-start gap-3 px-5 py-3 border-t border-destructive/20 bg-destructive/5"
              >
                <AlertCircle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
                <p className="text-sm text-destructive leading-snug">{error}</p>
                <button
                  type="button"
                  onClick={() => setError(null)}
                  className="ml-auto shrink-0 text-destructive/60 hover:text-destructive transition-colors"
                  aria-label="Dismiss error"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── Action row ── */}
        <div className="px-5 py-4 border-t border-border flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground hidden sm:block">
            {canProcess
              ? `${inputText.trim().split(/\s+/).length.toLocaleString()} words ready to process`
              : inputText.trim().length === 0
                ? "Paste or upload content to get started"
                : inputText.trim().length < 20
                  ? "Add a bit more text for meaningful analysis"
                  : isOverLimit
                    ? "Text exceeds character limit"
                    : ""}
          </p>

          <div className="flex items-center gap-2 ml-auto">
            {/* Loading indicator */}
            <AnimatePresence>
              {isProcessing && (
                <motion.div
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  data-ocid="input.loading_state"
                  className="flex items-center gap-2 text-xs text-muted-foreground"
                >
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Analysing…</span>
                </motion.div>
              )}
            </AnimatePresence>

            <Button
              onClick={handleProcess}
              disabled={!canProcess}
              data-ocid="input.primary_button"
              className={[
                "gap-2 font-medium transition-smooth",
                isProcessing ? "opacity-80" : "",
              ].join(" ")}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processing…
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Interpret Content
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
