import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ArrowDown,
  BookOpen,
  ChevronRight,
  FileText,
  Hash,
  Sparkles,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";

// Feature card data
const features = [
  {
    icon: FileText,
    title: "Text Simplification",
    description:
      "Transforms dense academic, legal, and medical content into clear, approachable language anyone can understand.",
    accent: "text-accent",
    bg: "bg-accent/10",
    border: "border-accent/20",
    delay: 0.35,
  },
  {
    icon: BookOpen,
    title: "Smart Summarization",
    description:
      "Generates concise bullet-point and paragraph summaries. Choose from short, balanced, or detailed output.",
    accent: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/20",
    delay: 0.45,
  },
  {
    icon: Hash,
    title: "Keyword Extraction",
    description:
      "Automatically detects and highlights the most important terms, with hover tooltips explaining each concept.",
    accent: "text-secondary",
    bg: "bg-secondary/10",
    border: "border-secondary/20",
    delay: 0.55,
  },
];

interface HeroSectionProps {
  /** id of the element to scroll to when CTA is clicked */
  ctaTargetId?: string;
}

export function HeroSection({ ctaTargetId = "interpreter" }: HeroSectionProps) {
  const handleScrollToCta = () => {
    const target = document.getElementById(ctaTargetId);
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section
      className="relative overflow-hidden"
      aria-labelledby="hero-heading"
      data-ocid="hero.section"
    >
      {/* ── Background mesh image ── */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/generated/hero-mesh-bg.dim_1600x700.jpg"
          alt=""
          aria-hidden="true"
          className="w-full h-full object-cover object-center opacity-30 dark:opacity-40 select-none pointer-events-none"
        />
        {/* Gradient overlay that ties image into the page background */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        {/* Subtle radial glow */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            background:
              "radial-gradient(ellipse 70% 55% at 50% 0%, oklch(var(--accent) / 0.35) 0%, transparent 70%)",
          }}
        />
      </div>

      {/* ── Content ── */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 pt-20 pb-16 md:pt-28 md:pb-20 flex flex-col items-center text-center gap-6">
        {/* Pill badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
        >
          <Badge
            variant="outline"
            className="gap-1.5 px-3 py-1 text-xs font-medium border-accent/30 bg-accent/5 text-accent tracking-wide uppercase"
            data-ocid="hero.badge"
          >
            <Sparkles className="w-3 h-3" strokeWidth={2} />
            AI-Powered Interpretation
          </Badge>
        </motion.div>

        {/* Headline */}
        <motion.h1
          id="hero-heading"
          className="font-display font-bold tracking-tight text-4xl sm:text-5xl md:text-6xl lg:text-7xl max-w-4xl leading-[1.08]"
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.08 }}
        >
          <span className="text-foreground">Simplify </span>
          <span
            className="bg-clip-text text-transparent"
            style={{
              backgroundImage:
                "linear-gradient(135deg, oklch(var(--primary)) 0%, oklch(var(--accent)) 100%)",
            }}
          >
            Complexity
          </span>
          <span className="text-foreground"> with AI</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          className="text-muted-foreground text-base sm:text-lg md:text-xl max-w-2xl leading-relaxed"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.18 }}
        >
          Effortlessly transform dense academic, legal, medical, and technical
          documents into clear, concise, and understandable language — in
          seconds.
        </motion.p>

        {/* CTA Row */}
        <motion.div
          className="flex flex-col sm:flex-row items-center gap-3 mt-2"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.26 }}
        >
          <Button
            size="lg"
            onClick={handleScrollToCta}
            className="gap-2 px-7 text-base font-semibold bg-accent hover:bg-accent/90 text-accent-foreground shadow-lg shadow-accent/25 transition-smooth"
            data-ocid="hero.primary_button"
          >
            <Zap className="w-4 h-4" strokeWidth={2} />
            Start Interpreting
            <ChevronRight className="w-4 h-4 opacity-70" strokeWidth={2} />
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={handleScrollToCta}
            className="gap-2 px-7 text-base border-border/60 hover:border-accent/50 hover:bg-accent/5 transition-smooth"
            data-ocid="hero.secondary_button"
          >
            See how it works
          </Button>
        </motion.div>

        {/* Stats row */}
        <motion.div
          className="flex items-center gap-6 mt-1 text-sm text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.36 }}
        >
          {[
            { label: "Documents processed", value: "50K+", first: true },
            { label: "Avg. time saved", value: "85%", first: false },
            {
              label: "Supported formats",
              value: "PDF, DOCX, TXT",
              first: false,
            },
          ].map((stat) => (
            <div key={stat.label} className="flex items-center gap-2">
              {!stat.first && (
                <span className="w-px h-3.5 bg-border/60" aria-hidden="true" />
              )}
              <span className="text-foreground font-semibold">
                {stat.value}
              </span>
              <span className="hidden sm:inline">{stat.label}</span>
            </div>
          ))}
        </motion.div>

        {/* ── Feature Cards ── */}
        <div
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-4xl mt-8"
          data-ocid="hero.features.list"
        >
          {features.map((feat, idx) => (
            <motion.div
              key={feat.title}
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.52,
                ease: "easeOut",
                delay: feat.delay,
              }}
              data-ocid={`hero.features.item.${idx + 1}`}
            >
              <Card
                className={`relative flex flex-col items-start gap-3 p-5 h-full border ${feat.border} bg-card/60 backdrop-blur-sm hover:bg-card/90 transition-smooth glow-accent hover:shadow-lg cursor-default`}
              >
                {/* Icon badge */}
                <div
                  className={`flex items-center justify-center w-9 h-9 rounded-lg ${feat.bg} border ${feat.border}`}
                >
                  <feat.icon
                    className={`w-4.5 h-4.5 ${feat.accent}`}
                    strokeWidth={1.75}
                  />
                </div>

                <div className="flex flex-col gap-1 text-left">
                  <h3 className="font-display font-semibold text-sm text-foreground leading-snug">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {feat.description}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Scroll arrow */}
        <motion.button
          onClick={handleScrollToCta}
          className="mt-6 flex flex-col items-center gap-1.5 text-muted-foreground hover:text-accent transition-colors duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
          aria-label="Scroll to interpreter"
          data-ocid="hero.scroll_button"
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.65 }}
        >
          <span className="text-xs tracking-wide uppercase font-medium opacity-70">
            Scroll to start
          </span>
          <motion.div
            animate={{ y: [0, 5, 0] }}
            transition={{
              repeat: Number.POSITIVE_INFINITY,
              duration: 1.6,
              ease: "easeInOut",
            }}
          >
            <ArrowDown className="w-4 h-4" strokeWidth={1.75} />
          </motion.div>
        </motion.button>
      </div>
    </section>
  );
}
