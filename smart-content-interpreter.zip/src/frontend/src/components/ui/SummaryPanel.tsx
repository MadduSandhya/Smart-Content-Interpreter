import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
/**
 * SummaryPanel — tabbed view for Short / Medium / Detailed summaries.
 * Each tab shows bullet points + a paragraph summary.
 */
import { cn } from "@/lib/utils";
import type { Summary, SummaryLength } from "@/types";
import { CheckCircle2 } from "lucide-react";

const SUMMARY_TABS: { value: SummaryLength; label: string }[] = [
  { value: "short", label: "Short" },
  { value: "medium", label: "Medium" },
  { value: "detailed", label: "Detailed" },
];

interface SummaryPanelProps {
  summaries: Record<SummaryLength, Summary>;
  defaultLength?: SummaryLength;
  className?: string;
}

interface SummaryContentProps {
  summary: Summary;
}

function SummaryContent({ summary }: SummaryContentProps) {
  return (
    <div className="space-y-4">
      {/* Bullet points */}
      {summary.bullets.length > 0 && (
        <ul className="space-y-2" data-ocid="summary.bullets_list">
          {summary.bullets.map((bullet, i) => (
            <li
              key={bullet.slice(0, 40)}
              className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed"
              data-ocid={`summary.bullet.${i + 1}`}
            >
              <CheckCircle2
                className="size-4 text-accent shrink-0 mt-0.5"
                aria-hidden
              />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
      )}

      {/* Paragraph summary */}
      {summary.paragraph && (
        <div className="pt-2 border-t border-border">
          <p
            className="text-sm text-muted-foreground leading-relaxed italic"
            data-ocid="summary.paragraph"
          >
            {summary.paragraph}
          </p>
        </div>
      )}
    </div>
  );
}

export function SummaryPanel({
  summaries,
  defaultLength = "medium",
  className,
}: SummaryPanelProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-border bg-card p-4 space-y-3",
        className,
      )}
      data-ocid="summary.panel"
    >
      <div className="flex items-center gap-2 mb-1">
        <h3 className="font-display font-semibold text-sm text-foreground uppercase tracking-wide">
          Summary
        </h3>
      </div>

      <Tabs defaultValue={defaultLength} data-ocid="summary.tabs">
        <TabsList className="w-full" data-ocid="summary.tabs_list">
          {SUMMARY_TABS.map(({ value, label }) => (
            <TabsTrigger
              key={value}
              value={value}
              className="flex-1"
              data-ocid={`summary.tab.${value}`}
            >
              {label}
            </TabsTrigger>
          ))}
        </TabsList>

        {SUMMARY_TABS.map(({ value }) => (
          <TabsContent key={value} value={value} className="mt-4">
            <SummaryContent summary={summaries[value]} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
