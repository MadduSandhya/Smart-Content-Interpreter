import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
/**
 * KeywordBadge — displays a keyword with an importance indicator bar.
 * Supports tooltip with keyword definition on hover.
 */
import { cn } from "@/lib/utils";
import type { Keyword } from "@/types";

const importanceConfig = {
  high: { dots: 3, label: "High importance", color: "bg-primary" },
  medium: { dots: 2, label: "Medium importance", color: "bg-accent" },
  low: { dots: 1, label: "Low importance", color: "bg-muted-foreground" },
} as const;

interface KeywordBadgeProps {
  keyword: Keyword;
  className?: string;
  "data-ocid"?: string;
}

export function KeywordBadge({
  keyword,
  className,
  "data-ocid": dataOcid,
}: KeywordBadgeProps) {
  const config = importanceConfig[keyword.importance];

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          data-ocid={dataOcid}
          className={cn(
            "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-border",
            "bg-card text-foreground text-xs font-medium cursor-default",
            "hover:border-accent/60 hover:bg-accent/10 transition-smooth",
            "glow-accent",
            className,
          )}
        >
          <span className="truncate max-w-[120px]">{keyword.word}</span>
          {/* Importance dots */}
          <span
            className="flex items-center gap-[3px] shrink-0"
            aria-label={config.label}
          >
            {[1, 2, 3].map((n) => (
              <span
                key={n}
                className={cn(
                  "size-1.5 rounded-full transition-smooth",
                  n <= config.dots ? config.color : "bg-border",
                )}
              />
            ))}
          </span>
        </span>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-[220px] text-center">
        <p className="font-medium mb-0.5">{keyword.word}</p>
        <p className="text-xs opacity-80">{keyword.definition}</p>
      </TooltipContent>
    </Tooltip>
  );
}
