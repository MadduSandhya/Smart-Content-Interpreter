import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";
/**
 * HighlightedText — renders text with difficult words underlined in teal.
 * Clicking a highlighted word triggers lazy-loaded term explanation via explainTerm().
 * Words over 10 chars or in a known-complex set are auto-detected.
 */
import { cn } from "@/lib/utils";
import type { DifficultTerm } from "@/types";
import { useCallback, useState } from "react";

// Common words excluded from auto-detection — mirrors KEYWORD_STOP_WORDS in api.ts.
// Any word <=7 chars is also excluded by isDifficult().
const SIMPLE_WORDS = new Set([
  "the",
  "that",
  "this",
  "with",
  "have",
  "will",
  "from",
  "they",
  "been",
  "were",
  "your",
  "more",
  "also",
  "into",
  "than",
  "then",
  "when",
  "what",
  "some",
  "would",
  "there",
  "their",
  "which",
  "about",
  "other",
  "after",
  "before",
  "because",
  "through",
  "during",
  "under",
  "over",
  "between",
  "could",
  "should",
  "these",
  "those",
  "where",
  "while",
  "every",
  "being",
  "since",
  "either",
  "within",
  "without",
  "against",
  "although",
  "whether",
  "information",
  "understanding",
  "environment",
  "development",
  "organization",
  "government",
  "international",
  "relationship",
  "community",
  "management",
  "technology",
  "communication",
  "educational",
  "significant",
  "particularly",
  "furthermore",
  "nonetheless",
  "nevertheless",
  "accordingly",
  "specifically",
  "approximately",
  "immediately",
  "continuously",
  "unfortunately",
  "essentially",
]);

function isDifficult(word: string): boolean {
  const clean = word.replace(/[^a-zA-Z]/g, "").toLowerCase();
  // Must be more than 7 chars (i.e. >=8) — same threshold as simulateKeywords
  if (clean.length <= 7) return false;
  if (SIMPLE_WORDS.has(clean)) return false;
  return true;
}

interface WordTokenProps {
  word: string;
  difficultTerms: DifficultTerm[];
  onExplain: (term: string) => Promise<string>;
}

function WordToken({ word, difficultTerms, onExplain }: WordTokenProps) {
  const clean = word.replace(/[^a-zA-Z]/g, "").toLowerCase();
  const existingTerm = difficultTerms.find(
    (t) => t.term.toLowerCase() === clean,
  );
  const highlight = existingTerm || isDifficult(word);

  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(
    existingTerm?.explanation ?? null,
  );

  const handleOpen = useCallback(
    async (isOpen: boolean) => {
      setOpen(isOpen);
      if (isOpen && explanation === null) {
        setLoading(true);
        try {
          const result = await onExplain(clean);
          setExplanation(result);
        } finally {
          setLoading(false);
        }
      }
    },
    [clean, explanation, onExplain],
  );

  if (!highlight) return <span>{word} </span>;

  return (
    <Popover open={open} onOpenChange={handleOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className={cn(
            "inline underline decoration-accent decoration-2 underline-offset-2",
            "hover:text-accent cursor-pointer transition-smooth rounded-sm",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          )}
          aria-label={`Explain: ${clean}`}
        >
          {word}
        </button>
      </PopoverTrigger>
      <PopoverContent
        side="top"
        className="w-64 p-3 bg-popover border border-border shadow-lg"
        data-ocid="highlighted-text.popover"
      >
        <p className="text-xs font-semibold text-accent mb-1 uppercase tracking-wide">
          {clean}
        </p>
        {loading ? (
          <div
            className="space-y-1.5"
            data-ocid="highlighted-text.loading_state"
          >
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-4/5" />
          </div>
        ) : (
          <p className="text-sm text-foreground leading-snug">{explanation}</p>
        )}
      </PopoverContent>
    </Popover>
  );
}

interface HighlightedTextProps {
  text: string;
  difficultTerms: DifficultTerm[];
  onExplain: (term: string) => Promise<string>;
  className?: string;
}

export function HighlightedText({
  text,
  difficultTerms,
  onExplain,
  className,
}: HighlightedTextProps) {
  const tokens = text.split(/(\s+)/);

  return (
    <p
      className={cn(
        "text-sm leading-relaxed text-foreground font-body",
        className,
      )}
      data-ocid="highlighted-text.panel"
    >
      {tokens.map((token, i) => {
        // Preserve whitespace tokens as-is
        const key = `token-${i}`;
        if (/^\s+$/.test(token)) return <span key={key}>{token}</span>;
        return (
          <WordToken
            key={key}
            word={token}
            difficultTerms={difficultTerms}
            onExplain={onExplain}
          />
        );
      })}
    </p>
  );
}
