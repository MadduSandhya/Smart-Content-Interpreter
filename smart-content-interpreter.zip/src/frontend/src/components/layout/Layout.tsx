import { Header } from "./Header";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";
  const footerHref = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`;

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />

      <main className="flex-1 w-full">{children}</main>

      <footer className="bg-card border-t border-border">
        <div className="container mx-auto px-4 sm:px-6 h-14 flex items-center justify-center">
          <p className="text-xs text-muted-foreground text-center">
            © {year}.{" "}
            <span className="text-muted-foreground/80">
              Built with love using{" "}
            </span>
            <a
              href={footerHref}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:text-accent/80 transition-colors duration-200 underline underline-offset-2"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}
