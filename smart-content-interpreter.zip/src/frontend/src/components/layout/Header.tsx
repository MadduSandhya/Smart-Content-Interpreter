import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/useTheme";
import { BrainCircuit, Moon, Sun } from "lucide-react";
import { motion } from "motion/react";

export function Header() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border shadow-subtle backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <motion.div
          className="flex items-center gap-2.5"
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 glow-accent">
            <BrainCircuit className="w-5 h-5 text-accent" strokeWidth={1.5} />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-display font-semibold text-base text-foreground tracking-tight">
              Smart Content
            </span>
            <span className="text-xs text-muted-foreground leading-none tracking-wide uppercase">
              Interpreter
            </span>
          </div>
        </motion.div>

        {/* Controls */}
        <motion.div
          className="flex items-center gap-2"
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
            data-ocid="theme.toggle"
            className="rounded-lg w-9 h-9 transition-smooth hover:bg-muted"
          >
            {isDark ? (
              <Sun className="w-4 h-4 text-foreground" strokeWidth={1.5} />
            ) : (
              <Moon className="w-4 h-4 text-foreground" strokeWidth={1.5} />
            )}
          </Button>
        </motion.div>
      </div>
    </header>
  );
}
