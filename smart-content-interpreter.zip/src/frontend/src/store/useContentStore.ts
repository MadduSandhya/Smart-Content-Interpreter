import {
  generateMultilingualSpeech,
  generateSpeech,
  generateVoicePreview,
  summarizeVideo,
} from "@/services/api";
import type {
  ActiveView,
  AudioFormat,
  AudioState,
  ContentState,
  FileAudioState,
  MultilingualTtsResult,
  ReadingLevel,
  SimplificationResult,
  SummaryLength,
  SupportedLanguage,
  TtsVoice,
  VideoState,
  VideoSummaryResult,
} from "@/types";
import { checkBrowserFormatSupport, detectAdaptiveFormat } from "@/types";
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ContentActions {
  setInputText: (text: string) => void;
  setResult: (result: SimplificationResult | null) => void;
  setProcessing: (flag: boolean) => void;
  setError: (error: string | null) => void;
  setReadingLevel: (level: ReadingLevel) => void;
  setSummaryLength: (length: SummaryLength) => void;
  setActiveView: (view: ActiveView) => void;
  reset: () => void;
}

interface AudioActions {
  setAudioUrl: (url: string | null) => void;
  setIsGeneratingAudio: (flag: boolean) => void;
  setAudioError: (error: string | null) => void;
  setSelectedVoice: (voice: TtsVoice) => void;
  setCurrentAudioSection: (section: string | null) => void;
  setAudioFormat: (format: AudioFormat) => void;
  generateAudio: (text: string, label: string) => Promise<void>;
  generateMultilingualAudio: (
    text: string,
    voice: TtsVoice,
    targetLanguage: string,
    label: string,
  ) => Promise<void>;
  generateVoicePreview: (voice: TtsVoice, language: string) => Promise<void>;
}

const initialState: ContentState = {
  inputText: "",
  result: null,
  isProcessing: false,
  error: null,
  selectedReadingLevel: "beginner",
  selectedSummaryLength: "medium",
  activeView: "split",
};

const initialVideoState = {
  videoUrl: "",
  videoResult: null as VideoSummaryResult | null,
  isProcessingVideo: false,
  videoError: null as string | null,
};

const initialAudioState: AudioState = {
  audioUrl: null,
  isGeneratingAudio: false,
  audioError: null,
  selectedVoice: "nova" as TtsVoice,
  currentAudioSection: null,
  selectedFormat: detectAdaptiveFormat(),
  audioFormat: undefined,
  bitrate: undefined,
  sampleRate: undefined,
};

const initialFileAudioState = {
  fileInputText: "",
  fileName: null as string | null,
  isExtractingFile: false,
  fileExtractionError: null as string | null,
  targetLanguage: "English" as SupportedLanguage,
  multilingualResult: null as MultilingualTtsResult | null,
};

export const useContentStore = create<
  ContentState &
    ContentActions &
    VideoState &
    AudioState &
    AudioActions &
    FileAudioState
>()(
  persist(
    (set, get) => ({
      ...initialState,
      ...initialVideoState,
      ...initialAudioState,
      ...initialFileAudioState,

      // ── Text interpreter actions ─────────────────────────────────────────────
      setInputText: (text) => set({ inputText: text }),
      setResult: (result) => set({ result }),
      setProcessing: (flag) => set({ isProcessing: flag }),
      setError: (error) => set({ error }),
      setReadingLevel: (level) => set({ selectedReadingLevel: level }),
      setSummaryLength: (length) => set({ selectedSummaryLength: length }),
      setActiveView: (view) => set({ activeView: view }),
      reset: () => set({ ...initialState }),

      // ── Video summarizer actions ─────────────────────────────────────────────
      setVideoUrl: (videoUrl) => set({ videoUrl }),
      setVideoResult: (videoResult) => set({ videoResult }),
      setIsProcessingVideo: (isProcessingVideo) => set({ isProcessingVideo }),
      setVideoError: (videoError) => set({ videoError }),

      processVideo: async () => {
        const { videoUrl } = get();
        if (!videoUrl.trim()) return;
        set({ isProcessingVideo: true, videoError: null, videoResult: null });
        try {
          const result = await summarizeVideo(videoUrl.trim());
          set({ videoResult: result });
        } catch (err) {
          const msg =
            err instanceof Error
              ? err.message
              : "An unexpected error occurred.";
          set({ videoError: msg, videoResult: null });
        } finally {
          set({ isProcessingVideo: false });
        }
      },

      // ── Audio / TTS actions ──────────────────────────────────────────────────
      setAudioUrl: (audioUrl) => set({ audioUrl }),
      setIsGeneratingAudio: (isGeneratingAudio) => set({ isGeneratingAudio }),
      setAudioError: (audioError) => set({ audioError }),
      setSelectedVoice: (selectedVoice) => set({ selectedVoice }),
      setCurrentAudioSection: (currentAudioSection) =>
        set({ currentAudioSection }),
      setAudioFormat: (format) => {
        // Verify browser support, fall back to mp3 if unsupported
        const supported = checkBrowserFormatSupport(format);
        set({ selectedFormat: supported });
      },

      generateAudio: async (text: string, label: string) => {
        const { selectedVoice, selectedFormat } = get();
        set({
          isGeneratingAudio: true,
          audioError: null,
          currentAudioSection: label,
          audioUrl: null,
          audioFormat: undefined,
          bitrate: undefined,
          sampleRate: undefined,
        });
        try {
          const result = await generateSpeech(
            text,
            selectedVoice,
            selectedFormat,
          );
          const fmt = result.audioFormat ?? selectedFormat;
          const dataUrl = result.audioBase64
            ? `data:audio/${fmt};base64,${result.audioBase64}`
            : null;
          set({
            audioUrl: dataUrl,
            isGeneratingAudio: false,
            audioFormat: fmt,
            bitrate: result.bitrate,
            sampleRate: result.sampleRate,
          });
        } catch (err) {
          const msg =
            err instanceof Error
              ? err.message
              : "Failed to generate audio. Please try again.";
          set({
            audioError: msg,
            isGeneratingAudio: false,
            audioUrl: null,
            audioFormat: undefined,
          });
        }
      },

      generateMultilingualAudio: async (
        text: string,
        voice: TtsVoice,
        targetLanguage: string,
        label: string,
      ) => {
        const { selectedFormat } = get();
        set({
          isGeneratingAudio: true,
          audioError: null,
          currentAudioSection: label,
          audioUrl: null,
          multilingualResult: null,
          audioFormat: undefined,
          bitrate: undefined,
          sampleRate: undefined,
        });
        try {
          const result = await generateMultilingualSpeech(
            text,
            voice,
            targetLanguage,
            selectedFormat,
          );
          const fmt = result.audioFormat ?? selectedFormat;
          const dataUrl = result.audioBase64
            ? `data:audio/${fmt};base64,${result.audioBase64}`
            : null;
          set({
            audioUrl: dataUrl,
            multilingualResult: result,
            isGeneratingAudio: false,
            audioFormat: fmt,
            bitrate: result.bitrate,
            sampleRate: result.sampleRate,
          });
        } catch (err) {
          const msg =
            err instanceof Error
              ? err.message
              : "Failed to generate multilingual audio. Please try again.";
          set({
            audioError: msg,
            isGeneratingAudio: false,
            audioUrl: null,
            multilingualResult: null,
            audioFormat: undefined,
          });
        }
      },

      generateVoicePreview: async (voice: TtsVoice, language: string) => {
        const { selectedFormat } = get();
        try {
          const result = await generateVoicePreview(
            voice,
            language,
            selectedFormat,
          );
          if (result.audioBase64) {
            const fmt = result.audioFormat ?? selectedFormat;
            const previewUrl = `data:audio/${fmt};base64,${result.audioBase64}`;
            // Play in a temporary audio element — does not overwrite main audioUrl
            const tempAudio = new Audio(previewUrl);
            tempAudio.volume = 0.8;
            tempAudio.play().catch(() => {
              // Ignore autoplay errors — browser may block without user gesture
            });
          }
        } catch {
          // Preview errors are non-critical; silently ignore
        }
      },

      // ── File Audio actions ───────────────────────────────────────────────────
      setFileInputText: (fileInputText) => set({ fileInputText }),
      setFileName: (fileName) => set({ fileName }),
      setIsExtractingFile: (isExtractingFile) => set({ isExtractingFile }),
      setFileExtractionError: (fileExtractionError) =>
        set({ fileExtractionError }),
      setTargetLanguage: (targetLanguage) =>
        set({ targetLanguage, multilingualResult: null }),
      clearFileInput: () =>
        set({
          fileInputText: "",
          fileName: null,
          isExtractingFile: false,
          fileExtractionError: null,
          multilingualResult: null,
        }),
    }),
    {
      name: "sci-content-store",
      // Only persist user preferences and user-entered content; not transient processing state
      partialize: (state) => ({
        selectedReadingLevel: state.selectedReadingLevel,
        selectedSummaryLength: state.selectedSummaryLength,
        activeView: state.activeView,
        selectedVoice: state.selectedVoice,
        selectedFormat: state.selectedFormat,
        fileInputText: state.fileInputText,
        fileName: state.fileName,
        targetLanguage: state.targetLanguage,
      }),
    },
  ),
);
