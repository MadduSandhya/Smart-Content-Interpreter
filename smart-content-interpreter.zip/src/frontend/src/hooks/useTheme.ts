import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "sci-theme";
const DARK_CLASS = "dark";

function getInitialTheme(): "dark" | "light" {
  if (typeof window === "undefined") return "dark";
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored === "dark" || stored === "light") return stored;
  // Default to dark per the design contract
  return "dark";
}

function applyTheme(theme: "dark" | "light") {
  const root = document.documentElement;
  if (theme === "dark") {
    root.classList.add(DARK_CLASS);
    root.style.colorScheme = "dark";
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", "#0d0d14");
  } else {
    root.classList.remove(DARK_CLASS);
    root.style.colorScheme = "light";
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", "#f9f9fc");
  }
}

export function useTheme() {
  const [theme, setThemeState] = useState<"dark" | "light">(getInitialTheme);

  // Apply on mount and whenever theme changes
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  const setTheme = useCallback((next: "dark" | "light") => {
    setThemeState(next);
    localStorage.setItem(STORAGE_KEY, next);
    applyTheme(next);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  return { theme, setTheme, toggleTheme, isDark: theme === "dark" };
}
