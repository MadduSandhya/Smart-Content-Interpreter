// TTS domain types for Text-to-Speech feature
module {
  // Available OpenAI TTS voices
  public type TtsVoice = {
    #Alloy;
    #Echo;
    #Fable;
    #Onyx;
    #Nova;
    #Shimmer;
  };

  // Supported audio output formats
  public type AudioFormat = {
    #mp3;
    #wav;
    #ogg;
    #m4a;
  };

  /// Map AudioFormat to a display/file-extension string.
  public func audioFormatToText(fmt : AudioFormat) : Text {
    switch (fmt) {
      case (#mp3) "mp3";
      case (#wav) "wav";
      case (#ogg) "ogg";
      case (#m4a) "m4a";
    };
  };

  /// Map AudioFormat to its MIME type string.
  public func audioFormatMimeType(fmt : AudioFormat) : Text {
    switch (fmt) {
      case (#mp3) "audio/mpeg";
      case (#wav) "audio/wav";
      case (#ogg) "audio/ogg";
      case (#m4a) "audio/mp4";
    };
  };

  // Result returned after audio generation
  public type TtsResult = {
    // Base64-encoded audio data — prefix with 'data:<mimeType>;base64,' for playback
    audioBase64 : Text;
    // Rough estimate of audio duration in seconds based on word count
    durationEstimate : Float;
    // Audio format identifier (e.g. "mp3", "wav")
    audioFormat : Text;
    // Bitrate in kbps as text (e.g. "128", "1411")
    bitrate : Text;
    // Sample rate in Hz as text (e.g. "44100", "48000")
    sampleRate : Text;
  };

  // Result returned after multilingual speech generation
  public type MultilingualTtsResult = {
    // Short name of the language detected in the input text (e.g. "English", "Hindi")
    detectedLanguage : Text;
    // Short name of the language the audio was produced in
    translatedLanguage : Text;
    // The text that was actually passed to TTS (translated or original)
    translatedText : Text;
    // Base64-encoded audio data
    audioBase64 : Text;
    // Rough estimate of audio duration in seconds based on word count
    durationEstimate : Text;
    // Audio format identifier (e.g. "mp3", "wav")
    audioFormat : Text;
    // Bitrate in kbps as text
    bitrate : Text;
    // Sample rate in Hz as text
    sampleRate : Text;
  };
};
