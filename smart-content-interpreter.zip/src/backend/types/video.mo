// Video domain types for YouTube Video Summarization feature
module {
  // Metadata fetched from YouTube for a given video
  public type VideoMetadata = {
    videoId : Text;
    title : Text;
    channelName : Text;
    durationSeconds : Nat;
    thumbnailUrl : Text;
  };

  // A single timestamped segment with a key point extracted from the transcript
  public type TimestampSegment = {
    timeSeconds : Nat;
    timeFormatted : Text; // e.g. "00:30", "01:45"
    keyPoint : Text;
  };

  // Full structured result returned by summarizeVideo
  public type VideoSummaryResult = {
    videoId : Text;
    metadata : VideoMetadata;
    summaryShort : Text;
    summaryDetailed : Text;
    keyPoints : [Text];
    topics : [Text];
    segments : [TimestampSegment];
  };
};
