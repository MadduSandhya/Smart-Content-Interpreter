// AI domain-specific types for Smart Content Interpreter
module {
  // Reading level for text simplification
  public type ReadingLevel = {
    #Beginner;
    #Intermediate;
    #Advanced;
  };

  // Summary length preference
  public type SummaryLength = {
    #Short;
    #Medium;
    #Detailed;
  };

  // Result of text simplification
  public type SimplificationResult = {
    simplifiedText : Text;
    readingLevel : ReadingLevel;
  };

  // Result of summarization
  public type SummarizationResult = {
    bulletPoints : [Text];
    paragraph : Text;
    summaryLength : SummaryLength;
  };

  // A keyword with an importance score (0.0 to 1.0)
  public type Keyword = {
    word : Text;
    score : Float;
  };

  // Result of keyword extraction
  public type KeywordResult = {
    keywords : [Keyword];
  };

  // Result of word/phrase explanation
  public type ExplanationResult = {
    term : Text;
    definition : Text;
    examples : [Text];
  };
};
