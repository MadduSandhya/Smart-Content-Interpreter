// Common cross-cutting types shared across all domains
module {
  // Timestamp in nanoseconds (from Time.now())
  public type Timestamp = Int;

  // Generic result type for all public methods
  public type Result<T> = { #ok : T; #err : Text };
};
