// Smart Content Interpreter — composition root
// Delegates all public methods to domain mixins; owns no business logic.
import AiMixin "mixins/ai-api";
import VideoMixin "mixins/video-api";
import TtsMixin "mixins/tts-api";

actor {
  include AiMixin();
  include VideoMixin();
  include TtsMixin();
};
