// TTS API mixin: exposes public Text-to-Speech endpoint using OpenAI TTS API
import OutCall "mo:caffeineai-http-outcalls/outcall";
import CommonTypes "../types/common";
import TtsTypes "../types/tts";
import TtsLib "../lib/tts";
import Blob "mo:core/Blob";
import Map "mo:core/Map";
import Text "mo:core/Text";
import Time "mo:core/Time";
import IC "ic:aaaaa-aa";

mixin () {
  let TTS_OPENAI_API_KEY : Text = "sk-placeholder-replace-with-your-openai-api-key";
  let TTS_OPENAI_URL : Text = "https://api.openai.com/v1/audio/speech";
  let OPENAI_CHAT_URL : Text = "https://api.openai.com/v1/chat/completions";

  let httpRequestCycles = 231_000_000_000;

  // ---------------------------------------------------------------------------
  // Audio cache: key = text # "|" # voice # "|" # format
  // Keyed by Text, stored as Map<Text, TtsResult>
  // ---------------------------------------------------------------------------
  let audioCache : Map.Map<Text, TtsTypes.TtsResult> = Map.empty<Text, TtsTypes.TtsResult>();
  let multilingualAudioCache : Map.Map<Text, TtsTypes.MultilingualTtsResult> = Map.empty<Text, TtsTypes.MultilingualTtsResult>();

  // Build a cache key for generateSpeech
  func speechCacheKey(text : Text, voice : TtsTypes.TtsVoice, fmt : TtsTypes.AudioFormat) : Text {
    text # "|" # TtsLib.voiceToText(voice) # "|" # TtsTypes.audioFormatToText(fmt);
  };

  // Build a cache key for generateMultilingualSpeech
  func multilingualCacheKey(text : Text, voice : TtsTypes.TtsVoice, targetLang : Text, fmt : TtsTypes.AudioFormat) : Text {
    text # "|" # TtsLib.voiceToText(voice) # "|" # targetLang # "|" # TtsTypes.audioFormatToText(fmt);
  };

  // Transform query required by IC HTTP outcalls for consensus determinism.
  // Named 'transformTts' to avoid collision with 'transform' (ai-api.mo)
  // and 'transformVideo' (video-api.mo).
  public query func transformTts(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  // Transform query for multilingual TTS OpenAI chat calls (language detection / translation).
  public query func transformMultilingualTts(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  // Transform query for voice preview TTS calls.
  public query func transformVoicePreview(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  // Make a POST request to the OpenAI TTS endpoint and return the raw binary body as Blob.
  // We bypass the OutCall helper (which decodes UTF-8) because TTS returns binary audio data.
  func httpPostBinary(url : Text, body : Text) : async CommonTypes.Result<Blob> {
    let headers : [IC.http_header] = [
      { name = "Content-Type"; value = "application/json" },
      { name = "Authorization"; value = "Bearer " # TTS_OPENAI_API_KEY },
      { name = "User-Agent"; value = "caffeine.ai" },
      { name = "Idempotency-Key"; value = "TTS-" # Time.now().toText() },
    ];
    let httpRequest : IC.http_request_args = {
      url;
      max_response_bytes = null;
      headers;
      body = ?body.encodeUtf8();
      method = #post;
      transform = ?{
        function = transformTts;
        context = Blob.fromArray([]);
      };
      is_replicated = ?false;
    };
    try {
      let response = await (with cycles = httpRequestCycles) IC.http_request(httpRequest);
      if (response.status == 200) {
        #ok(response.body);
      } else {
        // Try to decode error message for better diagnostics
        let errMsg = switch (response.body.decodeUtf8()) {
          case (?text) "OpenAI TTS error (" # response.status.toText() # "): " # text;
          case null "OpenAI TTS error: HTTP " # response.status.toText();
        };
        #err(errMsg);
      };
    } catch (e) {
      #err("HTTP outcall failed: " # e.message());
    };
  };



  // Make a POST request to the OpenAI chat completions endpoint and return the
  // raw JSON response body as Text.  Used for language detection and translation.
  func httpPostChat(body : Text) : async CommonTypes.Result<Text> {
    try {
      let rawResponse = await OutCall.httpPostRequest(
        OPENAI_CHAT_URL,
        [
          { name = "Content-Type"; value = "application/json" },
          { name = "Authorization"; value = "Bearer " # TTS_OPENAI_API_KEY },
        ],
        body,
        transformMultilingualTts,
      );
      #ok(rawResponse);
    } catch (e) {
      #err("HTTP outcall failed: " # e.message());
    };
  };

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Convert text to speech using the OpenAI TTS API.
  /// Returns a TtsResult with base64-encoded audio and estimated duration.
  /// format: optional AudioFormat — defaults to #mp3 when null.
  public func generateSpeech(
    text : Text,
    voice : TtsTypes.TtsVoice,
    format : ?TtsTypes.AudioFormat,
  ) : async CommonTypes.Result<TtsTypes.TtsResult> {
    let fmt = switch (format) { case (?f) f; case null #mp3 };
    let cacheKey = speechCacheKey(text, voice, fmt);

    // Return cached result if available
    switch (audioCache.get(cacheKey)) {
      case (?cached) return #ok(cached);
      case null {};
    };

    let requestBody = TtsLib.buildTtsBody(text, voice, ?fmt);
    switch (await httpPostBinary(TTS_OPENAI_URL, requestBody)) {
      case (#err(msg)) #err(msg);
      case (#ok(audioBlob)) {
        let audioBase64 = TtsLib.base64Encode(audioBlob);
        let durationEstimate = TtsLib.estimateDuration(text);
        let result : TtsTypes.TtsResult = {
          audioBase64;
          durationEstimate;
          audioFormat = TtsTypes.audioFormatToText(fmt);
          bitrate = TtsLib.formatBitrate(fmt);
          sampleRate = TtsLib.formatSampleRate(fmt);
        };
        audioCache.add(cacheKey, result);
        #ok(result);
      };
    };
  };

  /// Detect language, translate if needed, then convert to speech.
  /// targetLanguage must be one of the supported language names (e.g. "Hindi").
  /// If targetLanguage is empty or unrecognised it falls back to "English".
  /// For texts longer than 4000 chars, translation is done in ~3000-char chunks
  /// before a single TTS call on the concatenated result.
  /// format: optional AudioFormat — defaults to #mp3 when null.
  public func generateMultilingualSpeech(
    text : Text,
    voice : TtsTypes.TtsVoice,
    targetLanguage : Text,
    format : ?TtsTypes.AudioFormat,
  ) : async CommonTypes.Result<TtsTypes.MultilingualTtsResult> {
    // Reject empty input early
    let trimmedText = text.trim(#predicate(func(c : Char) : Bool {
      c == ' ' or c == '\t' or c == '\n' or c == '\r';
    }));
    if (trimmedText.isEmpty()) {
      return #err("Input text is empty");
    };

    let fmt = switch (format) { case (?f) f; case null #mp3 };
    let normTarget = TtsLib.normaliseLanguage(targetLanguage);
    let cacheKey = multilingualCacheKey(trimmedText, voice, normTarget, fmt);

    // Return cached result if available
    switch (multilingualAudioCache.get(cacheKey)) {
      case (?cached) return #ok(cached);
      case null {};
    };

    // ── 1. Detect language ──────────────────────────────────────────────────
    let detectBody = TtsLib.buildDetectLanguageBody(trimmedText);
    let detectedLanguage = switch (await httpPostChat(detectBody)) {
      case (#err(_)) "Unknown";
      case (#ok(raw)) TtsLib.parseDetectedLanguage(raw);
    };

    // ── 2. Translate (skip if same language) ────────────────────────────────
    let translatedText : Text = if (detectedLanguage == normTarget) {
      trimmedText; // already in the target language
    } else if (trimmedText.size() > 4000) {
      // Chunk, translate each piece, then concatenate
      let chunks = TtsLib.chunkText(trimmedText, 3000);
      var combined = "";
      for (chunk in chunks.vals()) {
        let translateBody = TtsLib.buildTranslateBody(chunk, normTarget);
        let translated = switch (await httpPostChat(translateBody)) {
          case (#err(_)) chunk; // fallback: keep original chunk on failure
          case (#ok(raw)) {
            let t = TtsLib.parseTranslation(raw);
            if (t.isEmpty()) chunk else t;
          };
        };
        combined := if (combined.isEmpty()) translated else combined # " " # translated;
      };
      combined;
    } else {
      let translateBody = TtsLib.buildTranslateBody(trimmedText, normTarget);
      switch (await httpPostChat(translateBody)) {
        case (#err(_)) trimmedText; // fallback to original on translation failure
        case (#ok(raw)) {
          let t = TtsLib.parseTranslation(raw);
          if (t.isEmpty()) trimmedText else t;
        };
      };
    };

    // ── 3. Generate TTS on the translated text ───────────────────────────────
    let requestBody = TtsLib.buildTtsBody(translatedText, voice, ?fmt);
    switch (await httpPostBinary(TTS_OPENAI_URL, requestBody)) {
      case (#err(msg)) #err(msg);
      case (#ok(audioBlob)) {
        let audioBase64 = TtsLib.base64Encode(audioBlob);
        let durationSecs = TtsLib.estimateDuration(translatedText);
        // Format duration as a human-readable string, e.g. "12.4s"
        let durationEstimate = durationSecs.toText() # "s";
        let result : TtsTypes.MultilingualTtsResult = {
          detectedLanguage;
          translatedLanguage = normTarget;
          translatedText;
          audioBase64;
          durationEstimate;
          audioFormat = TtsTypes.audioFormatToText(fmt);
          bitrate = TtsLib.formatBitrate(fmt);
          sampleRate = TtsLib.formatSampleRate(fmt);
        };
        multilingualAudioCache.add(cacheKey, result);
        #ok(result);
      };
    };
  };

  /// Generate a short voice preview for the given voice, language, and format.
  /// Produces TTS for a standard sample sentence without caching the result
  /// (previews are intentionally short and cheap).
  public func generateVoicePreview(
    voice : TtsTypes.TtsVoice,
    language : Text,
    format : TtsTypes.AudioFormat,
  ) : async CommonTypes.Result<TtsTypes.TtsResult> {
    let sampleText = "Hello! This is a preview of the selected voice.";
    let requestBody = TtsLib.buildTtsBody(sampleText, voice, ?format);
    switch (await httpPostBinary(TTS_OPENAI_URL, requestBody)) {
      case (#err(msg)) #err(msg);
      case (#ok(audioBlob)) {
        let audioBase64 = TtsLib.base64Encode(audioBlob);
        let durationEstimate = TtsLib.estimateDuration(sampleText);
        #ok({
          audioBase64;
          durationEstimate;
          audioFormat = TtsTypes.audioFormatToText(format);
          bitrate = TtsLib.formatBitrate(format);
          sampleRate = TtsLib.formatSampleRate(format);
        });
      };
    };
  };
};
