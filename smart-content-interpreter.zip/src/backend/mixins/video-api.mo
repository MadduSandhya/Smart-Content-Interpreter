// Video API mixin: exposes public YouTube Video Summarization endpoint
import OutCall "mo:caffeineai-http-outcalls/outcall";
import CommonTypes "../types/common";
import VideoTypes "../types/video";
import VideoLib "../lib/video";
import AiLib "../lib/ai";
import Error "mo:core/Error";

mixin () {
  // Reuse the same OpenAI key + URL constants as ai-api.mo.
  // In a single actor these constants are inlined per mixin — each mixin is
  // independent; they share the same actor but no shared let bindings.
  let VIDEO_OPENAI_API_KEY : Text = "sk-placeholder-replace-with-your-openai-api-key";
  let VIDEO_OPENAI_URL : Text = "https://api.openai.com/v1/chat/completions";

  func videoOpenAiHeaders() : [OutCall.Header] {
    [
      { name = "Content-Type"; value = "application/json" },
      { name = "Authorization"; value = "Bearer " # VIDEO_OPENAI_API_KEY },
    ];
  };

  // Transform query required by IC HTTP outcalls for consensus determinism.
  // NOTE: the ai-api.mo mixin already exposes a `transform` query; we name
  // this one differently to avoid duplicate public method names.
  public query func transformVideo(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  // Perform an HTTP GET to the given URL; return the response body as Text.
  func httpGet(url : Text) : async CommonTypes.Result<Text> {
    try {
      let response = await OutCall.httpGetRequest(url, [], transformVideo);
      #ok(response);
    } catch (e) {
      #err("HTTP GET failed: " # e.message());
    };
  };

  // Call OpenAI with the given request body; return the assistant message content.
  func callOpenAiForVideo(requestBody : Text) : async CommonTypes.Result<Text> {
    try {
      let rawResponse = await OutCall.httpPostRequest(
        VIDEO_OPENAI_URL,
        videoOpenAiHeaders(),
        requestBody,
        transformVideo,
      );
      switch (AiLib.extractContent(rawResponse)) {
        case (?content) #ok(content);
        case null #err("Failed to parse OpenAI response: " # rawResponse);
      };
    } catch (e) {
      #err("HTTP outcall failed: " # e.message());
    };
  };

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Accept a YouTube URL, fetch metadata + transcript, run AI summarization,
  /// and return a structured VideoSummaryResult.
  public func summarizeVideo(url : Text) : async CommonTypes.Result<VideoTypes.VideoSummaryResult> {
    // 1. Extract video ID
    let videoId = switch (VideoLib.extractVideoId(url)) {
      case null return #err("Invalid YouTube URL. Please provide a valid youtube.com or youtu.be link.");
      case (?id) id;
    };

    // 2. Fetch metadata via YouTube oEmbed API
    let metadataUrl = VideoLib.buildMetadataUrl(videoId);
    let metadata : VideoTypes.VideoMetadata = switch (await httpGet(metadataUrl)) {
      case (#err(_)) {
        // oEmbed failed — use minimal fallback metadata
        {
          videoId;
          title = "YouTube Video";
          channelName = "Unknown Channel";
          durationSeconds = 0;
          thumbnailUrl = "https://img.youtube.com/vi/" # videoId # "/hqdefault.jpg";
        };
      };
      case (#ok(metaJson)) VideoLib.parseMetadataResponse(metaJson, videoId);
    };

    // 3. Fetch transcript via YouTube timedtext API (JSON3 format)
    let transcriptUrl = VideoLib.buildTranscriptUrl(videoId);
    let transcript : Text = switch (await httpGet(transcriptUrl)) {
      case (#err(_)) {
        "Transcript unavailable for this video. Here is a summary based on available video information.";
      };
      case (#ok(transcriptJson)) {
        switch (VideoLib.parseTranscriptResponse(transcriptJson)) {
          case null {
            // JSON3 parse failed — try XML fallback URL (no fmt param)
            let xmlUrl = "https://www.youtube.com/api/timedtext?v=" # videoId # "&lang=en";
            switch (await httpGet(xmlUrl)) {
              case (#err(_)) {
                "Transcript unavailable for this video. Here is a summary based on available video information.";
              };
              case (#ok(xmlBody)) {
                switch (VideoLib.parseTranscriptResponse(xmlBody)) {
                  case null {
                    "Transcript unavailable for this video. Here is a summary based on available video information.";
                  };
                  case (?t) t;
                };
              };
            };
          };
          case (?t) t;
        };
      };
    };

    // 4. Send transcript to OpenAI for summarization
    let promptBody = VideoLib.buildVideoSummaryPrompt(transcript, videoId);
    switch (await callOpenAiForVideo(promptBody)) {
      case (#err(msg)) #err(msg);
      case (#ok(content)) {
        let result = VideoLib.parseVideoSummaryResponse(content, videoId, metadata);
        #ok(result);
      };
    };
  };
};
