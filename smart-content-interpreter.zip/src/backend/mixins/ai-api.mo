// AI API mixin: exposes all public AI processing endpoints via OpenAI HTTP outcalls
import OutCall "mo:caffeineai-http-outcalls/outcall";
import Types "../types/ai";
import CommonTypes "../types/common";
import AiLib "../lib/ai";
import Error "mo:core/Error";

mixin () {
  // OpenAI API key — replace with your actual key or set via configuration.
  // In production this would be read from a secure config store.
  let OPENAI_API_KEY : Text = "sk-placeholder-replace-with-your-openai-api-key";
  let OPENAI_URL : Text = "https://api.openai.com/v1/chat/completions";

  // Headers required for OpenAI API calls
  func openAiHeaders() : [OutCall.Header] {
    [
      { name = "Content-Type"; value = "application/json" },
      { name = "Authorization"; value = "Bearer " # OPENAI_API_KEY },
    ];
  };

  // Transform callback required by the IC HTTP outcalls mechanism.
  // Strips non-deterministic fields so all replicas agree on the response.
  public query func transform(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  // Call the OpenAI API and extract the assistant message content.
  // Returns #err with a description if the HTTP call or content extraction fails.
  func callOpenAi(requestBody : Text) : async CommonTypes.Result<Text> {
    try {
      let rawResponse = await OutCall.httpPostRequest(
        OPENAI_URL,
        openAiHeaders(),
        requestBody,
        transform,
      );
      switch (AiLib.extractContent(rawResponse)) {
        case (?content) #ok(content);
        case null #err("Failed to parse OpenAI response: " # rawResponse);
      };
    } catch (e) {
      #err("HTTP outcall failed: " # e.message());
    };
  };

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Simplify complex text to the requested reading level.
  public func simplifyText(
    text : Text,
    level : Types.ReadingLevel,
  ) : async CommonTypes.Result<Types.SimplificationResult> {
    let body = AiLib.buildSimplifyPrompt(text, level);
    switch (await callOpenAi(body)) {
      case (#err(msg)) #err(msg);
      case (#ok(content)) {
        let result = AiLib.parseSimplificationResponse(content, level);
        #ok(result);
      };
    };
  };

  /// Summarize text into bullet points and a paragraph.
  public func summarizeText(
    text : Text,
    length : Types.SummaryLength,
  ) : async CommonTypes.Result<Types.SummarizationResult> {
    let body = AiLib.buildSummarizePrompt(text, length);
    switch (await callOpenAi(body)) {
      case (#err(msg)) #err(msg);
      case (#ok(content)) {
        let result = AiLib.parseSummarizationResponse(content, length);
        #ok(result);
      };
    };
  };

  /// Extract keywords with importance scores from text.
  public func extractKeywords(
    text : Text,
  ) : async CommonTypes.Result<Types.KeywordResult> {
    let body = AiLib.buildKeywordPrompt(text);
    switch (await callOpenAi(body)) {
      case (#err(msg)) #err(msg);
      case (#ok(content)) {
        let result = AiLib.parseKeywordResponse(content);
        #ok(result);
      };
    };
  };

  /// Explain a word or phrase in plain language with examples.
  public func explainTerm(
    term : Text,
  ) : async CommonTypes.Result<Types.ExplanationResult> {
    let body = AiLib.buildExplainPrompt(term);
    switch (await callOpenAi(body)) {
      case (#err(msg)) #err(msg);
      case (#ok(content)) {
        let result = AiLib.parseExplanationResponse(content, term);
        #ok(result);
      };
    };
  };
};
