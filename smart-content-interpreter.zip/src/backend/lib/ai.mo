// AI domain logic: builds OpenAI prompts and parses raw text responses
import Types "../types/ai";
import Text "mo:core/Text";
import List "mo:core/List";
import Float "mo:core/Float";
import Nat "mo:core/Nat";

module {

  // ---------------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------------

  // Escape a user-supplied string so it is safe inside a JSON string value.
  func jsonEscape(s : Text) : Text {
    var out = s;
    out := out.replace(#text "\\", "\\\\");
    out := out.replace(#text "\"", "\\\"");
    out := out.replace(#text "\n", "\\n");
    out := out.replace(#text "\r", "\\r");
    out := out.replace(#text "\t", "\\t");
    out;
  };

  // Build an OpenAI chat/completions JSON body.
  func buildRequestBody(systemMsg : Text, userMsg : Text) : Text {
    "{\"model\":\"gpt-4o-mini\",\"temperature\":0.3,\"messages\":[{\"role\":\"system\",\"content\":\"" #
    jsonEscape(systemMsg) #
    "\"},{\"role\":\"user\",\"content\":\"" #
    jsonEscape(userMsg) #
    "\"}]}";
  };

  // Strip leading/trailing whitespace characters.
  func trimWS(s : Text) : Text {
    s.trim(#predicate(func(c : Char) : Bool {
      c == ' ' or c == '\t' or c == '\n' or c == '\r';
    }));
  };

  // Strip markdown code fences that OpenAI often wraps JSON in.
  func stripFences(s : Text) : Text {
    var t = trimWS(s);
    if (t.startsWith(#text "```json")) {
      t := switch (t.stripStart(#text "```json")) {
        case (?stripped) stripped;
        case null t;
      };
    } else if (t.startsWith(#text "```")) {
      t := switch (t.stripStart(#text "```")) {
        case (?stripped) stripped;
        case null t;
      };
    };
    if (t.endsWith(#text "```")) {
      t := switch (t.stripEnd(#text "```")) {
        case (?stripped) stripped;
        case null t;
      };
    };
    trimWS(t);
  };

  // Extract the value of a JSON string field.
  // Finds "fieldName":"<value>" and returns <value>.
  // Simple implementation that works for GPT's well-formed output.
  func extractStringField(json : Text, fieldName : Text) : ?Text {
    let needle = "\"" # fieldName # "\":\"";
    let iter = json.split(#text needle);
    ignore iter.next(); // skip content before the field
    switch (iter.next()) {
      case null null;
      case (?segment) {
        // segment starts immediately after the opening quote of the value
        // Split on the next double-quote to get the value
        let valueIter = segment.split(#text "\"");
        switch (valueIter.next()) {
          case null null;
          case (?value) ?value;
        };
      };
    };
  };

  // Extract an array of strings from a JSON array field: "fieldName":["a","b"]
  func extractArrayField(json : Text, fieldName : Text) : [Text] {
    let needle = "\"" # fieldName # "\":[";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null [];
      case (?segment) {
        // Find the content up to the first closing bracket
        let bracketIter = segment.split(#text "]");
        switch (bracketIter.next()) {
          case null [];
          case (?inner) {
            // inner: "item1","item2","item3"
            // Split on "," to get individual quoted items
            let rawItems = inner.split(#text "\",\"");
            let buf = List.empty<Text>();
            for (item in rawItems) {
              var cleaned = trimWS(item);
              cleaned := switch (cleaned.stripStart(#text "\"")) {
                case (?s) s;
                case null cleaned;
              };
              cleaned := switch (cleaned.stripEnd(#text "\"")) {
                case (?s) s;
                case null cleaned;
              };
              if (not cleaned.isEmpty()) {
                buf.add(cleaned);
              };
            };
            buf.toArray();
          };
        };
      };
    };
  };

  // Extract a Float value from a JSON integer field (0-100) scaled to 0.0-1.0.
  // e.g. "score": 85  ->  0.85
  func extractFloatField(json : Text, fieldName : Text) : Float {
    let needle = "\"" # fieldName # "\":";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null 0.5;
      case (?segment) {
        let t = trimWS(segment);
        // Collect digit characters
        let numBuf = List.empty<Char>();
        label scan for (c in t.toIter()) {
          if (c >= '0' and c <= '9') {
            numBuf.add(c);
          } else {
            break scan;
          };
        };
        let numText = Text.fromIter(numBuf.values());
        switch (Nat.fromText(numText)) {
          case (?n) {
            // Score is 0-100; divide by 100.0 to get 0.0-1.0
            n.toFloat() / 100.0;
          };
          case null 0.5;
        };
      };
    };
  };

  // ---------------------------------------------------------------------------
  // Prompt builders
  // ---------------------------------------------------------------------------

  /// Build an OpenAI request body for text simplification.
  public func buildSimplifyPrompt(text : Text, level : Types.ReadingLevel) : Text {
    let (levelDesc, guidance) = switch (level) {
      case (#Beginner) (
        "grade 5 (age 10-11)",
        "Use very simple words and short sentences. Avoid jargon and technical terms, or explain them simply.",
      );
      case (#Intermediate) (
        "grade 9 (age 14-15)",
        "Use clear language and moderate sentence length. Define uncommon terms when first used.",
      );
      case (#Advanced) (
        "college level",
        "Maintain precise vocabulary and well-structured paragraphs while remaining readable.",
      );
    };
    let systemMsg = "You are an expert at rewriting text to be more accessible. " #
      "Rewrite the given text to a " # levelDesc # " reading level. " #
      guidance # " " #
      "Return ONLY a JSON object with this exact structure (no markdown fences): " #
      "{\"simplifiedText\":\"<the rewritten text>\"}";
    buildRequestBody(systemMsg, text);
  };

  /// Build an OpenAI request body for summarization.
  public func buildSummarizePrompt(text : Text, length : Types.SummaryLength) : Text {
    let (bulletCount, paraDesc) = switch (length) {
      case (#Short) ("2-3", "2 concise sentences");
      case (#Medium) ("5-7", "1 short paragraph of 4-6 sentences");
      case (#Detailed) ("10 or more", "2 detailed paragraphs");
    };
    let systemMsg = "You are an expert summarizer. " #
      "Summarize the given text with exactly " # bulletCount # " concise bullet points and a prose summary of " # paraDesc # ". " #
      "Return ONLY a JSON object (no markdown fences): " #
      "{\"bulletPoints\":[\"point 1\",\"point 2\"],\"paragraph\":\"prose summary here\"}";
    buildRequestBody(systemMsg, text);
  };

  /// Build an OpenAI request body for keyword extraction.
  public func buildKeywordPrompt(text : Text) : Text {
    let systemMsg = "You are an expert at identifying important keywords and key phrases in text. " #
      "Extract 5 to 15 of the most important keywords, each with an importance score from 0 to 100 (integer, where 100 = most important). " #
      "Return ONLY a JSON object (no markdown fences): " #
      "{\"keywords\":[{\"word\":\"example\",\"score\":95},{\"word\":\"another\",\"score\":80}]}";
    buildRequestBody(systemMsg, text);
  };

  /// Build an OpenAI request body for term explanation.
  public func buildExplainPrompt(term : Text) : Text {
    let systemMsg = "You are a helpful educator and dictionary. " #
      "Explain the given word or phrase in plain, simple language. " #
      "Provide a clear definition and 2-3 short example sentences. " #
      "Return ONLY a JSON object (no markdown fences): " #
      "{\"definition\":\"plain language definition\",\"examples\":[\"Example sentence 1.\",\"Example sentence 2.\"]}";
    buildRequestBody(systemMsg, term);
  };

  // ---------------------------------------------------------------------------
  // Response parsers
  // ---------------------------------------------------------------------------

  /// Extract the assistant message content from an OpenAI chat completion response.
  /// Response shape: {"choices":[{"message":{"role":"assistant","content":"..."}}]}
  public func extractContent(jsonResponse : Text) : ?Text {
    extractStringField(jsonResponse, "content");
  };

  /// Parse simplification JSON into SimplificationResult.
  public func parseSimplificationResponse(raw : Text, level : Types.ReadingLevel) : Types.SimplificationResult {
    let cleaned = stripFences(raw);
    let simplified = switch (extractStringField(cleaned, "simplifiedText")) {
      case (?t) t;
      case null raw;
    };
    { simplifiedText = simplified; readingLevel = level };
  };

  /// Parse summarization JSON into SummarizationResult.
  public func parseSummarizationResponse(raw : Text, length : Types.SummaryLength) : Types.SummarizationResult {
    let cleaned = stripFences(raw);
    let bullets = extractArrayField(cleaned, "bulletPoints");
    let para = switch (extractStringField(cleaned, "paragraph")) {
      case (?t) t;
      case null "";
    };
    { bulletPoints = bullets; paragraph = para; summaryLength = length };
  };

  /// Parse keyword extraction JSON into KeywordResult.
  /// Handles array of objects: [{"word":"...","score":0.9}, ...]
  public func parseKeywordResponse(raw : Text) : Types.KeywordResult {
    let cleaned = stripFences(raw);
    let needle = "\"keywords\":[";
    let iter = cleaned.split(#text needle);
    ignore iter.next();
    let keywords : [Types.Keyword] = switch (iter.next()) {
      case null [];
      case (?segment) {
        // Find the outer closing bracket of the keywords array
        let bracketIter = segment.split(#text "]");
        switch (bracketIter.next()) {
          case null [];
          case (?inner) {
            // Split individual keyword objects on },{ separator
            let objParts = inner.split(#text "},{");
            let buf = List.empty<Types.Keyword>();
            for (part in objParts) {
              let word = switch (extractStringField(part, "word")) {
                case (?w) w;
                case null "";
              };
              let score = extractFloatField(part, "score");
              if (not word.isEmpty()) {
                buf.add({ word; score });
              };
            };
            buf.toArray();
          };
        };
      };
    };
    { keywords };
  };

  /// Parse explanation JSON into ExplanationResult.
  public func parseExplanationResponse(raw : Text, term : Text) : Types.ExplanationResult {
    let cleaned = stripFences(raw);
    let definition = switch (extractStringField(cleaned, "definition")) {
      case (?d) d;
      case null "";
    };
    let examples = extractArrayField(cleaned, "examples");
    { term; definition; examples };
  };
};
