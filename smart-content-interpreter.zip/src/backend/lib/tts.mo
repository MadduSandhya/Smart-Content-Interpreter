// TTS domain logic: builds OpenAI TTS request body and encodes binary audio to base64
import Types "../types/tts";
import Text "mo:core/Text";
import List "mo:core/List";
import Float "mo:core/Float";
import Char "mo:core/Char";

module {

  // ---------------------------------------------------------------------------
  // Voice helpers
  // ---------------------------------------------------------------------------

  /// Convert a TtsVoice variant to the lowercase text name expected by OpenAI.
  public func voiceToText(voice : Types.TtsVoice) : Text {
    switch (voice) {
      case (#Alloy) "alloy";
      case (#Echo) "echo";
      case (#Fable) "fable";
      case (#Onyx) "onyx";
      case (#Nova) "nova";
      case (#Shimmer) "shimmer";
    };
  };

  // ---------------------------------------------------------------------------
  // Audio format helpers
  // ---------------------------------------------------------------------------

  /// Map AudioFormat to the OpenAI response_format parameter string.
  /// OGG maps to "opus" (OpenAI's OGG codec), M4A maps to "aac".
  public func audioFormatToOpenAI(fmt : Types.AudioFormat) : Text {
    switch (fmt) {
      case (#mp3) "mp3";
      case (#wav) "wav";
      case (#ogg) "opus";
      case (#m4a) "aac";
    };
  };

  /// Return the bitrate (kbps) string for a given audio format.
  public func formatBitrate(fmt : Types.AudioFormat) : Text {
    switch (fmt) {
      case (#mp3) "128";
      case (#wav) "1411";
      case (#ogg) "128";
      case (#m4a) "128";
    };
  };

  /// Return the sample rate (Hz) string for a given audio format.
  public func formatSampleRate(fmt : Types.AudioFormat) : Text {
    switch (fmt) {
      case (#mp3) "44100";
      case (#wav) "44100";
      case (#ogg) "48000";
      case (#m4a) "44100";
    };
  };

  // ---------------------------------------------------------------------------
  // Request builder
  // ---------------------------------------------------------------------------

  /// Escape a string value for safe embedding inside a JSON string.
  public func jsonEscape(s : Text) : Text {
    var out = s;
    out := out.replace(#text "\\", "\\\\");
    out := out.replace(#text "\"", "\\\"");
    out := out.replace(#text "\n", "\\n");
    out := out.replace(#text "\r", "\\r");
    out := out.replace(#text "\t", "\\t");
    out;
  };

  /// Build the JSON request body for POST https://api.openai.com/v1/audio/speech.
  /// Accepts an optional AudioFormat — defaults to #mp3 when null.
  public func buildTtsBody(text : Text, voice : Types.TtsVoice, format : ?Types.AudioFormat) : Text {
    let voiceName = voiceToText(voice);
    let fmt = switch (format) { case (?f) f; case null #mp3 };
    let responseFormat = audioFormatToOpenAI(fmt);
    "{\"model\":\"tts-1\",\"input\":\"" #
    jsonEscape(text) #
    "\",\"voice\":\"" #
    voiceName #
    "\",\"response_format\":\"" #
    responseFormat #
    "\"}";
  };

  // ---------------------------------------------------------------------------
  // Duration estimate
  // ---------------------------------------------------------------------------

  /// Estimate audio duration in seconds based on average speaking rate (~150 wpm).
  public func estimateDuration(text : Text) : Float {
    // Count words by splitting on whitespace
    var wordCount : Nat = 0;
    var inWord = false;
    for (c in text.toIter()) {
      if (c == ' ' or c == '\t' or c == '\n' or c == '\r') {
        inWord := false;
      } else if (not inWord) {
        inWord := true;
        wordCount += 1;
      };
    };
    // 150 words per minute => words / 2.5 = seconds
    wordCount.toFloat() / 2.5;
  };

  // ---------------------------------------------------------------------------
  // Base64 encoding
  // ---------------------------------------------------------------------------

  let BASE64_CHARS : [Char] = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/',
  ];

  /// Encode a Blob of binary data to a base64 Text string.
  /// Uses pure arithmetic (no bitwise ops) since Nat lacks >> and & operators.
  public func base64Encode(data : Blob) : Text {
    let bytes = data.toArray();
    let len = bytes.size();
    let buf = List.empty<Char>();

    var i = 0;
    while (i + 3 <= len) {
      let b0 = bytes[i].toNat();
      let b1 = bytes[i + 1].toNat();
      let b2 = bytes[i + 2].toNat();

      // 24-bit group = b0<<16 | b1<<8 | b2
      let grp = b0 * 65536 + b1 * 256 + b2;
      buf.add(BASE64_CHARS[(grp / 262144) % 64]);  // bits 18-23
      buf.add(BASE64_CHARS[(grp / 4096) % 64]);    // bits 12-17
      buf.add(BASE64_CHARS[(grp / 64) % 64]);      // bits 6-11
      buf.add(BASE64_CHARS[grp % 64]);              // bits 0-5

      i += 3;
    };

    // Handle remaining 1 or 2 bytes with padding
    if (i + 1 == len) {
      let b0 = bytes[i].toNat();
      // b0 contributes 2 base64 chars, then 2 padding '='
      buf.add(BASE64_CHARS[(b0 / 4) % 64]);         // bits 2-7
      buf.add(BASE64_CHARS[(b0 % 4) * 16]);          // bits 0-1 shifted left
      buf.add('=');
      buf.add('=');
    } else if (i + 2 == len) {
      let b0 = bytes[i].toNat();
      let b1 = bytes[i + 1].toNat();
      // b0 and b1 contribute 3 base64 chars, then 1 padding '='
      let grp2 = b0 * 256 + b1;
      buf.add(BASE64_CHARS[(grp2 / 1024) % 64]);    // bits 10-15
      buf.add(BASE64_CHARS[(grp2 / 16) % 64]);      // bits 4-9
      buf.add(BASE64_CHARS[(grp2 % 16) * 4]);       // bits 0-3 shifted left
      buf.add('=');
    };

    Text.fromIter(buf.values());
  };

  // ---------------------------------------------------------------------------
  // Multilingual helpers
  // ---------------------------------------------------------------------------

  /// List of supported target language names for display / validation.
  public let SUPPORTED_LANGUAGES : [Text] = [
    "English", "Hindi", "Telugu", "Spanish", "French",
    "German", "Japanese", "Chinese", "Arabic", "Portuguese",
  ];

  /// Normalise a language name to a canonical form (title-case, trimmed).
  /// Falls back to "English" if the supplied name is empty or unrecognised.
  public func normaliseLanguage(lang : Text) : Text {
    let trimmed = lang.trim(#predicate(func(c : Char) : Bool {
      c == ' ' or c == '\t' or c == '\n' or c == '\r';
    }));
    if (trimmed.isEmpty()) return "English";
    // Check against supported list (case-insensitive prefix match)
    let lowerInput = trimmed.toLower();
    for (supported in SUPPORTED_LANGUAGES.vals()) {
      if (supported.toLower() == lowerInput) return supported;
    };
    // Unknown language — fall back to English
    "English";
  };

  /// Build an OpenAI GPT-4o-mini request body for language detection.
  /// The model is asked to return ONLY a JSON object: {"language":"<Name>"}
  public func buildDetectLanguageBody(text : Text) : Text {
    let systemMsg = "You are a language detection expert. " #
      "Detect the language of the provided text. " #
      "Return ONLY a JSON object with this exact structure (no markdown fences, no extra text): " #
      "{\"language\":\"<short language name, e.g. English, Hindi, Spanish>\"}";
    let userMsg = if (text.size() > 500) {
      // Use only the first ~500 chars for detection to save tokens
      var preview = List.empty<Char>();
      var count = 0;
      label cut for (c in text.toIter()) {
        if (count >= 500) break cut;
        preview.add(c);
        count += 1;
      };
      Text.fromIter(preview.values());
    } else {
      text;
    };
    "{\"model\":\"gpt-4o-mini\",\"temperature\":0,\"messages\":[{\"role\":\"system\",\"content\":\"" #
    jsonEscape(systemMsg) #
    "\"},{\"role\":\"user\",\"content\":\"" #
    jsonEscape(userMsg) #
    "\"}]}";
  };

  /// Parse the language detection response and extract the language name.
  public func parseDetectedLanguage(raw : Text) : Text {
    // Response shape from OpenAI: {"choices":[{"message":{"content":"{\"language\":\"Hindi\"}"}}]}
    // First extract the "content" field, then extract "language" from it.
    let contentOpt = extractJsonStringField(raw, "content");
    let payload = switch (contentOpt) {
      case (?c) c;
      case null raw;
    };
    let langOpt = extractJsonStringField(payload, "language");
    switch (langOpt) {
      case (?lang) {
        let trimmed = lang.trim(#predicate(func(c : Char) : Bool {
          c == ' ' or c == '\t' or c == '\n' or c == '\r';
        }));
        if (trimmed.isEmpty()) "English" else trimmed;
      };
      case null "English";
    };
  };

  /// Build an OpenAI GPT-4o-mini request body to translate text to targetLanguage.
  public func buildTranslateBody(text : Text, targetLanguage : Text) : Text {
    let systemMsg = "You are a professional translator. " #
      "Translate the provided text into " # targetLanguage # ". " #
      "Preserve the original meaning, tone, and formatting. " #
      "Return ONLY the translated text — no explanations, no JSON wrapper, no markdown.";
    "{\"model\":\"gpt-4o-mini\",\"temperature\":0.2,\"messages\":[{\"role\":\"system\",\"content\":\"" #
    jsonEscape(systemMsg) #
    "\"},{\"role\":\"user\",\"content\":\"" #
    jsonEscape(text) #
    "\"}]}";
  };

  /// Parse the translation response and extract the translated text from the
  /// "content" field of the first choice's message.
  public func parseTranslation(raw : Text) : Text {
    switch (extractJsonStringField(raw, "content")) {
      case (?content) {
        content.trim(#predicate(func(c : Char) : Bool {
          c == ' ' or c == '\t' or c == '\n' or c == '\r';
        }));
      };
      case null "";
    };
  };

  /// Split text into chunks of at most ~3000 characters, breaking at sentence
  /// boundaries ('. ', '! ', '? ', '\n') to avoid mid-sentence cuts.
  /// If no sentence boundary is found within the window, splits at the limit.
  public func chunkText(text : Text, maxChunkSize : Nat) : [Text] {
    let len = text.size();
    if (len <= maxChunkSize) return [text];

    let chars = List.empty<Char>();
    for (c in text.toIter()) { chars.add(c) };
    let arr = chars.toArray();

    let chunks = List.empty<Text>();
    var start = 0;

    while (start < len) {
      let end = if (start + maxChunkSize >= len) {
        len;
      } else {
        // Search backwards from start+maxChunkSize for a sentence boundary
        var splitAt = start + maxChunkSize;
        var scan = splitAt;
        label findBoundary while (scan > start) {
          let c = arr[scan];
          if (scan + 1 < len) {
            let next = arr[scan + 1];
            if ((c == '.' or c == '!' or c == '?') and next == ' ') {
              splitAt := scan + 2; // split after the space
              break findBoundary;
            };
          };
          if (c == '\n') {
            splitAt := scan + 1;
            break findBoundary;
          };
          scan -= 1;
        };
        splitAt;
      };

      // Collect chars from start..end into a Text
      let chunkBuf = List.empty<Char>();
      var idx = start;
      while (idx < end) {
        chunkBuf.add(arr[idx]);
        idx += 1;
      };
      let chunk = Text.fromIter(chunkBuf.values()).trim(#predicate(func(c : Char) : Bool {
        c == ' ' or c == '\t' or c == '\n' or c == '\r';
      }));
      if (not chunk.isEmpty()) {
        chunks.add(chunk);
      };
      start := end;
    };

    chunks.toArray();
  };

  // ---------------------------------------------------------------------------
  // Private JSON helpers (used only within this module)
  // ---------------------------------------------------------------------------

  /// Extract the value of a JSON string field from a JSON object text.
  /// Returns the raw string value between the quotes, or null if not found.
  public func extractJsonStringField(json : Text, fieldName : Text) : ?Text {
    let needle = "\"" # fieldName # "\":\"";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null null;
      case (?segment) {
        // Walk char by char to handle escaped quotes (\") correctly
        let valBuf = List.empty<Char>();
        let doubleQuote : Char = Char.fromNat32(34); // '"'
        let backslash : Char = Char.fromNat32(92);   // '\'
        var escaping = false;
        label parseVal for (c in segment.toIter()) {
          if (escaping) {
            // Write the unescaped character
            let unescaped : Char = switch (c) {
              case ('n') '\n';
              case ('r') '\r';
              case ('t') '\t';
              case (_) c; // includes '"' and '\'
            };
            valBuf.add(unescaped);
            escaping := false;
          } else if (c == backslash) {
            // Next char is escaped — don't write the backslash yet
            escaping := true;
          } else if (c == doubleQuote) {
            break parseVal;
          } else {
            valBuf.add(c);
          };
        };
        ?Text.fromIter(valBuf.values());
      };
    };
  };
};
