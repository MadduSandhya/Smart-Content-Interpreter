// Video lib: prompt builders and JSON parsers for YouTube Video Summarization
import Types "../types/video";
import Text "mo:core/Text";
import List "mo:core/List";
import Nat "mo:core/Nat";

module {

  // ---------------------------------------------------------------------------
  // Internal helpers (mirrored from lib/ai.mo patterns)
  // ---------------------------------------------------------------------------

  func trimWS(s : Text) : Text {
    s.trim(#predicate(func(c : Char) : Bool {
      c == ' ' or c == '\t' or c == '\n' or c == '\r';
    }));
  };

  func jsonEscape(s : Text) : Text {
    var out = s;
    out := out.replace(#text "\\", "\\\\");
    out := out.replace(#text "\"", "\\\"");
    out := out.replace(#text "\n", "\\n");
    out := out.replace(#text "\r", "\\r");
    out := out.replace(#text "\t", "\\t");
    out;
  };

  func stripFences(s : Text) : Text {
    var t = trimWS(s);
    if (t.startsWith(#text "```json")) {
      t := switch (t.stripStart(#text "```json")) {
        case (?stripped) stripped;
        case null t;
      };
    } else if (t.startsWith(#text "```")) {
      t := switch (t.stripStart(#text "```")) {
        case (?stripped) stripped;
        case null t;
      };
    };
    if (t.endsWith(#text "```")) {
      t := switch (t.stripEnd(#text "```")) {
        case (?stripped) stripped;
        case null t;
      };
    };
    trimWS(t);
  };

  func extractStringField(json : Text, fieldName : Text) : ?Text {
    let needle = "\"" # fieldName # "\":\"";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null null;
      case (?segment) {
        let valueIter = segment.split(#text "\"");
        switch (valueIter.next()) {
          case null null;
          case (?value) ?value;
        };
      };
    };
  };

  func extractArrayField(json : Text, fieldName : Text) : [Text] {
    let needle = "\"" # fieldName # "\":[";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null [];
      case (?segment) {
        let bracketIter = segment.split(#text "]");
        switch (bracketIter.next()) {
          case null [];
          case (?inner) {
            let rawItems = inner.split(#text "\",\"");
            let buf = List.empty<Text>();
            for (item in rawItems) {
              var cleaned = trimWS(item);
              cleaned := switch (cleaned.stripStart(#text "\"")) {
                case (?s) s;
                case null cleaned;
              };
              cleaned := switch (cleaned.stripEnd(#text "\"")) {
                case (?s) s;
                case null cleaned;
              };
              if (not cleaned.isEmpty()) {
                buf.add(cleaned);
              };
            };
            buf.toArray();
          };
        };
      };
    };
  };

  // Extract a Nat value from a JSON numeric field.
  func extractNatField(json : Text, fieldName : Text) : Nat {
    let needle = "\"" # fieldName # "\":";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null 0;
      case (?segment) {
        let t = trimWS(segment);
        let numBuf = List.empty<Char>();
        label scan for (c in t.toIter()) {
          if (c >= '0' and c <= '9') {
            numBuf.add(c);
          } else {
            break scan;
          };
        };
        let numText = Text.fromIter(numBuf.values());
        switch (Nat.fromText(numText)) {
          case (?n) n;
          case null 0;
        };
      };
    };
  };

  // Pad a number to 2 digits: "5" -> "05"
  func pad2(n : Nat) : Text {
    if (n < 10) { "0" # n.toText() } else { n.toText() };
  };

  // ---------------------------------------------------------------------------
  // Public functions
  // ---------------------------------------------------------------------------

  /// Extract a YouTube video ID from a full YouTube URL.
  /// Supports youtube.com/watch?v=ID and youtu.be/ID formats.
  public func extractVideoId(url : Text) : ?Text {
    // Try youtu.be/ID format first
    if (url.contains(#text "youtu.be/")) {
      let parts = url.split(#text "youtu.be/");
      ignore parts.next();
      switch (parts.next()) {
        case null {};
        case (?after) {
          // Strip any query string or fragment
          let idParts = after.split(#text "?");
          switch (idParts.next()) {
            case null {};
            case (?candidate) {
              let hashParts = candidate.split(#text "#");
              switch (hashParts.next()) {
                case null {};
                case (?id) {
                  let trimmed = trimWS(id);
                  if (trimmed.size() >= 11) {
                    // Take the first 11 chars
                    var count = 0;
                    let buf = List.empty<Char>();
                    for (c in trimmed.toIter()) {
                      if (count < 11) {
                        buf.add(c);
                        count += 1;
                      };
                    };
                    return ?Text.fromIter(buf.values());
                  };
                };
              };
            };
          };
        };
      };
    };

    // Try youtube.com/watch?v=ID format
    if (url.contains(#text "v=")) {
      let parts = url.split(#text "v=");
      ignore parts.next();
      switch (parts.next()) {
        case null {};
        case (?after) {
          // Strip & or # suffixes
          let ampParts = after.split(#text "&");
          switch (ampParts.next()) {
            case null {};
            case (?candidate) {
              let hashParts = candidate.split(#text "#");
              switch (hashParts.next()) {
                case null {};
                case (?id) {
                  let trimmed = trimWS(id);
                  if (trimmed.size() >= 11) {
                    var count = 0;
                    let buf = List.empty<Char>();
                    for (c in trimmed.toIter()) {
                      if (count < 11) {
                        buf.add(c);
                        count += 1;
                      };
                    };
                    return ?Text.fromIter(buf.values());
                  };
                };
              };
            };
          };
        };
      };
    };

    null;
  };

  /// Format a raw seconds value into "MM:SS" or "H:MM:SS" display string.
  public func formatTimestamp(seconds : Nat) : Text {
    let hours = seconds / 3600;
    let mins = (seconds % 3600) / 60;
    let secs = seconds % 60;
    if (hours > 0) {
      hours.toText() # ":" # pad2(mins) # ":" # pad2(secs);
    } else {
      pad2(mins) # ":" # pad2(secs);
    };
  };

  /// Build the YouTube oEmbed API request URL for metadata.
  /// Uses no API key; returns title, author_name, thumbnail_url.
  public func buildMetadataUrl(videoId : Text) : Text {
    "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=" # videoId # "&format=json";
  };

  /// Parse video metadata from a YouTube oEmbed JSON response.
  /// duration defaults to 0 (oEmbed doesn't include duration).
  public func parseMetadataResponse(json : Text, videoId : Text) : Types.VideoMetadata {
    let title = switch (extractStringField(json, "title")) {
      case (?t) t;
      case null "Unknown Title";
    };
    let channelName = switch (extractStringField(json, "author_name")) {
      case (?n) n;
      case null "Unknown Channel";
    };
    let thumbnailUrl = switch (extractStringField(json, "thumbnail_url")) {
      case (?u) u;
      case null ("https://img.youtube.com/vi/" # videoId # "/hqdefault.jpg");
    };
    {
      videoId;
      title;
      channelName;
      durationSeconds = 0;
      thumbnailUrl;
    };
  };

  /// Build the YouTube timedtext API URL (JSON3 format).
  public func buildTranscriptUrl(videoId : Text) : Text {
    "https://www.youtube.com/api/timedtext?v=" # videoId # "&lang=en&fmt=json3";
  };

  /// Parse the timedtext JSON3 response into a plain text string.
  /// JSON3 format: {"events":[{"segs":[{"utf8":"text"}],"tStartMs":...},...]}
  /// Falls back to basic XML text extraction if JSON3 pattern not matched.
  public func parseTranscriptResponse(json : Text) : ?Text {
    let trimmed = trimWS(json);
    if (trimmed.isEmpty()) return null;

    // Try JSON3 format: extract all "utf8" fields
    if (trimmed.contains(#text "\"utf8\"")) {
      let parts = trimmed.split(#text "\"utf8\":\"");
      let buf = List.empty<Text>();
      ignore parts.next(); // skip content before first field
      for (seg in parts) {
        // Each seg starts with the value, ends at the next unescaped "
        let valIter = seg.split(#text "\"");
        switch (valIter.next()) {
          case null {};
          case (?value) {
            let cleaned = value.replace(#text "\\n", " ");
            if (not trimWS(cleaned).isEmpty()) {
              buf.add(trimWS(cleaned));
            };
          };
        };
      };
      if (buf.toArray().size() > 0) {
        // Join segments with spaces
        var result = "";
        for (seg in buf.values()) {
          if (result.isEmpty()) {
            result := seg;
          } else {
            result := result # " " # seg;
          };
        };
        return ?result;
      };
    };

    // Try XML format: strip tags and return remaining text
    if (trimmed.startsWith(#text "<") or trimmed.contains(#text "<text ") or trimmed.contains(#text "<transcript")) {
      // Extract content between XML tags
      let tagBuf = List.empty<Text>();
      let xmlParts = trimmed.split(#text ">");
      for (part in xmlParts) {
        // After each ">" the content before the next "<" is text
        let textParts = part.split(#text "<");
        switch (textParts.next()) {
          case null {};
          case (?textContent) {
            let tc = trimWS(textContent);
            if (not tc.isEmpty() and not tc.startsWith(#text "<?") and not tc.startsWith(#text "<!")) {
              tagBuf.add(tc);
            };
          };
        };
      };
      let xmlArr = tagBuf.toArray();
      if (xmlArr.size() > 0) {
        var xmlResult = "";
        for (seg in xmlArr.values()) {
          if (xmlResult.isEmpty()) {
            xmlResult := seg;
          } else {
            xmlResult := xmlResult # " " # seg;
          };
        };
        return ?xmlResult;
      };
    };

    null;
  };

  /// Build an OpenAI request body to summarize a video transcript.
  /// Returns structured JSON with summaryShort, summaryDetailed, keyPoints, topics, segments.
  public func buildVideoSummaryPrompt(transcript : Text, videoId : Text) : Text {
    let systemMsg = "You are an expert at analyzing and summarizing YouTube video content. " #
      "Given a video transcript, produce a structured summary. " #
      "Return ONLY a JSON object (no markdown fences) with this exact structure: " #
      "{" #
      "\"summaryShort\":\"3-5 bullet points as a single string separated by • character\"," #
      "\"summaryDetailed\":\"100-150 word paragraph summary\"," #
      "\"keyPoints\":[\"plain-language key point 1\",\"key point 2\",\"key point 3\",\"key point 4\"]," #
      "\"topics\":[\"topic 1\",\"topic 2\",\"topic 3\"]," #
      "\"segments\":[{\"timeSeconds\":30,\"timeFormatted\":\"00:30\",\"keyPoint\":\"description of key moment\"}]" #
      "} " #
      "Provide 4-6 keyPoints, 3-5 topics, and 3-6 segments with realistic timestamps from the transcript. " #
      "For segments, estimate timestamps based on where topics appear in the transcript flow.";
    let userMsg = "Video ID: " # videoId # "\n\nTranscript:\n" # jsonEscape(transcript);
    "{\"model\":\"gpt-4o-mini\",\"temperature\":0.3,\"messages\":[{\"role\":\"system\",\"content\":\"" #
    jsonEscape(systemMsg) #
    "\"},{\"role\":\"user\",\"content\":\"" #
    userMsg #
    "\"}]}";
  };

  // Parse segments array from the AI JSON response.
  // Each segment object: {"timeSeconds":30,"timeFormatted":"00:30","keyPoint":"..."}
  func parseSegments(json : Text) : [Types.TimestampSegment] {
    let needle = "\"segments\":[";
    let iter = json.split(#text needle);
    ignore iter.next();
    switch (iter.next()) {
      case null [];
      case (?segment) {
        // Find the closing ] of the segments array
        // Split on "}," to get individual segment objects, then on the final }]
        let buf = List.empty<Types.TimestampSegment>();
        // Collect everything up to the outer ]
        let outerIter = segment.split(#text "]");
        switch (outerIter.next()) {
          case null {};
          case (?inner) {
            // Split individual objects on },{ separator
            let objParts = inner.split(#text "},{");
            for (part in objParts) {
              let timeSeconds = extractNatField(part, "timeSeconds");
              let timeFormatted = switch (extractStringField(part, "timeFormatted")) {
                case (?t) t;
                case null formatTimestamp(timeSeconds);
              };
              let keyPoint = switch (extractStringField(part, "keyPoint")) {
                case (?k) k;
                case null "";
              };
              if (not keyPoint.isEmpty()) {
                buf.add({ timeSeconds; timeFormatted; keyPoint });
              };
            };
          };
        };
        buf.toArray();
      };
    };
  };

  /// Parse the raw OpenAI response JSON into a VideoSummaryResult.
  public func parseVideoSummaryResponse(
    content : Text,
    videoId : Text,
    metadata : Types.VideoMetadata,
  ) : Types.VideoSummaryResult {
    let cleaned = stripFences(content);

    let summaryShort = switch (extractStringField(cleaned, "summaryShort")) {
      case (?t) t;
      case null "• Summary unavailable";
    };
    let summaryDetailed = switch (extractStringField(cleaned, "summaryDetailed")) {
      case (?t) t;
      case null "Detailed summary unavailable.";
    };
    let keyPoints = extractArrayField(cleaned, "keyPoints");
    let topics = extractArrayField(cleaned, "topics");
    let segments = parseSegments(cleaned);

    {
      videoId;
      metadata;
      summaryShort;
      summaryDetailed;
      keyPoints;
      topics;
      segments;
    };
  };
};
